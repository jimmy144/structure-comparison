import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EventObject;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.AbstractAction;
import javax.swing.AbstractCellEditor;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.jmol.adapter.smarter.SmarterJmolAdapter;
import org.jmol.api.JmolAdapter;
import org.jmol.api.JmolViewer;


public class GlobalStructureComparison {
public static void main(String[] args) throws Exception {

		// Character c1 = new Character('A');
		// Character c2 = new Character('C');
		//
		// // create an int type
		// int res;
		//
		// // compare c1 with c2 and assign result to res
		// res = c2.compareTo(c1);
		// System.out.println(res);

	 try {
			 UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());	 
		 } 
		 catch (Exception e) {}
	 
 new MainFrame().setVisible(true);
 }
 }
 
class MainFrame extends JFrame implements ActionListener 
		{
	
	private static final long serialVersionUID = 1L;
	MainFrame(){
		super("Welcome you to very fast function recognition solfware");
 		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 		int h = Toolkit.getDefaultToolkit().getScreenSize().height;
 		setSize(w,h);
		create_mainFrame();
	     }	
	
	
	public void create_mainFrame(){
		JPanel mainPanel= new JPanel();
		JMenuBar menuBar = new JMenuBar();
		JMenu menuRun = new JMenu("Run");
		JMenu menuFile = new JMenu("File");
		JMenuItem  Save = new JMenuItem("Save file");
		Save.addActionListener(this);
		JMenuItem  Open = new JMenuItem("Open file");
		Open.addActionListener(this);
		menuFile.add(Open);menuFile.add(Save);
		JMenu menuHelp = new JMenu("Help");
		JMenuItem  readme = new JMenuItem("Read me");
		readme.addActionListener(this);
		menuHelp.add(readme);
		JMenuItem  run1 = new JMenuItem("core program ");
		run1.addActionListener(this);
		menuRun.add(run1);
		menuBar.add(menuRun);menuBar.add(menuHelp);menuBar.add(menuFile);
		this.setJMenuBar(menuBar);
		this.getContentPane().add(BorderLayout.CENTER,mainPanel);
		}
	public void actionPerformed(ActionEvent e){
 		if(e.getActionCommand().equals("core program ")) new Run_coreProgram1();
		else if(e.getActionCommand().equals("Read me")) new Readme();
		else if(e.getActionCommand().equals("Save file")){
		MyDBengine engine = new MyDBengine();
		try{
				String path = "OutputFiles" + File.separator + "OutputTable";
		Result r =(Result)engine.DeserialObject(path);		
		JFileChooser chooser = new JFileChooser();
		chooser.setCurrentDirectory(new File("./"));
		int actionDialog = chooser.showSaveDialog(this);
		if ( actionDialog == JFileChooser.APPROVE_OPTION ){   
		 	File fileName = new File(chooser.getSelectedFile( ) + ".log" );    
			if(fileName != null){ 
			engine.SerialObject(chooser.getSelectedFile ().getAbsolutePath(),r);

					}}
		}catch (Exception ex) {}}

		else if(e.getActionCommand().equals("Open file")){

		JFileChooser fc = new JFileChooser ();
      		fc.setDialogTitle ("Open file");
      		fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    		fc.setCurrentDirectory (new File ("."));
     	 	int result = fc.showOpenDialog (null);
     		if (result == JFileChooser.APPROVE_OPTION) {

		MyDBengine eg = new MyDBengine();
		try{
		Result r =(Result)eg.DeserialObject(fc.getSelectedFile().getAbsolutePath());new ResultTable(r);}catch (Exception ex) {}
		 
}}}}


class ButtonColumn extends AbstractCellEditor
	implements TableCellRenderer, TableCellEditor, ActionListener, MouseListener
{
	
	private static final long serialVersionUID = 1L;
	public JTable table;
	public Action action;
	public Action action2;
	public Action action3;
	public int mnemonic;
	public Border focusBorder;
	public JButton renderButton;
	public JButton editButton;
	public JButton editButton2;
	public JButton editButton3;
	public Object editorValue;
	public boolean isButtonColumnEditor;
	public int column;
	public int column2;
	public int column3;

	public ButtonColumn(JTable table, Action action, Action action2, Action action3, int column, int column2,
		int column3)
	{   this.column=column;
		this.column2=column2;
		this.column3 = column3;
		this.table = table;
		this.action = action;
		this.action2 = action2;
		this.action3 = action3;
		renderButton = new JButton("Open...");
		editButton = new JButton();
		editButton2 = new JButton();
		editButton3 = new JButton();
		editButton.setFocusPainted( false );
		editButton2.setFocusPainted( false );
		editButton3.setFocusPainted(false);
		editButton.addActionListener( this );
		editButton2.addActionListener( this );
		editButton3.addActionListener(this);
		editButton.getBorder();
		editButton2.getBorder();
		editButton3.getBorder();
		setFocusBorder( new LineBorder(Color.BLUE) );
		TableColumnModel columnModel = table.getColumnModel();
		columnModel.getColumn(column).setCellRenderer(this);
		columnModel.getColumn(column).setCellEditor(this);
		columnModel.getColumn(column2).setCellRenderer(this);
		columnModel.getColumn(column2).setCellEditor(this);
		columnModel.getColumn(column3).setCellRenderer(this);
		columnModel.getColumn(column3).setCellEditor(this);
		table.addMouseListener(this);
	}


	public Border getFocusBorder()
	{
		return focusBorder;
	}

	public void setFocusBorder(Border focusBorder)
	{
		this.focusBorder = focusBorder;
		editButton.setBorder( focusBorder );
		editButton2.setBorder( focusBorder );
		editButton3.setBorder(focusBorder);
	}

	public int getMnemonic()
	{
		return mnemonic;
	}

	
	public void setMnemonic(int mnemonic)
	{
		this.mnemonic = mnemonic;
		renderButton.setMnemonic(mnemonic);
		editButton.setMnemonic(mnemonic);
		editButton2.setMnemonic(mnemonic);
		editButton3.setMnemonic(mnemonic);
	}

	@Override
	public Component getTableCellEditorComponent(
		JTable table, Object value, boolean isSelected, int row, int column)
	{
		
		if (column == 2)
			return editButton;
		else if (column == 10)
			return editButton2;
		else if (column == 11)
			return editButton3;
		else return null;
		
	}

	@Override
	public Object getCellEditorValue()
	{
		return editorValue;
	}

	public Component getTableCellRendererComponent(
		JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column){
	

		if (column == 2 || column == 10 || column == 11)
			return renderButton;
		else
			return null;
	}


	public void actionPerformed(ActionEvent e)
	{
		
		int x=table.convertColumnIndexToModel(table.getEditingColumn());
		if(x==column){
		int row = table.convertRowIndexToModel( table.getEditingRow() );
		fireEditingStopped();

		//  Invoke the Action

		ActionEvent event = new ActionEvent(
			table,
			ActionEvent.ACTION_PERFORMED,
			"" + row);
		action.actionPerformed(event);
		}
		else if(x==column2){
			int row = table.convertRowIndexToModel(table.getEditingRow());
			fireEditingStopped();

			//  Invoke the Action

			ActionEvent event = new ActionEvent(
				table,
				ActionEvent.ACTION_PERFORMED,
				"" + row);
			action2.actionPerformed(event);
			}

		else if (x == column3) {
			int row = table.convertRowIndexToModel(table.getEditingRow());
			fireEditingStopped();

			// Invoke the Action

			ActionEvent event = new ActionEvent(table, ActionEvent.ACTION_PERFORMED, "" + row);
			action3.actionPerformed(event);
		}

	}


    public void mousePressed(MouseEvent e)
    {
    	if (table.isEditing()
		&&  table.getCellEditor() == this)
			isButtonColumnEditor = true;
    }

    public void mouseReleased(MouseEvent e)
    {
    	if (isButtonColumnEditor
    	&&  table.isEditing())
    		table.getCellEditor().stopCellEditing();

		isButtonColumnEditor = false;
    }

    public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}

class Readme extends JFrame{

	private static final long serialVersionUID = 1L;

	Readme(){
	setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	String content="Core program perform global structure comparison between an input structure and list known structures";

	JPanel Panel = new JPanel();
	JTextArea text = new JTextArea(content,18,30);
	text.setFont(new Font("LucidaSans", Font.PLAIN, 14));
	Panel.add(text);
	getContentPane().add(Panel);
	int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 	int h = Toolkit.getDefaultToolkit().getScreenSize().height;
 	setSize(w,h);
	pack();
    	setVisible(true);
	 }
	}


class Run_coreProgram1 extends JFrame implements ActionListener,ListSelectionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTextField pathFile;
	JTextField KnownProPathFile;
	JTextField MinTMscore;
	double minTMscore;
	JButton OK;
	JButton browse;
	JButton browse2;
	JProgressBar pb ;
	JFrame fr ;
	JPanel running;
	String targetProtein_id;
	String path_file;
	String KnownPath;
	Run_coreProgram1(){
			super("Global structure comparison: one against all");
		 pb = new JProgressBar();
		 fr = new JFrame();
		running= new JPanel();
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
 		setSize(1100,600);
		int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 		int h = Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setLocation((int)w/2 - 550,
         (int)h/2 - 300);
		create_GUI();
			}


		public void actionPerformed(ActionEvent e) {
			Object o=e.getSource();
 				if(o.equals(browse)) {
		String s ="";// file path
		JFileChooser fc = new JFileChooser ();
      		fc.setDialogTitle ("Choose target protein file");
      		fc.setFileSelectionMode ( JFileChooser.FILES_ONLY);
    		fc.setCurrentDirectory (new File ("."));
    		fc.addChoosableFileFilter(new PDB_fileFilter());
     	 	int result = fc.showOpenDialog (null);
     		if (result == JFileChooser.APPROVE_OPTION) 
        	s = fc.getSelectedFile().getAbsolutePath();
		this.pathFile.setText(s);}
 				
 				if(o.equals(browse2)) {
 					String s ="";// file path
 					JFileChooser fc = new JFileChooser ();
			fc.setDialogTitle("List known structures(folder or file)");
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
 			    		fc.setCurrentDirectory (new File ("."));
 			    		fc.addChoosableFileFilter(new PDB_fileFilter());
 			     	 	int result = fc.showOpenDialog (null);
 			     		if (result == JFileChooser.APPROVE_OPTION) 
 			        	s = fc.getSelectedFile().getAbsolutePath();
 					this.KnownProPathFile.setText(s);}
 							
				
				
			

			
				else if(o.equals(OK)) {
		targetProtein_id = "Protein_Name";
		path_file= pathFile.getText();
		KnownPath =KnownProPathFile.getText();
		int n = path_file.length();
		if (n>7) targetProtein_id = path_file.substring(n-8,n-4);
		minTMscore = 0.3;
		 try {
			 minTMscore = Double.parseDouble(MinTMscore.getText()); 
			 
			 
	 } catch (Exception e1) {
	 JOptionPane.showMessageDialog(null,"Input value error !! Maximum RMSD must be  a number"); 
	 return;}
if(minTMscore>1||minTMscore<0)
			 
	minTMscore =0.3; 
			
		 
		 
		
		
	new Thread() {
          public void run() {

	pb.setPreferredSize(new Dimension(600,40));
	int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 	int h = Toolkit.getDefaultToolkit().getScreenSize().height;
	fr.setLocation((int)w/2 - 300,
         (int)h/2 - 20);
	pb.setIndeterminate(true);
	running.add(pb);
	fr.setContentPane(running);fr.pack();
	fr.setVisible(true);
}}.start();

	
new Thread() {
          public void run() {

     	  
	try {
	CoreAlgorismModule program=new CoreAlgorismModule(KnownPath,targetProtein_id,path_file,minTMscore);
	//program.SAVE_all_alignments();
	//File file = new File(KnownPath);
//	LinkedList<Alignment>list1;
	//if(file.isDirectory()){
	program.all_alignments1();//save into memory
	LinkedList<Alignment> list1 = program.get_all_alignments();//get back;
	
	//}
	/*
	else{
		
		list1 = program.all_alignments2();
		}*/
						System.out.print("ssss" + list1.size());
	Result result1= new Result(program.sort(list1),path_file);
	MyDBengine engine = new MyDBengine();
						String path = "OutputFiles" + File.separator + "OutputTable";
	engine.SerialObject(path,result1);
						String path2 = "Result" + File.separator + "Result_" + targetProtein_id;
	engine.SerialObject(path2,result1);
	new ResultTable(result1);
	fr.setVisible(false);//show GUI table result
	  }catch (Exception ex) {
		ex.printStackTrace();
		JOptionPane.showMessageDialog(null,""+ex); 
		}  finally{fr.setVisible(false);}}}.start();

	}}



		public void valueChanged(ListSelectionEvent e) {
				//Object o=e.getSource();
 				//if(o.equals(sortChoice)) sortChoice.getSelectedIndex();
 				//else if(o.equals(this.structureLevel)) this.structureLevel.getSelectedIndex();
 				
 				

 				}
 
		
		public void create_GUI() {
			JPanel p = new JPanel(new GridBagLayout());
			GridBagConstraints c= new GridBagConstraints();
			c.insets = new Insets(10,10,10,10);
			
			

			this.pathFile = new JTextField(25);
			JLabel  file_label = new JLabel("Input protein file");
			file_label.setLabelFor(this.pathFile);
			c.gridx=0;
			c.gridy=1;
		p.add(file_label,c);
		c.gridx=1;
		c.gridy=1;
		p.add(this.pathFile,c);
		c.gridx=2;
		c.gridy=1;
		this.browse = new JButton("Browse");
		this.browse.addActionListener(this);
		p.add(this.browse,c);
		

		this.KnownProPathFile = new JTextField(25);
		JLabel labelForKnownProPathFile = new JLabel("Known protein folder or file");
		labelForKnownProPathFile.setLabelFor(this.KnownProPathFile);
		c.gridx=0;
		c.gridy=3;
		
	p.add(labelForKnownProPathFile,c);
	c.gridx=1;
	c.gridy=3;
	p.add(this.KnownProPathFile,c);
	
	c.gridx=2;
	c.gridy=3;
	this.browse2 = new JButton("Browse");
	this.browse2.addActionListener(this);
	p.add(this.browse2,c);
	
		
		

		this.MinTMscore = new JTextField(3);
		this.MinTMscore.setText("0.2");
		JLabel  LabelForMinTMscore = new JLabel("Minimum TM-score");
		LabelForMinTMscore.setLabelFor(this.MinTMscore);
		c.gridx=0;
		c.gridy=5;
		p.add(LabelForMinTMscore,c);
		c.gridx=1;
		c.gridy=5;
		p.add(this.MinTMscore,c);
		
		c.gridx=1;
		c.gridy=7;
		this.OK = new JButton("OK");
		this.OK.addActionListener(this);
		p.add(this.OK,c);
		
		this.add(p,BorderLayout.NORTH);
		this.setVisible(true);
			}}




 class PDB_fileFilter extends FileFilter
{
     public boolean accept(File f)
    {
        if(f.isDirectory())
        {
            return true;
        }
        return f.getName().endsWith(".pdb");
    }
 
    public String getDescription()
    {
        return "PDB files (*.pdb)";
    }
}


class MyDBengine {
 
 public void SerialObject(String fileName, Object obj) throws Exception{
 FileOutputStream fs=new FileOutputStream(fileName);
 ObjectOutputStream os=new ObjectOutputStream(fs);
 os.writeObject(obj);
 fs.close();os.close();
 }
 
 public Object DeserialObject(String path) throws Exception{
 Object kp=null;
 FileInputStream fi=new FileInputStream(path);
 ObjectInputStream ois=new ObjectInputStream(fi);
 kp=ois.readObject();
 fi.close();ois.close();
 return kp;
 }
 }


class OutputDataBase implements java.io.Serializable{
 private static final long serialVersionUID = 7576163164455567730L;
 ArrayList<Result> data;

    public OutputDataBase(ArrayList<Result> data)
    {
	this.data=data;}}





class JButtonCellRenderer extends JPanel implements TableCellRenderer { 
	private static final long serialVersionUID = 1L;

		public Component getTableCellRendererComponent( 
                            final JTable table, Object value, 
                            boolean isSelected, boolean hasFocus, 
                            int row, int column) { 
           
                this.add( new JButton("Jmol")); 
                return this; 
        } 
} 




class Superpostion{
	Alignment A;

	Superpostion(Alignment A) {
		this.A = A;
	}
	
	
public String Translation_Rotation2(ArrayList<String>List_residueFromEnzymePDBfile,String EnzymePDBcode,String TargetPDBcode,String pathFile,Point O1,Point O2,MT S)throws Exception{
	String file="";
	int n=List_residueFromEnzymePDBfile.size();//"SuperPosition"+"\\"+A.InputProtein+A.KnownProtein.trim().substring(0,4)+".pdb"
	   for(int i=0;i<n;i++){
			String line=List_residueFromEnzymePDBfile.get(i);
			String r0=line.substring(0,6);
			String r1=line.substring(6,12);
			String r2=line.substring(12,16);
			String r3=line.substring(16,17);
			String r4=line.substring(17,20);//residue name
			String r5=line.substring(20,21); 
			String r6=line.substring(21,22);//chain name
			String r7=line.substring(22,26);//residue number 
			String r8=line.substring(26,27);//insertion code 
			String r9=line.substring(27,38);// x_cordinate 
			String r10=line.substring(38,46);//y_cordinate
			String r11=line.substring(46,54);//z_cordinate
			String r12=line.substring(54,60);
			String r13=line.substring(60,66);
			String r14=line.substring(66,72);
			String r15=line.substring(72,80);	
					
				MT X=new MT(3,1);
				X.data[0][0]= Double.parseDouble(r9.trim())-O1.x;
				X.data[1][0]= Double.parseDouble(r10.trim())-O1.y;
				X.data[2][0]= Double.parseDouble(r11.trim())-O1.z;
				MT Y=S.times(X);
			 	r9= String.format("%.3f",Y.data[0][0]+O2.x);
			 	r10= String.format("%.3f",Y.data[1][0]+O2.y);
				r11= String.format("%.3f",Y.data[2][0]+O2.z);
				r9="   "+fillblank(r9.trim());
				r10=fillblank(r10.trim());
				r11=fillblank(r11.trim());
				r6="Z";			String s=r0+r1+r2+r3+r4+r5+r6+r7+r8+r9+r10+r11+r12+r13+r14+r15;   
				file=file+s+"\n";
				  }
						

	   file= file+"TER"+"\n";
	   
		
		Scanner in=new Scanner(new FileInputStream(pathFile)); 
		boolean read_more = true; 
		    while((in.hasNextLine())&&(read_more)){
			String line=in.nextLine(); 
			if((line.startsWith("ATOM"))||(line.startsWith("HETATM"))) file=file+line+"\n";
			else if(line.startsWith("END")) read_more= false; }in.close();
				file=file+"END";
				return file;}




public void Translation_Rotation(String hashtableID,Point O1,Point O2,MT S,String InpuMotifPathFile,String inputChain,String hitChain,String pathFile)throws Exception{

		String path = "OutputFiles" + File.separator + "SuperPosition.pdb";
		String path2 = "OutputFiles" + File.separator + "SuperPosition2.pdb";
		PrintWriter out2 = new PrintWriter(new FileOutputStream(path2));
	PrintWriter out = new PrintWriter(new FileOutputStream(path));	
		// color 1 using distance
		// color 2 using blosum

		HashMap<String, String> input = this.A.color1.get(0);
		HashMap<String, String> hit = this.A.color1.get(1);
	
		HashMap<String, String> input2 = this.A.color2.get(0);
		HashMap<String, String> hit2 = this.A.color2.get(1);
	Scanner sc = new Scanner(new FileInputStream(InpuMotifPathFile)); 
	boolean readMore = true; 
	    while((sc.hasNextLine())&&(readMore)){
	    	String line=sc.nextLine(); 
	    	if((line.startsWith("ATOM"))||(line.startsWith("HETATM"))){
	    		String r6=line.substring(21,22);//chain name
	    		if(r6.trim().compareTo(inputChain)==0){
			String r0=line.substring(0,6);
			String r1=line.substring(6,12);
			String r2=line.substring(12,16);
			String r3=line.substring(16,17);
			//String r4=line.substring(17,20);//residue name
			String rr4=line.substring(17,20);//residue name
			String r5=line.substring(20,21); 
			//String r6=line.substring(21,22);//chain name
			String r7=line.substring(22,26);//residue number 
			String r8=line.substring(26,27);//insertion code 
			String r9=line.substring(27,38);// x_cordinate 
			String r10=line.substring(38,46);//y_cordinate
			String r11=line.substring(46,54);//z_cordinate
			String r12=line.substring(54,60);
					String r13 = line.substring(60, 66);// B factor
			String r14=line.substring(66,72);
			String r15=line.substring(72,80);	
					// r6="Z";
			/*
			if(r4.compareTo("MO3")==0) r4="MG";
			if((r4.compareTo("FE1")==0)||(r4.compareTo("FE2")==0)) r4="FE";
			if((r4.compareTo("CU1")==0)||(r4.compareTo("CUA")==0)) r4="CU";
			if((r4.compareTo("ZNO")==0)||(r4.compareTo("ZN1")==0)) r4="ZN";
				String s =r4.trim()+" "+r7.trim()+" "+r6;
for(int i=0;i<list_resides.size();i++){
if ((list_resides.get(i).trim().compareTo(s.trim())==0)){r6="Y";break;}}

			*/
			
					
				MT X=new MT(3,1);
				X.data[0][0]= Double.parseDouble(r9.trim())-O1.x;
				X.data[1][0]= Double.parseDouble(r10.trim())-O1.y;
				X.data[2][0]= Double.parseDouble(r11.trim())-O1.z;
				MT Y=S.times(X);
			 	r9= String.format("%.3f",Y.data[0][0]+O2.x);
			 	r10= String.format("%.3f",Y.data[1][0]+O2.y);
				r11= String.format("%.3f",Y.data[2][0]+O2.z);
				r9=r9.replace(',', '.');
				r10=r10.replace(',', '.');
				r11=r11.replace(',', '.');
				r9="   "+fillblank(r9.trim());
				r10=fillblank(r10.trim());
				r11=fillblank(r11.trim());

					String key = rr4.trim() + r6 + r7.trim();
					if (input.containsKey(key))
						r13 = input.get(key);
					else
						r13 = "100.00";

					// key=Residue_Name+this.Chain_Name+this.Residue_number;
					r6 = "Z";
				String newLINE=r0+r1+r2+r3+rr4+r5+r6+r7+r8+r9+r10+r11+r12+r13+r14+r15;   
				out.println(newLINE);
					r13 = line.substring(60, 66);// B factor
					if (input2.containsKey(key))
						r13 = input2.get(key);
					else
						r13 = "  0.00";
					String newLINE2 = r0 + r1 + r2 + r3 + rr4 + r5 + r6 + r7 + r8 + r9 + r10 + r11 + r12 + r13 + r14
						+ r15;
					out2.println(newLINE2);
				  }}
	    	
	    	else if ((line.startsWith("END"))) readMore = false;	
	    }sc.close();
	    	
	    	
						

	   out.println("TER");
	   
		//String pathFile = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+ hashtableID +".pdb";
		Scanner in=new Scanner(new FileInputStream(pathFile)); 
		boolean read_mmore = true; 
		    while((in.hasNextLine())&&(read_mmore)){
			String line=in.nextLine(); 
			if((line.startsWith("ATOM"))||(line.startsWith("HETATM")))
			{
				String r6=line.substring(21,22);//chain name
				if (r6.trim().compareTo(hitChain) == 0) {

					String r0 = line.substring(0, 6);
					String r1 = line.substring(6, 12);
					String r2 = line.substring(12, 16);
					String r3 = line.substring(16, 17);
					// String r4=line.substring(17,20);//residue name
					String rr4 = line.substring(17, 20);// residue name
					String r5 = line.substring(20, 21);
					// String r6=line.substring(21,22);//chain name
					String r7 = line.substring(22, 26);// residue number
					String r8 = line.substring(26, 27);// insertion code
					String r9 = line.substring(27, 38);// x_cordinate
					String r10 = line.substring(38, 46);// y_cordinate
					String r11 = line.substring(46, 54);// z_cordinate
					String r12 = line.substring(54, 60);
					String r13 = line.substring(60, 66);// B factor
					String r14 = line.substring(66, 72);
					String r15 = line.substring(72, 80);

					String key = rr4.trim() + r6 + r7.trim();
					r13 = hit.get(key);
					if (hit.containsKey(key))
						r13 = hit.get(key);
					else
						r13 = "100.00";
					String newLINE = r0 + r1 + r2 + r3 + rr4 + r5 + r6 + r7 + r8 + r9 + r10 + r11 + r12 + r13 + r14
						+ r15;
					out.println(newLINE);

					r13 = line.substring(60, 66);// B factor
					if (hit2.containsKey(key))
						r13 = hit2.get(key);
					else
						r13 = "  0.00";
					String newLINE2 = r0 + r1 + r2 + r3 + rr4 + r5 + r6 + r7 + r8 + r9 + r10 + r11 + r12 + r13 + r14
						+ r15;
					out2.println(newLINE2);
				}
			}
			
			else if(line.startsWith("END")) read_mmore= false; }
		    in.close();
			out.println("END"); out.close();
				}

	public void Translation_Rotation111(String hashtableID, Point O1, Point O2, MT S, String InpuMotifPathFile,
		String inputChain, String hitChain, String pathFile) throws Exception {

		String path = "OutputFiles" + File.separator + "SuperPosition.pdb";
		PrintWriter out = new PrintWriter(new FileOutputStream(path));

		Scanner sc = new Scanner(new FileInputStream(InpuMotifPathFile));
		boolean readMore = true;
		while ((sc.hasNextLine()) && (readMore)) {
			String line = sc.nextLine();
			if ((line.startsWith("ATOM")) || (line.startsWith("HETATM"))) {
				String r6 = line.substring(21, 22);// chain name
				if (r6.trim().compareTo(inputChain) == 0) {
					String r0 = line.substring(0, 6);
					String r1 = line.substring(6, 12);
					String r2 = line.substring(12, 16);
					String r3 = line.substring(16, 17);
					// String r4=line.substring(17,20);//residue name
					String rr4 = line.substring(17, 20);// residue name
					String r5 = line.substring(20, 21);
					// String r6=line.substring(21,22);//chain name
					String r7 = line.substring(22, 26);// residue number
					String r8 = line.substring(26, 27);// insertion code
					String r9 = line.substring(27, 38);// x_cordinate
					String r10 = line.substring(38, 46);// y_cordinate
					String r11 = line.substring(46, 54);// z_cordinate
					String r12 = line.substring(54, 60);
					String r13 = line.substring(60, 66);// B factor
					String r14 = line.substring(66, 72);
					String r15 = line.substring(72, 80);
					r6 = "Z";
					/*
					 * if(r4.compareTo("MO3")==0) r4="MG"; if((r4.compareTo("FE1")==0)||(r4.compareTo("FE2")==0))
					 * r4="FE"; if((r4.compareTo("CU1")==0)||(r4.compareTo("CUA")==0)) r4="CU";
					 * if((r4.compareTo("ZNO")==0)||(r4.compareTo("ZN1")==0)) r4="ZN"; String s =r4.trim()+" "
					 * +r7.trim()+" "+r6; for(int i=0;i<list_resides.size();i++){ if
					 * ((list_resides.get(i).trim().compareTo(s.trim())==0)){r6="Y";break;}}
					 */

					MT X = new MT(3, 1);
					X.data[0][0] = Double.parseDouble(r9.trim()) - O1.x;
					X.data[1][0] = Double.parseDouble(r10.trim()) - O1.y;
					X.data[2][0] = Double.parseDouble(r11.trim()) - O1.z;
					MT Y = S.times(X);
					r9 = String.format("%.3f", Y.data[0][0] + O2.x);
					r10 = String.format("%.3f", Y.data[1][0] + O2.y);
					r11 = String.format("%.3f", Y.data[2][0] + O2.z);
					r9 = r9.replace(',', '.');
					r10 = r10.replace(',', '.');
					r11 = r11.replace(',', '.');
					r9 = "   " + fillblank(r9.trim());
					r10 = fillblank(r10.trim());
					r11 = fillblank(r11.trim());
					String newLINE = r0 + r1 + r2 + r3 + rr4 + r5 + r6 + r7 + r8 + r9 + r10 + r11 + r12 + r13 + r14
						+ r15;
					out.println(newLINE);
				}
			}

			else if ((line.startsWith("END")))
				readMore = false;
		}
		sc.close();

		out.println("TER");

		// String pathFile = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+ hashtableID
		// +".pdb";
		Scanner in = new Scanner(new FileInputStream(pathFile));
		boolean read_mmore = true;
		while ((in.hasNextLine()) && (read_mmore)) {
			String line = in.nextLine();
			if ((line.startsWith("ATOM")) || (line.startsWith("HETATM"))) {
				String r6 = line.substring(21, 22);// chain name
				if (r6.trim().compareTo(hitChain) == 0)
					out.println(line);
			}

			else if (line.startsWith("END"))
				read_mmore = false;
		}
		in.close();
		out.println("END");
		out.close();
	}
public void Translation_Rotation2222(ArrayList<String> list_HitResidues,String hashtableID,Point O1,Point O2,MT S,String InpuMotifPathFile,ArrayList<String>list_resides,String inputChain,String hitChain,String pathFile)throws Exception{

		String path = "OutputFiles" + File.separator + "SuperPosition.pdb";
	PrintWriter out = new PrintWriter(new FileOutputStream(path));	
	
	
	Scanner sc = new Scanner(new FileInputStream(InpuMotifPathFile)); 
	boolean readMore = true; 
	    while((sc.hasNextLine())&&(readMore)){
	    	String line=sc.nextLine(); 
	    	if((line.startsWith("ATOM"))||(line.startsWith("HETATM"))){
	    		String r6=line.substring(21,22);//chain name
	    		if(r6.trim().compareTo(inputChain)==0){
			String r0=line.substring(0,6);
			String r1=line.substring(6,12);
			String r2=line.substring(12,16);
			String r3=line.substring(16,17);
			//String r4=line.substring(17,20);//residue name
			String rr4=line.substring(17,20);//residue name
			String r5=line.substring(20,21); 
			//String r6=line.substring(21,22);//chain name
			String r7=line.substring(22,26);//residue number 
			String r8=line.substring(26,27);//insertion code 
			String r9=line.substring(27,38);// x_cordinate 
			String r10=line.substring(38,46);//y_cordinate
			String r11=line.substring(46,54);//z_cordinate
			String r12=line.substring(54,60);
			String r13=line.substring(60,66);
			String r14=line.substring(66,72);
			String r15=line.substring(72,80);	
			r6="Z";
			/*
			if(r4.compareTo("MO3")==0) r4="MG";
			if((r4.compareTo("FE1")==0)||(r4.compareTo("FE2")==0)) r4="FE";
			if((r4.compareTo("CU1")==0)||(r4.compareTo("CUA")==0)) r4="CU";
			if((r4.compareTo("ZNO")==0)||(r4.compareTo("ZN1")==0)) r4="ZN";
				String s =r4.trim()+" "+r7.trim()+" "+r6;
for(int i=0;i<list_resides.size();i++){
if ((list_resides.get(i).trim().compareTo(s.trim())==0)){r6="Y";break;}}

			*/
			
					
				MT X=new MT(3,1);
				X.data[0][0]= Double.parseDouble(r9.trim())-O1.x;
				X.data[1][0]= Double.parseDouble(r10.trim())-O1.y;
				X.data[2][0]= Double.parseDouble(r11.trim())-O1.z;
				MT Y=S.times(X);
			 	r9= String.format("%.3f",Y.data[0][0]+O2.x);
			 	r10= String.format("%.3f",Y.data[1][0]+O2.y);
				r11= String.format("%.3f",Y.data[2][0]+O2.z);
				r9=r9.replace(',', '.');
				r10=r10.replace(',', '.');
				r11=r11.replace(',', '.');
				r9="   "+fillblank(r9.trim());
				r10=fillblank(r10.trim());
				r11=fillblank(r11.trim());
	
				String newLINE=r0+r1+r2+r3+rr4+r5+r6+r7+r8+r9+r10+r11+r12+r13+r14+r15;   
				out.println(newLINE);
				  }}
	    	
	    	else if ((line.startsWith("END"))) readMore = false;	
	    }sc.close();
	    	
	    	
						

	   out.println("TER");
	   
		//String pathFile = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+ hashtableID +".pdb";
		Scanner in=new Scanner(new FileInputStream(pathFile)); 
		boolean read_mmore = true; 
		    while((in.hasNextLine())&&(read_mmore)){
			String line=in.nextLine(); 
			if((line.startsWith("ATOM"))||(line.startsWith("HETATM")))
			{
				String r6=line.substring(21,22);//chain name
				 if(r6.trim().compareTo(hitChain)==0) 
				 out.println(line);
			}
			
			else if(line.startsWith("END")) read_mmore= false; }
		    in.close();
			out.println("END"); out.close();
				}

public String fillblank(String s){
		double f = Double.parseDouble(s);
		double x= Math.abs(f);
		String s1="";
			if(x<10 && f>0) s1="   "+s;
		else if (x < 10 && f <= 0)
			s1 = "  " + s;
		   
			else if(x<100 && f>0)s1="  "+s;
			else if(x<100 && f<0)s1=" "+s; 
	
			else if (x<1000 && f>0)s1=" "+s;
			else s1=""+s; 
		return s1;}

	}

class Result implements java.io.Serializable{
	private static final long serialVersionUID = 7576163164455567730L;
	LinkedList<Alignment> myAlignments;
	String pathFile;
    public Result(LinkedList<Alignment> myAlignments,String pathFile)
    	{
		this.pathFile = pathFile;
	this.myAlignments=myAlignments;
	}}

class ButtonHeaderRenderer extends JButton implements TableCellRenderer {
     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int pushedColumn;
 
     public ButtonHeaderRenderer() {
       pushedColumn   = -1;
       setMargin(new Insets(0,0,0,0));
     }
 
     public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
       setText((value ==null) ? "" : value.toString());
       boolean isPressed = (column == pushedColumn);
       getModel().setPressed(isPressed);
       getModel().setArmed(isPressed);
       return this;
     }
 
     public void setPressedColumn(int col) {
       pushedColumn = col;
     }
   }

class Table_Model extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int sortCol4 = 4;
	protected int sortCol5= 5;
	protected int sortCol6 = 6;
	protected int sortCol7 = 7;
	protected int sortCol8 = 8;
	protected int sortCol9 = 9;
	protected boolean isSortAsc = false;
	protected int columnsCount = 12;
	LinkedList<Alignment> myAlignments ;

	public Table_Model(LinkedList<Alignment> myAlignments) {
    this.myAlignments = myAlignments;
  }

	public int getRowCount() {
   		 return myAlignments == null ? 0 : myAlignments.size();
  }

	public int getColumnCount() {
    return columnsCount;
  }

  
public String getColumnName(int column) {
		String[] colNames = {"Alignment", "pdb25 protein", "Open Jmol", "Description", "TMscore", "RMSD", "blosum",
			"clesum", "hydrBondSim", "evolutionScore", "Sequence Alignment", "Superimposed"};
		return colNames[column];
	}


  public boolean isCellEditable(int nRow, int nCol) {
    return true;
  }

  public Object getValueAt(int nRow, int nCol) {
if (nRow < 0 || nRow >= getRowCount())
      return "";
else {
	if(nCol==0) return nRow+"";
	else if(nCol==1) return myAlignments.get(nRow).HitProteinID;
	else if(nCol==3) return myAlignments.get(nRow).HitProteinDescription;
	else if(nCol==4) return myAlignments.get(nRow).print_Score();
	else if(nCol==5) return myAlignments.get(nRow).print_RMSD();
			else if (nCol == 6)
				return myAlignments.get(nRow).print_blosum();
			else if (nCol == 7)
				return myAlignments.get(nRow).print_clesum();
			else if (nCol == 8)
				return myAlignments.get(nRow).print_hyrd();
			else if (nCol == 9)
				return myAlignments.get(nRow).print_evol();
	else return "";
 }
 }



  class MyColumnListener extends MouseAdapter {
	protected JTable table;
	JTableHeader   header;
    ButtonHeaderRenderer renderer;
 
	
    public MyColumnListener(JTable t,JTableHeader header,ButtonHeaderRenderer renderer) {
      table = t;this.header   = header;
      this.renderer = renderer;
    }



public void mousePressed(MouseEvent e) {
       int col = header.columnAtPoint(e.getPoint());
       renderer.setPressedColumn(col);
       header.repaint();
     }
 
     public void mouseReleased(MouseEvent e) {
       renderer.setPressedColumn(-1);                // clear
       header.repaint();
     }

    public void mouseClicked(MouseEvent e) {
      TableColumnModel colModel = table.getColumnModel();
      int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
      int modelIndex = colModel.getColumn(columnModelIndex)
          .getModelIndex();


 if (sortCol4 == modelIndex){
      //  isSortAsc = !isSortAsc;	
      Collections.sort(myAlignments,new ScoreComparator(isSortAsc));
      table.tableChanged(new TableModelEvent(Table_Model.this));
      table.repaint();  isSortAsc = !isSortAsc;	

TableColumnModel colModel1 = table.getColumnModel();
for(int i=0;i<2;i++){ colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
		colModel1.getColumn(i).setCellEditor(new CustomEditor());}
	colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
	//colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
	colModel1.getColumn(3).setCellEditor(new CustomEditor());
	//colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
		colModel1.getColumn(i).setCellEditor(new CustomEditor());}
	
        for (int row = 0; row < table.getRowCount(); row++) 
        {	Component comp = table.prepareRenderer(table.getCellRenderer(row,4), row, 4); 
                int rowHeight = comp.getPreferredSize().height+15; 
          	table.setRowHeight(row, rowHeight); 
        } 
   
    	table.setPreferredScrollableViewportSize(table.getPreferredSize());

			}

			if (sortCol6 == modelIndex) {

				// isSortAsc = !isSortAsc;
				Collections.sort(myAlignments, new BlosumComparator(isSortAsc));
				table.tableChanged(new TableModelEvent(Table_Model.this));
				table.repaint();
				isSortAsc = !isSortAsc;

				TableColumnModel colModel1 = table.getColumnModel();
				for (int i = 0; i < 2; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}
				colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
				// colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
				colModel1.getColumn(3).setCellEditor(new CustomEditor());
				// colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}

				for (int row = 0; row < table.getRowCount(); row++) {
					Component comp = table.prepareRenderer(table.getCellRenderer(row, 4), row, 4);
					int rowHeight = comp.getPreferredSize().height + 15;
					table.setRowHeight(row, rowHeight);
				}

				table.setPreferredScrollableViewportSize(table.getPreferredSize());

			}
			if (sortCol7 == modelIndex) {
				// isSortAsc = !isSortAsc;
				Collections.sort(myAlignments, new ClesumComparator(isSortAsc));
				table.tableChanged(new TableModelEvent(Table_Model.this));
				table.repaint();
				isSortAsc = !isSortAsc;

				TableColumnModel colModel1 = table.getColumnModel();
				for (int i = 0; i < 2; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}
				colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
				// colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
				colModel1.getColumn(3).setCellEditor(new CustomEditor());
				// colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}

				for (int row = 0; row < table.getRowCount(); row++) {
					Component comp = table.prepareRenderer(table.getCellRenderer(row, 4), row, 4);
					int rowHeight = comp.getPreferredSize().height + 15;
					table.setRowHeight(row, rowHeight);
				}

				table.setPreferredScrollableViewportSize(table.getPreferredSize());

			}
			if (sortCol8 == modelIndex) {
				// isSortAsc = !isSortAsc;
				Collections.sort(myAlignments, new HydrScoreComparator(isSortAsc));
				table.tableChanged(new TableModelEvent(Table_Model.this));
				table.repaint();
				isSortAsc = !isSortAsc;

TableColumnModel colModel1 = table.getColumnModel();
				for (int i = 0; i < 2; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}
				colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
				// colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
				colModel1.getColumn(3).setCellEditor(new CustomEditor());
				// colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}

				for (int row = 0; row < table.getRowCount(); row++) {
					Component comp = table.prepareRenderer(table.getCellRenderer(row, 4), row, 4);
					int rowHeight = comp.getPreferredSize().height + 15;
					table.setRowHeight(row, rowHeight);
				}

				table.setPreferredScrollableViewportSize(table.getPreferredSize());

} 
			if (sortCol9 == modelIndex) {
				// isSortAsc = !isSortAsc;
				Collections.sort(myAlignments, new EvolutionScoreComparator(isSortAsc));
				table.tableChanged(new TableModelEvent(Table_Model.this));
				table.repaint();
				isSortAsc = !isSortAsc;

				TableColumnModel colModel1 = table.getColumnModel();
				for (int i = 0; i < 2; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}
				colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
				// colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
				colModel1.getColumn(3).setCellEditor(new CustomEditor());
				// colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
					colModel1.getColumn(i).setCellEditor(new CustomEditor());
				}

				for (int row = 0; row < table.getRowCount(); row++) {
					Component comp = table.prepareRenderer(table.getCellRenderer(row, 4), row, 4);
					int rowHeight = comp.getPreferredSize().height + 15;
					table.setRowHeight(row, rowHeight);
				}

				table.setPreferredScrollableViewportSize(table.getPreferredSize());

			}

else if (sortCol5 == modelIndex){
      Collections.sort(myAlignments,new RMSDComparator(isSortAsc));
      table.tableChanged(new TableModelEvent(Table_Model.this));
      table.repaint();
				isSortAsc = !isSortAsc;
TableColumnModel colModel1 = table.getColumnModel();
for(int i=0;i<2;i++){ colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
		colModel1.getColumn(i).setCellEditor(new CustomEditor());}

	colModel1.getColumn(3).setCellRenderer(new CustomRenderer());
	//colModel1.getColumn(6).setCellRenderer(new CustomRenderer());
	colModel1.getColumn(3).setCellEditor(new CustomEditor());
	//colModel1.getColumn(6).setCellEditor(new CustomEditor());
				for (int i = 4; i < 10; i++) {
					colModel1.getColumn(i).setCellRenderer(new CustomRenderer1());
		colModel1.getColumn(i).setCellEditor(new CustomEditor());}
	
        for (int row = 0; row < table.getRowCount(); row++) 
        {	Component comp = table.prepareRenderer(table.getCellRenderer(row,4), row, 4); 
                int rowHeight = comp.getPreferredSize().height+15; 
          	table.setRowHeight(row, rowHeight); 
        } 
   
    	table.setPreferredScrollableViewportSize(table.getPreferredSize());
} 

    }
  }
}


class FragmentAlignmentComparator implements Comparator<FragmentAlignment> {

	public FragmentAlignmentComparator() {
	  }

	public int compare(FragmentAlignment Alignment1, FragmentAlignment Alignment2) {
		double x = Alignment1.GLscore;
		double y = Alignment2.GLscore;
		if (x < y)
			return 1;
		else
			return -1;
	}
}

class PreAlignmentTMscoreComparator implements Comparator<PreAlignment> {

	public PreAlignmentTMscoreComparator() {
	  }

	public int compare(PreAlignment Alignment1, PreAlignment Alignment2) {
		double x = Alignment1.getTMscore();
		double y = Alignment2.getTMscore();
		if (x < y)
			return 1;
		else
			return -1;
	}
}

class PreAlignmentEvolScoreComparator implements Comparator<PreAlignment> {

	public PreAlignmentEvolScoreComparator() {}

	public int compare(PreAlignment Alignment1, PreAlignment Alignment2) {
		double x = Alignment1.getEvolScore();
		double y = Alignment2.getEvolScore();
		if (x < y)
			return 1;
		else
			return -1;
	}
}

class PreAlignmentRMSDComparator implements Comparator<PreAlignment> {

	public PreAlignmentRMSDComparator() {}

	public int compare(PreAlignment Alignment1, PreAlignment Alignment2) {
		double x = Alignment1.get_RMSD();
		double y = Alignment2.get_RMSD();
		if (x < y)
			return -1;
		else
			return 1;
	}
}

class ScoreComparator implements Comparator<Alignment> {
	  protected boolean isSortAsc;

	  public ScoreComparator(boolean sortAsc) {
	    isSortAsc = sortAsc;
	  }
	  public double round(double x){
			if(x<0.2) return 0.2;
			else if(x<0.4) return 0.4;
			else if(x<0.6) return 0.6;
			else if(x<0.8) return 0.8;
			else if(x<1.0) return 1.0;
			else if(x<1.2) return 1.2;
			else if(x<1.4) return 1.4;
			else if(x<1.6) return 1.6;
			else if(x<1.8) return 1.8;
			else if(x<2.0) return 2.0;
			else if(x<2.2) return 2.2;
			else if(x<2.4) return 2.4;
			else if(x<2.6) return 2.6;
			else if(x<2.8) return 2.8;
			else return 3.0;
		}
	  public int compare(Alignment Alignment1,Alignment Alignment2) {
				double x=Alignment1.score;
				double y=Alignment2.score;
				double x1=this.round(Alignment1.RMSD);
				double y1=this.round(Alignment2.RMSD);
				double x2=Alignment1.residueIDENTITY;
				double y2=Alignment2.residueIDENTITY;
			if(isSortAsc){if(x<y) return 2;
				else if(x==y)
		 {if(x1<y1)return -1;else if(x1==y1){if(x2<y2) return 1;else if(x2==y2) return 0;else return -1;}else return 1;}	
				else return -2;}
				else{if(x<y) return -2;
				else if(x==y)
		 {if(x1<y1)return -1;else if(x1==y1){if(x2<y2) return 1;else if(x2==y2) return 0;else return -1;}else return 1;}	
				else return 2;}
	   					}
	}

class BlosumComparator implements Comparator<Alignment> {
	protected boolean isSortAsc;

	public BlosumComparator(boolean sortAsc) {
		isSortAsc = sortAsc;
	}

	public int compare(Alignment Alignment1, Alignment Alignment2) {
		double x = Alignment1.blosum;
		double y = Alignment2.blosum;

		if (isSortAsc) {
			if (x < y)
				return 2;
			else if (x == y)
				return 0;
			else
				return -2;
		} else {
			if (x < y)
				return -2;
			else if (x == y)
				return 0;
			else
				return 2;
		}

	}
}

class ClesumComparator implements Comparator<Alignment> {
	protected boolean isSortAsc;

	public ClesumComparator(boolean sortAsc) {
		isSortAsc = sortAsc;
	}

	public int compare(Alignment Alignment1, Alignment Alignment2) {
		double x = Alignment1.clesum;
		double y = Alignment2.clesum;

		if (isSortAsc) {
			if (x < y)
				return 2;
			else if (x == y)
				return 0;
			else
				return -2;
		} else {
			if (x < y)
				return -2;
			else if (x == y)
				return 0;
			else
				return 2;
		}

	}
}

class HydrScoreComparator implements Comparator<Alignment> {
	protected boolean isSortAsc;

	public HydrScoreComparator(boolean sortAsc) {
		isSortAsc = sortAsc;
	}

	public int compare(Alignment Alignment1, Alignment Alignment2) {
		double x = Alignment1.evolutionScore;
		double y = Alignment2.evolutionScore;

		if (isSortAsc) {
			if (x < y)
				return 2;
			else if (x == y)
				return 0;
			else
				return -2;
		} else {
			if (x < y)
				return -2;
			else if (x == y)
				return 0;
			else
				return 2;
		}

	}
}

class EvolutionScoreComparator implements Comparator<Alignment> {
	protected boolean isSortAsc;

	public EvolutionScoreComparator(boolean sortAsc) {
		isSortAsc = sortAsc;
	}

	public int compare(Alignment Alignment1, Alignment Alignment2) {
		double x = Alignment1.evolutionScore;
		double y = Alignment2.evolutionScore;

		if (isSortAsc) {
			if (x < y)
				return 2;
			else if (x == y)
				return 0;
			else
				return -2;
		} else {
			if (x < y)
				return -2;
			else if (x == y)
				return 0;
			else
				return 2;
		}

	}
}

	class ResidueIdentityComparator implements Comparator<Alignment> {
	  protected boolean isSortAsc;

	  public ResidueIdentityComparator( boolean sortAsc) {
	    isSortAsc = sortAsc;
	  }
	  public double round(double x){
			if(x<0.2) return 0.2;
			else if(x<0.4) return 0.4;
			else if(x<0.6) return 0.6;
			else if(x<0.8) return 0.8;
			else if(x<1.0) return 1.0;
			else if(x<1.2) return 1.2;
			else if(x<1.4) return 1.4;
			else if(x<1.6) return 1.6;
			else if(x<1.8) return 1.8;
			else if(x<2.0) return 2.0;
			else if(x<2.2) return 2.2;
			else if(x<2.4) return 2.4;
			else if(x<2.6) return 2.6;
			else if(x<2.8) return 2.8;
			else return 3.0;
		}
	  public int compare(Alignment Alignment1,Alignment Alignment2) {
			double x=Alignment1.residueIDENTITY;
			double y=Alignment2.residueIDENTITY;
			double x1=Alignment1.RMSD;
			double y1=Alignment2.RMSD;
			double x2=Alignment1.score;
			double y2=Alignment2.score;
			
		if(isSortAsc){
			if(x<y) return 3;
			else if(x==y)
			    {if(x2<y2) return 2;
				else if(x2==y2)
	 					{if(x1<y1)return -1;else if(x1==y1) return 0;else return 1;}	
				else return -2;}
	
			else return -3;}




		else{if(x<y) return -3;
		else if(x==y)
	    {if(x2<y2) return 2;
		else if(x2==y2)
					{if(x1<y1)return -1;else if(x1==y1) return 0;else return 1;}	
		else return -2;}
	
			else return 3;}	
 					}
	 
	}


	class RMSDComparator implements Comparator<Alignment> {
	  protected boolean isSortAsc;

	  public RMSDComparator( boolean sortAsc) {
	    isSortAsc = sortAsc;
	  }


	  public int compare(Alignment Alignment1,Alignment Alignment2) {
		double x = Alignment1.RMSD;
		double y = Alignment2.RMSD;

		if(isSortAsc){
				if(x<y) return -2;
			else if (x == y)
				return 0;
			else
				return 2;
		}

		else {
			if (x < y)
				return 2;
			else if (x == y)
				return 0;
			else
				return -2;
		}

	   					}
	}


class ResultTable{
	ButtonColumn FinalTable;
    Result result;
	

    public ResultTable(final Result result)
    {   this.result=result;
	
    Table_Model tableModel = new Table_Model(result.myAlignments);
    JTable table = new JTable(tableModel){
	private static final long serialVersionUID = 1L;

	public String getToolTipText(MouseEvent e) {
        java.awt.Point p = e.getPoint();
        int rowIndex = rowAtPoint(p);
        int colIndex = columnAtPoint(p);
        TableModel model = getModel();
        int realColumnIndex = convertColumnIndexToModel(colIndex);
        String tip="";
        if( realColumnIndex==3) {tip=(String)model.getValueAt(rowIndex,colIndex);tip = "<html>"+tip.replaceAll("\n","<br>")+"</html>"; return tip;}
        else return super.getToolTipText(e);
    }};
    
    
    
    
        TableColumnModel colModel = table.getColumnModel();
for(int i=0;i<2;i++){ 
		colModel.getColumn(i).setCellRenderer(new CustomRenderer1());
		colModel.getColumn(i).setCellEditor(new CustomEditor());
		}
      
		for (int i = 4; i < 10; i++) {
	colModel.getColumn(i).setCellRenderer(new CustomRenderer1());
	colModel.getColumn(i).setCellEditor(new CustomEditor());
	}


colModel.getColumn(3).setCellRenderer(new CustomRenderer());
colModel.getColumn(3).setCellEditor(new CustomEditor());


        colModel.getColumn(0).setPreferredWidth(20);
        colModel.getColumn(2).setPreferredWidth(20);
        colModel.getColumn(1).setPreferredWidth(20);
        colModel.getColumn(3).setPreferredWidth(90);
        colModel.getColumn(4).setPreferredWidth(20);
        colModel.getColumn(5).setPreferredWidth(20);
        colModel.getColumn(6).setPreferredWidth(20);
        colModel.getColumn(7).setPreferredWidth(20);
		colModel.getColumn(8).setPreferredWidth(20);
		colModel.getColumn(9).setPreferredWidth(20);
		colModel.getColumn(10).setPreferredWidth(20);
		colModel.getColumn(11).setPreferredWidth(20);
    
        for (int row = 0; row < table.getRowCount(); row++) 
        {	
        	//Component comp1 = table.prepareRenderer(table.getCellRenderer(row,4), row, 4); 
            //int h = comp1.getPreferredSize().height+15;
          	table.setRowHeight(row,50); 
        } 

    	table.setPreferredScrollableViewportSize(table.getPreferredSize());

		Action seqAl = new AbstractAction() {
			private static final long serialVersionUID = 13L;

			public void actionPerformed(ActionEvent e) {
				int modelRow = Integer.valueOf(e.getActionCommand());
				Alignment A = result.myAlignments.get(modelRow);
				String[] seqAl = A.seqAl;
				JFrame jf = new JFrame();
				jf.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				String content = seqAl[0] + "\n" + seqAl[1] + "\n" + seqAl[2];

				JTextArea text = new JTextArea(content);

				JScrollPane scroll = new JScrollPane(text, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
					JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

				jf.add(scroll);
				jf.setVisible(true);

				// JPanel Panel = new JPanel();
				// JTextArea text = new JTextArea(content,18,30);
				// JTextArea text = new JTextArea(content);
				text.setFont(new Font("LucidaSans", Font.PLAIN, 14));

				int w = Toolkit.getDefaultToolkit().getScreenSize().width;
				int h = Toolkit.getDefaultToolkit().getScreenSize().height;
				jf.setSize(w, h);
				jf.pack();
				jf.setVisible(true);

			}
		};

	Action OpenJmol = new AbstractAction()
{
	private static final long serialVersionUID = 1L;

	public void actionPerformed(ActionEvent e)
    {
        int rowIsClicked = Integer.valueOf(e.getActionCommand());
        new ClickButton(rowIsClicked);
    }};

Action OpenPDBfile25 = new AbstractAction()
{
	private static final long serialVersionUID = 7L;

	public void actionPerformed(ActionEvent e)
    {
    int modelRow = Integer.valueOf(e.getActionCommand());
	Alignment A = result.myAlignments.get(modelRow);
	ArrayList<String> list_Input_resides= new ArrayList<String>();
	list_Input_resides.addAll(java.util.Arrays.asList(A.HitProteinResidues.split("\n")));
try{
	String pathPDB25 = A.path;
	String title = A.HitProteinID.trim().substring(0,4);
	String h="";//highlineResidue
	ArrayList<Residue> L=A.ListHitResidues;
	String chain = "";
	if(A.ListHitResidues.size()!=0)
	 chain = A.ListHitResidues.get(0).Chain_Name;
	else chain = "A";
	for(int i=0;i<L.size()-1;i++)   h=h+L.get(i).Residue_number+",";
									h=h+L.get(L.size()-1).Residue_number;

//String howJmol = "select ;spacefill off;wireframe off;cartoons on;select "+h+" colour green";
h="*"+chain+"&("+h+");" ;
					// String howJmol = "select ;spacefill off;wireframe off;cartoons on;select *:"+chain+";spacefill
					// off;wireframe off;cartoons on;colour chain; select "+h+" colour green";

					String howJmol = "select ;spacefill off;wireframe off;cartoons on;colour green";

							        
							        
							        
							        
	new OpenJmol(title).openPDBfile(pathPDB25,howJmol);	
} catch (Exception ex) {
 ex.printStackTrace();}
    }
};

		this.FinalTable = new ButtonColumn(table, OpenPDBfile25, seqAl, OpenJmol, 2, 10, 11);
        JFrame f = new JFrame();
        int n = this.result.pathFile.length();
		if (n>7)f.setTitle("Input Motif : "+this.result.pathFile.substring(n-8,n-4));
	JScrollPane scrollPane = new JScrollPane(this.FinalTable.table);

ButtonHeaderRenderer renderer = new ButtonHeaderRenderer();
     TableColumnModel model = table.getColumnModel();
    
 
     for (int i=4;i<10;i++) {
       model.getColumn(i).setHeaderRenderer(renderer);
     }

	JTableHeader header = table.getTableHeader(); 
        header.setBackground(Color.white); 
        header.setForeground(Color.black); 

    //header.setUpdateTableInRealTime(true);
    header.addMouseListener(tableModel.new MyColumnListener(this.FinalTable.table,header,renderer));
    
    //header.setReorderingAllowed(true);
    scrollPane.getViewport().add(this.FinalTable.table);
    f.add(scrollPane, BorderLayout.CENTER);
	f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	f.setSize(1200,600);
	int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 	int h = Toolkit.getDefaultToolkit().getScreenSize().height;
	f.setLocation((int)w/2 - 600,(int)h/2 - 300);
    f.setVisible(true);
    }
 
  class ClickButton {
	  int rowIsClicked;
	  ClickButton(int rowIsClicked){
		  this.rowIsClicked=rowIsClicked;
		  CreatFile creat =  new CreatFile();
		  creat.start();
		 try{ creat.join();}catch (Exception ex) {
			 ex.printStackTrace();}
		  new LoadFile().start();}
	  class CreatFile extends Thread {
	  public void run()
	    {
		  Alignment A = result.myAlignments.get(rowIsClicked);
			MT S = A.get_rotational_Matrix();
			Point O1 = A.center_of_inputResidues();
			Point O2 = A.center_of_HitResidues();
			ArrayList<String> list_InputResidues= new ArrayList<String>();
			list_InputResidues.addAll(java.util.Arrays
		.asList(A.InputResidues.split("\n")));
			ArrayList<String> list_HitResidues= new ArrayList<String>();
			list_HitResidues.addAll(java.util.Arrays
		.asList(A.HitProteinResidues.split("\n")));
			String inputChain = A.ListInputResidues.get(0).Chain_Name;
			String hitChain = A.ListHitResidues.get(0).Chain_Name;
			
		try{
		//	new Superpostion().Translation_Rotation(list_HitResidues,A.HitProteinID,O1,O2,S,result.pathFile,list_InputResidues,inputChain,hitChain,A.path);
					// new
					// Superpostion().Translation_Rotation(A.HitProteinID,O1,O2,S,result.pathFile,inputChain,hitChain,A.path);
					new Superpostion(A).Translation_Rotation(A.HitProteinID, O1, O2, S, result.pathFile, inputChain,
						hitChain, A.path);
		
		} catch (Exception ex) {
		 ex.printStackTrace();}
	    }}
	  class LoadFile extends Thread {
		  public void run()
		    {
			  try{
			Alignment A = result.myAlignments.get(rowIsClicked); 
			String title = A.InputProteinID+"_"+A.HitProteinID.trim().substring(0,4);
					String path = "OutputFiles" + File.separator + "SuperPosition.pdb";
			String conser1="";//highlineResidue
			String conser2="";//highlineResidue
			String NOTconser1="";//highlineResidue
			String NOTconser2="";//highlineResidue
			ArrayList<Residue> L1=A.ListInputResidues;
			ArrayList<Residue> L2=A.ListHitResidues;
			for(int i=0;i<L1.size()-1;i++)  { 
				if(L1.get(i).Residue_Name.compareTo(L2.get(i).Residue_Name)==0)
				{
					conser1=conser1+L1.get(i).Residue_number+",";
					conser2=conser2+L2.get(i).Residue_number+",";
				}
				
				else{
					NOTconser1=NOTconser1+L1.get(i).Residue_number+",";
					NOTconser2=NOTconser2+L2.get(i).Residue_number+",";
				}
			}
			
			if(L1.get(L1.size()-1).Residue_Name.compareTo(L2.get(L2.size()-1).Residue_Name)==0)
			{
				conser1=conser1+L1.get(L1.size()-1).Residue_number;
				conser2=conser2+L2.get(L2.size()-1).Residue_number;
				
				
				NOTconser1=NOTconser1.substring(0,NOTconser1.length()-1);
				NOTconser2=NOTconser2.substring(0,NOTconser2.length()-1);
			}
			
			else{
				conser1=conser1.substring(0,conser1.length()-1);
				conser2=conser2.substring(0,conser2.length()-1);
				NOTconser1=NOTconser1+L1.get(L1.size()-1).Residue_number;
				NOTconser2=NOTconser2+L2.get(L2.size()-1).Residue_number;
			}
			
			conser1="*z&("+conser1+");" ;
			String chain=L2.get(0).Chain_Name;
			
			conser2="*"+chain+"&("+conser2+");" ;
					// String howJmol = "select ;spacefill off;wireframe off;cartoons off;trace on;color green;select
					// "+conser1+" colour red;select "+conser2+"color red";
					String howJmol = "select ;spacefill off;wireframe off;cartoons on;color green;select *z; color temperature";
					// String howJmol = "select ;spacefill off;wireframe off;cartoons on;colour temperature";
			new OpenJmol(title).openPDBfile(path,howJmol);
			  }catch (Exception ex) {
					 ex.printStackTrace();}
			}}
  }  
}

class CustomEditor implements TableCellEditor
{
    JTextArea textArea;
    public CustomEditor()
    {
        textArea = new JTextArea();
    }
 
    public Component getTableCellEditorComponent(JTable table,
                                                 Object value,
                                                 boolean isSelected,
                                                 int row, int column)
    {
     textArea.setText((String)value);
	 return textArea;
    }
 
    public void addCellEditorListener(CellEditorListener l) { }
    public void cancelCellEditing() { }
    public Object getCellEditorValue()
    {
        return textArea.getText();
    }
    public boolean isCellEditable(EventObject anEvent)
    {
        return false;
    }
    public void removeCellEditorListener(CellEditorListener l) { }
    public boolean shouldSelectCell(EventObject anEvent)
    {
        return true;
    }
    public boolean stopCellEditing()
    {
        return true;
    }
}

 
class CustomRenderer implements TableCellRenderer
// format column 3,4
{
    //JScrollPane scrollPane;
    JTextPane textArea;
 
    public CustomRenderer()
    {
        textArea = new JTextPane();
      //  scrollPane = new JScrollPane(textArea);
    }
 
	public boolean isCellEditable(EventObject anEvent)
    {
        return false;
    }
    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row, int column)
    {
	

    
    	
 //if (column == 4||column == 5||column == 3) 
textArea.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.orange)); 
textArea.setText((String)value);
javax.swing.text.StyledDocument doc = textArea.getStyledDocument(); 
javax.swing.text.SimpleAttributeSet
center = new javax.swing.text.SimpleAttributeSet
(); 
javax.swing.text.StyleConstants.setAlignment(center,javax.swing.text.StyleConstants.ALIGN_CENTER); 
doc.setParagraphAttributes(0, doc.getLength(), center, false); 
	Font font = new Font("Verdana", Font.BOLD, 12);
	textArea.setFont(font);
	textArea.setForeground(Color.blue);
	
	if(row%2==0) textArea.setBackground (Color.gray);               
        else  textArea.setBackground(Color.white);
	textArea.setEditable(false); 
        return textArea;
    }
public boolean stopCellEditing()
    {
        return true;
    }
}
 

class CustomRenderer1 implements TableCellRenderer
{// format column 0,1,2,5,6,7
  
    JTextField text;
    public CustomRenderer1()
    {
        text = new JTextField();
    }
	public boolean isCellEditable(EventObject anEvent)
    {
        return false;
    }

    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row, int column)
    {
   /* if (column == 2)	{String t=(String)value;String s=t.substring(0,4)+"   >>";text.setText(s);} 
    else text.setText((String)value);*/
    text.setText((String)value);	
	Font font = new Font("Verdana", Font.BOLD, 12);
	text.setFont(font);
	text.setForeground(Color.blue);
	text.setHorizontalAlignment(SwingConstants.CENTER); 

	if(row%2==0)	text.setBackground (Color.gray);                
        else		text.setBackground(Color.white);    
        return text;
    }
}


class Extract {// get only subset active site residue from original enzyme PDBfile
	Extract(){};
	
	public ArrayList<String> get_subset_residue_from_original_PDBfile(String InputFilePath,ArrayList<String>list_resides)throws Exception{
		ArrayList<String>myList = new ArrayList<String>();
		Scanner in=new Scanner(new FileInputStream(InputFilePath)); 
	boolean read_more = true; 
	    while((in.hasNextLine())&&(read_more)){
		String line=in.nextLine(); 
		if((line.startsWith("ATOM"))||(line.startsWith("HETATM"))){ 
			String r4=line.substring(17,20);//residue name
			String r6=line.substring(21,22);//chain name
			String r7=line.substring(22,26);//residue number 
			if(r4.compareTo("MO3")==0) r4="MG";
			if((r4.compareTo("FE1")==0)||(r4.compareTo("FE2")==0)) r4="FE";
			if((r4.compareTo("CU1")==0)||(r4.compareTo("CUA")==0)) r4="CU";
			if((r4.compareTo("ZNO")==0)||(r4.compareTo("ZN1")==0)) r4="ZN";
				String s =r4.trim()+" "+r7.trim()+" "+r6;
for(int i=0;i<list_resides.size();i++){
if ((list_resides.get(i).trim().compareTo(s.trim())==0)){myList.add(line);break;}}
		}
else if ((line.startsWith("END"))) read_more = false;
		} in.close();return myList;}	


	}














 class CoreAlgorismModule{
	MT S5;
	 int STRUCTURElevel=2;// backbone
	String InputMotifPDBcode;
	String path_file;
	String  KnownPath;
	double minTMscore;
	HashMap<String,String> PDBcodeVSfunction;
	ArrayList<Residue2> ListResidues2;
	ArrayList<ArrayList<Residue>> listListResidue;
	HashMap<String,Integer> ResidueName;
	HashMap<String,Integer> polarity;
	HashMap<String,Integer> residue_position;
	int[] SSE;
	boolean has; //true if there is helix and sheet field from pdb file otherwise program will calculate SSE assignment
	int[][] Ori_CLESUM_WS = {{73, 20, 13, -17, -25, -20, -6, -45, -31, -23, -19, -11, -2, 10, 25, 35, 16, 0}, // A
		{20, 51, 7, 13, 15, 7, 13, -96, -74, -57, -50, -12, -13, -11, -12, 42, 12, 0}, // B
		{13, 7, 53, 21, 3, 20, -4, -77, -56, -43, -33, 0, -12, -5, 3, 4, 29, 0}, // C
		{-17, 13, 21, 52, 22, 22, -31, -124, -105, -88, -81, -22, -49, -44, -42, -10, 14, 0}, // D
		{-25, 15, 3, 22, 36, 26, -22, -127, -108, -93, -84, -21, -47, -43, -48, -5, -6, 0}, // E
		{-20, 7, 20, 22, 26, 50, -5, -107, -88, -73, -69, -16, -33, -32, -30, 0, 3, 0}, // F
		{-6, 13, -4, -31, -22, -5, 69, -51, -34, -21, -13, 29, 21, -8, -1, 5, 8, 0}, // G
		{-45, -96, -77, -124, -127, -107, -51, 23, 18, 13, 5, -62, -4, -34, -55, -60, -87, 0}, // H
		{-31, -74, -56, -105, -108, -88, -34, 18, 23, 16, 21, -41, 1, -11, -34, -49, -62, 0}, // I
		{-23, -57, -43, -88, -93, -73, -21, 13, 16, 37, 13, -32, 16, -2, -24, -34, -44, 0}, // J
		{-19, -50, -33, -81, -84, -69, -13, 5, 21, 13, 49, -1, 12, 28, 5, -36, -24, 0}, // K
		{-11, -12, 0, -22, -21, -16, 29, -62, -41, -32, -1, 74, 5, 8, -4, -12, 26, 0}, // L
		{-2, -13, -12, -49, -47, -33, 21, -4, 1, 16, 12, 5, 61, 7, 5, 8, -7, 0}, // M
		{10, -11, -5, -44, -43, -32, -8, -34, -11, -2, 28, 8, 7, 90, 15, -3, 32, 0}, // N
		{25, -12, 3, -42, -48, -30, -1, -55, -34, -24, 5, -4, 5, 15, 104, 4, -13, 0}, // O
		{35, 42, 4, -10, -5, 0, 5, -60, -49, -34, -36, -12, 8, -3, 4, 66, 7, 0}, // P
		{16, 12, 29, 14, -6, 3, 8, -87, -62, -44, -24, 26, -7, 32, -13, 7, 90, 0}, // Q
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};// R
	// A B C D E F G H I J K L M N O P Q R
	int[][] Ori_BLOSUM_62 = {{4, -1, -2, -2, 0, -1, -1, 0, -2, -1, -1, -1, -1, -2, -1, 1, 0, -3, -2, 0, -5}, // A
		{-1, 5, 0, -2, -3, 1, 0, -2, 0, -3, -2, 2, -1, -3, -2, -1, -1, -3, -2, -3, -5}, // R
		{-2, 0, 6, 1, -3, 0, 0, 0, 1, -3, -3, 0, -2, -3, -2, 1, 0, -4, -2, -3, -5}, // N
		{-2, -2, 1, 6, -3, 0, 2, -1, -1, -3, -4, -1, -3, -3, -1, 0, -1, -4, -3, -3, -5}, // D
		{0, -3, -3, -3, 9, -3, -4, -3, -3, -1, -1, -3, -1, -2, -3, -1, -1, -2, -2, -1, -5}, // C
		{-1, 1, 0, 0, -3, 5, 2, -2, 0, -3, -2, 1, 0, -3, -1, 0, -1, -2, -1, -2, -5}, // Q
		{-1, 0, 0, 2, -4, 2, 5, -2, 0, -3, -3, 1, -2, -3, -1, 0, -1, -3, -2, -2, -5}, // E
		{0, -2, 0, -1, -3, -2, -2, 6, -2, -4, -4, -2, -3, -3, -2, 0, -2, -2, -3, -3, -5}, // G
		{-2, 0, 1, -1, -3, 0, 0, -2, 8, -3, -3, -1, -2, -1, -2, -1, -2, -2, 2, -3, -5}, // H
		{-1, -3, -3, -3, -1, -3, -3, -4, -3, 4, 2, -3, 1, 0, -3, -2, -1, -3, -1, 3, -5}, // I
		{-1, -2, -3, -4, -1, -2, -3, -4, -3, 2, 4, -2, 2, 0, -3, -2, -1, -2, -1, 1, -5}, // L
		{-1, 2, 0, -1, -3, 1, 1, -2, -1, -3, -2, 5, -1, -3, -1, 0, -1, -3, -2, -2, -5}, // K
		{-1, -1, -2, -3, -1, 0, -2, -3, -2, 1, 2, -1, 5, 0, -2, -1, -1, -1, -1, 1, -5}, // M
		{-2, -3, -3, -3, -2, -3, -3, -3, -1, 0, 0, -3, 0, 6, -4, -2, -2, 1, 3, -1, -5}, // F
		{-1, -2, -2, -1, -3, -1, -1, -2, -2, -3, -3, -1, -2, -4, 7, -1, -1, -4, -3, -2, -5}, // P
		{1, -1, 1, 0, -1, 0, 0, 0, -1, -2, -2, 0, -1, -2, -1, 4, 1, -3, -2, -2, -5}, // S
		{0, -1, 0, -1, -1, -1, -1, -2, -2, -1, -1, -1, -1, -2, -1, 1, 5, -2, -2, 0, -5}, // T
		{-3, -3, -4, -4, -2, -2, -3, -2, -2, -3, -2, -3, -1, 1, -4, -3, -2, 11, 2, -3, -5}, // W
		{-2, -2, -2, -3, -2, -1, -2, -3, 2, -1, -1, -2, -1, 3, -3, -2, -2, 2, 7, -1, -5}, // Y
		{0, -3, -3, -3, -1, -2, -2, -3, -3, 3, 1, -2, 1, -1, -2, -2, 0, -3, -1, 4, -5}, // V
		{-5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5}}; // Z
	// A R N D C Q E G H I L K M F P S T W Y V Z

	int[][] Ori_BLOSUM_45 = {{5, -2, -1, -2, -1, -1, -1, 0, -2, -1, -1, -1, -1, -2, -1, 1, 0, -2, -2, 0, -5}, // A
		{-2, 7, 0, -1, -3, 1, 0, -2, 0, -3, -2, 3, -1, -2, -2, -1, -1, -2, -1, -2, -5}, // R
		{-1, 0, 6, 2, -2, 0, 0, 0, 1, -2, -3, 0, -2, -2, -2, 1, 0, -4, -2, -3, -5}, // N
		{-2, -1, 2, 7, -3, 0, 2, -1, 0, -4, -3, 0, -3, -4, -1, 0, -1, -4, -2, -3, -5}, // D
		{-1, -3, -2, -3, 12, -3, -3, -3, -3, -3, -2, -3, -2, -2, -4, -1, -1, -5, -3, -1, -5}, // C
		{-1, 1, 0, 0, -3, 6, 2, -2, 1, -2, -2, 1, 0, -4, -1, 0, -1, -2, -1, -3, -5}, // Q
		{-1, 0, 0, 2, -3, 2, 6, -2, 0, -3, -2, 1, -2, -3, 0, 0, -1, -3, -2, -3, -5}, // E
		{0, -2, 0, -1, -3, -2, -2, 7, -2, -4, -3, -2, -2, -3, -2, 0, -2, -2, -3, -3, -5}, // G
		{-2, 0, 1, 0, -3, 1, 0, -2, 10, -3, -2, -1, 0, -2, -2, -1, -2, -3, 2, -3, -5}, // H
		{-1, -3, -2, -4, -3, -2, -3, -4, -3, 5, 2, -3, 2, 0, -2, -2, -1, -2, 0, 3, -5}, // I
		{-1, -2, -3, -3, -2, -2, -2, -3, -2, 2, 5, -3, 2, 1, -3, -3, -1, -2, 0, 1, -5}, // L
		{-1, 3, 0, 0, -3, 1, 1, -2, -1, -3, -3, 5, -1, -3, -1, -1, -1, -2, -1, -2, -5}, // K
		{-1, -1, -2, -3, -2, 0, -2, -2, 0, 2, 2, -1, 6, 0, -2, -2, -1, -2, 0, 1, -5}, // M
		{-2, -2, -2, -4, -2, -4, -3, -3, -2, 0, 1, -3, 0, 8, -3, -2, -1, 1, 3, 0, -5}, // F
		{-1, -2, -2, -1, -4, -1, 0, -2, -2, -2, -3, -1, -2, -3, 9, -1, -1, -3, -3, -3, -5}, // P
		{1, -1, 1, 0, -1, 0, 0, 0, -1, -2, -3, -1, -2, -2, -1, 4, 2, -4, -2, -1, -5}, // S
		{0, -1, 0, -1, -1, -1, -1, -2, -2, -1, -1, -1, -1, -1, -1, 2, 5, -3, -1, 0, -5}, // T
		{-2, -2, -4, -4, -5, -2, -3, -2, -3, -2, -2, -2, -2, 1, -3, -4, -3, 15, 3, -3, -5}, // W
		{-2, -1, -2, -2, -3, -1, -2, -3, 2, 0, 0, -1, 0, 3, -3, -2, -1, 3, 8, -1, -5}, // Y
		{0, -2, -3, -3, -1, -3, -3, -3, -3, 3, 1, -2, 1, 0, -3, -1, 0, -3, -1, 5, -5}, // V
		{-5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5}}; // Z
	// A R N D C Q E G H I L K M F P S T W Y V Z

	// BLOSUM_Mapping//--------------ARNDCQEGHILKMFPSTWYVZ
	int[] Blo_AA_Map_WS = {0, 19, 4, 3, 6, 13, 7, 8, 9, 17, 11, 10, 12, 2, 18, 14, 5, 1, 15, 16, 20};
	// A V C D E F G H I W K L M N Y P Q R S T Z
	// 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
	// Ori_Mapping//-----------------AVCDEFGHIWKLMNYPQRSTZ
	int[] Ori_AA_Map_WS = {0, 20, 2, 3, 4, 5, 6, 7, 8, 20, 10, 11, 12, 13, 20, 15, 16, 17, 18, 19, 20, 1, 9, 20, 14,
		20};

	// A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
	// 0 1 2 3 4 5 6 7 8 9 10 11 12 14 14 15 16 17 18 19 20 21 22 23 24 25
	char WWW_Three2One_III(String input) {
		int i;
		int len;
		int result;
		// encoding
		len = input.length();
		if (len != 3)
			return 'X';
		result = 0;
		for (i = 0; i < len; i++)
			result += (input.charAt(i) - 'A') * (int) Math.pow(1.0 * 26, 1.0 * i);
		// switch
		switch (result) {
			case 286:
				return 'A';
			case 4498:
				return 'R';
			case 9256:
				return 'N';
			case 10608:
				return 'D';
			case 12794:
				return 'C';
			case 9080:
				return 'Q';
			case 13812:
				return 'E';
			case 16516:
				return 'G';
			case 12383:
				return 'H';
			case 2998:
				return 'I';
			case 13635:
				return 'L';
			case 12803:
				return 'K';
			case 12960:
				return 'M';
			case 2901:
				return 'F';
			case 9921:
				return 'P';
			case 11614:
				return 'S';
			case 11693:
				return 'T';
			case 10601:
				return 'W';
			case 12135:
				return 'Y';
			case 7457:
				return 'V';
			default:
				return 'X';
		}
	}
		
	public CoreAlgorismModule(String KnownPath,String InputMotifPDBcode,String path_file,double minTMscore)throws Exception{
		
		this.KnownPath=KnownPath;
		this.minTMscore=minTMscore;
		this.InputMotifPDBcode= InputMotifPDBcode;
		this.path_file = path_file;
		//this.has=this.hasHELIXSHEETinPDBfile();
		this.has = false;
		this.polarity = new HashMap<String,Integer>();
		fill_hashmap();
		this.ResidueName = new HashMap<String,Integer>();
		fill_hashmap2();
		this.residue_position = new HashMap<String,Integer>();
		fill_hashmap3();
		
		// this.ListResidues= new ArrayList<Residue>();
		if(this.has==true){
			this.listListResidue = this.get_list_all_residues_from_PDBfile(path_file, this.InputMotifPDBcode);
			// this.ListResidues= ls.get(0);
		}
		else {
		ArrayList<ArrayList<Residue2>> ls =this.get_list_all_residues_from_PDBfile2(path_file,this.InputMotifPDBcode);
			this.listListResidue = new ArrayList<ArrayList<Residue>>();
			for (int k = 0; k < ls.size(); k++) {
				ArrayList<Residue2> listRes2 = ls.get(k);
				int n = listRes2.size();
				int[] SSE = new int[n];
				ArrayList<Residue> listRes = new ArrayList<Residue>(n);
				SSE = this.correctSSElabel(listRes2);
		for(int i=0;i<n;i++) {
					Residue2 R = listRes2.get(i);
			int polarit= this.polarity.get(R.Residue_Name);
					int label = SSE[i];
					listRes.add(new Residue(R, label, polarit));
				}
				this.listListResidue.add(listRes);
			}
		

		
		}


	}

	int BlosSum62Score(ArrayList<Residue> hit, ArrayList<Residue> input) {

		int sum = 0;
		for (int i = 0; i < hit.size(); i++) {
			char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
			char b = this.WWW_Three2One_III(input.get(i).Residue_Name);
			sum = sum + this.BLOSUM62_Calc(a, b); // this.BLOSUM45_Calc(a, b);

		}
		return sum;
	}

	int BlosSum45Score(ArrayList<Residue> hit, ArrayList<Residue> input) {

		int sum = 0;
		for (int i = 0; i < hit.size(); i++) {
			char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
			char b = this.WWW_Three2One_III(input.get(i).Residue_Name);
			sum = sum + this.BLOSUM45_Calc(a, b);
		}
		return sum;
	}
	int BLOSUM62_Calc(char a, char b) {
		int ii, jj;
		if (a < 'A' || a > 'Z')
			a = 'Z';
		ii = Blo_AA_Map_WS[Ori_AA_Map_WS[a - 'A']];
		if (b < 'A' || b > 'Z')
			b = 'Z';
		jj = Blo_AA_Map_WS[Ori_AA_Map_WS[b - 'A']];
		return Ori_BLOSUM_62[ii][jj];
	}

	int BLOSUM45_Calc(char a, char b) {
		int ii, jj;
		if (a < 'A' || a > 'Z')
			a = 'Z';
		ii = Blo_AA_Map_WS[Ori_AA_Map_WS[a - 'A']];
		if (b < 'A' || b > 'Z')
			b = 'Z';
		jj = Blo_AA_Map_WS[Ori_AA_Map_WS[b - 'A']];
		return Ori_BLOSUM_45[ii][jj];
	}

	int CLESUM_Calc(char a, char b) {
		if (a < 'A' || a > 'R')
			a = 'R';
		if (b < 'A' || b > 'R')
			b = 'R';
		return Ori_CLESUM_WS[a - 'A'][b - 'A'];
	}

	void print(){
		 /*
		 Scanner in=new Scanner(new FileInputStream("2NYB.pdb"));
		 PrintWriter out =new PrintWriter(new FileOutputStream("newFile.pdb"));

		    while((in.hasNextLine())){
			String line=in.nextLine(); 
	if(line.startsWith("ATOM")) {
				String r6=line.substring(22,27).trim();
				String r5=line.substring(21,22);
				if(r5.compareTo("A")==0){
			if(r6.compareTo("26")==0||r6.compareTo("34")==0||r6.compareTo("69")==0
					||r6.compareTo("73")==0||r6.compareTo("156")==0||r6.compareTo("158")==0||r6.compareTo("160")==0
					||r6.compareTo("189")==0) out.println(line); 
		
	} }} out.println("END"); out.close();
		 
		 */
	}
	
	public MT get_substitution_Matrix(){
		MT S=new MT(20,20);
S.data[0][0]=9.0;S.data[0][1]=-1.0;S.data[0][2]=-1.0;S.data[0][3]=-3.0;S.data[0][4]=0.0;S.data[0][5]=-3.0;S.data[0][6]=-3.0;S.data[0][7]=-3.0;S.data[0][8]=-4.0;S.data[0][9]=-3.0;S.data[0][10]=-3.0;S.data[0][11]=-3.0;S.data[0][12]=-3.0;S.data[0][13]=-1.0;S.data[0][14]=-1.0;S.data[0][15]=-1.0;S.data[0][16]=-1.0;S.data[0][17]=-2.0;S.data[0][18]=-2.0;S.data[0][19]=-2.0;S.data[1][0]=-1.0;S.data[1][1]=4.0;S.data[1][2]=1.0;S.data[1][3]=-1.0;S.data[1][4]=1.0;S.data[1][5]=0.0;S.data[1][6]=1.0;S.data[1][7]=0.0;S.data[1][8]=0.0;S.data[1][9]=0.0;S.data[1][10]=-1.0;S.data[1][11]=-1.0;S.data[1][12]=0.0;S.data[1][13]=-1.0;S.data[1][14]=-2.0;S.data[1][15]=-2.0;S.data[1][16]=-2.0;S.data[1][17]=-2.0;S.data[1][18]=-2.0;S.data[1][19]=-3.0;S.data[2][0]=-1.0;S.data[2][1]=1.0;S.data[2][2]=4.0;S.data[2][3]=1.0;S.data[2][4]=-1.0;S.data[2][5]=1.0;S.data[2][6]=0.0;S.data[2][7]=1.0;S.data[2][8]=0.0;S.data[2][9]=0.0;S.data[2][10]=0.0;S.data[2][11]=-1.0;S.data[2][12]=0.0;S.data[2][13]=-1.0;S.data[2][14]=-2.0;S.data[2][15]=-2.0;S.data[2][16]=-2.0;S.data[2][17]=-2.0;S.data[2][18]=-2.0;S.data[2][19]=-3.0;S.data[3][0]=-3.0;S.data[3][1]=-1.0;S.data[3][2]=1.0;S.data[3][3]=7.0;S.data[3][4]=-1.0;S.data[3][5]=-2.0;S.data[3][6]=-1.0;S.data[3][7]=-1.0;S.data[3][8]=-1.0;S.data[3][9]=-1.0;S.data[3][10]=-2.0;S.data[3][11]=-2.0;S.data[3][12]=-1.0;S.data[3][13]=-2.0;S.data[3][14]=-3.0;S.data[3][15]=-3.0;S.data[3][16]=-2.0;S.data[3][17]=-4.0;S.data[3][18]=-3.0;S.data[3][19]=-4.0;S.data[4][0]=0.0;S.data[4][1]=1.0;S.data[4][2]=-1.0;S.data[4][3]=-1.0;S.data[4][4]=4.0;S.data[4][5]=0.0;S.data[4][6]=-1.0;S.data[4][7]=-2.0;S.data[4][8]=-1.0;S.data[4][9]=-1.0;S.data[4][10]=-2.0;S.data[4][11]=-1.0;S.data[4][12]=-1.0;S.data[4][13]=-1.0;S.data[4][14]=-1.0;S.data[4][15]=-1.0;S.data[4][16]=-2.0;S.data[4][17]=-2.0;S.data[4][18]=-2.0;S.data[4][19]=-3.0;S.data[5][0]=-3.0;S.data[5][1]=0.0;S.data[5][2]=1.0;S.data[5][3]=-2.0;S.data[5][4]=0.0;S.data[5][5]=6.0;S.data[5][6]=-2.0;S.data[5][7]=-1.0;S.data[5][8]=-2.0;S.data[5][9]=-2.0;S.data[5][10]=-2.0;S.data[5][11]=-2.0;S.data[5][12]=-2.0;S.data[5][13]=-3.0;S.data[5][14]=-4.0;S.data[5][15]=-4.0;S.data[5][16]=0.0;S.data[5][17]=-3.0;S.data[5][18]=-3.0;S.data[5][19]=-2.0;S.data[6][0]=-3.0;S.data[6][1]=1.0;S.data[6][2]=0.0;S.data[6][3]=-2.0;S.data[6][4]=-2.0;S.data[6][5]=0.0;S.data[6][6]=6.0;S.data[6][7]=1.0;S.data[6][8]=0.0;S.data[6][9]=0.0;S.data[6][10]=-1.0;S.data[6][11]=0.0;S.data[6][12]=0.0;S.data[6][13]=-2.0;S.data[6][14]=-3.0;S.data[6][15]=-3.0;S.data[6][16]=-3.0;S.data[6][17]=-3.0;S.data[6][18]=-2.0;S.data[6][19]=-4.0;S.data[7][0]=-3.0;S.data[7][1]=0.0;S.data[7][2]=1.0;S.data[7][3]=-1.0;S.data[7][4]=-2.0;S.data[7][5]=-1.0;S.data[7][6]=1.0;S.data[7][7]=6.0;S.data[7][8]=2.0;S.data[7][9]=0.0;S.data[7][10]=-1.0;S.data[7][11]=-2.0;S.data[7][12]=-1.0;S.data[7][13]=-3.0;S.data[7][14]=-3.0;S.data[7][15]=-4.0;S.data[7][16]=-3.0;S.data[7][17]=-3.0;S.data[7][18]=-3.0;S.data[7][19]=-4.0;S.data[8][0]=-4.0;S.data[8][1]=0.0;S.data[8][2]=0.0;S.data[8][3]=-1.0;S.data[8][4]=-1.0;S.data[8][5]=-2.0;S.data[8][6]=0.0;S.data[8][7]=2.0;S.data[8][8]=5.0;S.data[8][9]=2.0;S.data[8][10]=0.0;S.data[8][11]=0.0;S.data[8][12]=1.0;S.data[8][13]=-2.0;S.data[8][14]=-3.0;S.data[8][15]=-3.0;S.data[8][16]=-3.0;S.data[8][17]=-3.0;S.data[8][18]=-2.0;S.data[8][19]=-3.0;S.data[9][0]=-3.0;S.data[9][1]=0.0;S.data[9][2]=0.0;S.data[9][3]=-1.0;S.data[9][4]=-1.0;S.data[9][5]=-2.0;S.data[9][6]=0.0;S.data[9][7]=0.0;S.data[9][8]=2.0;S.data[9][9]=5.0;S.data[9][10]=0.0;S.data[9][11]=1.0;S.data[9][12]=1.0;S.data[9][13]=0.0;S.data[9][14]=-3.0;S.data[9][15]=-2.0;S.data[9][16]=-2.0;S.data[9][17]=-3.0;S.data[9][18]=-1.0;S.data[9][19]=-2.0;S.data[10][0]=-3.0;S.data[10][1]=-1.0;S.data[10][2]=0.0;S.data[10][3]=-2.0;S.data[10][4]=-2.0;S.data[10][5]=-2.0;S.data[10][6]=1.0;S.data[10][7]=1.0;S.data[10][8]=0.0;S.data[10][9]=0.0;S.data[10][10]=8.0;S.data[10][11]=0.0;S.data[10][12]=-1.0;S.data[10][13]=-2.0;S.data[10][14]=-3.0;S.data[10][15]=-3.0;S.data[10][16]=-2.0;S.data[10][17]=-1.0;S.data[10][18]=2.0;S.data[10][19]=-2.0;S.data[11][0]=-3.0;S.data[11][1]=-1.0;S.data[11][2]=-1.0;S.data[11][3]=-2.0;S.data[11][4]=-1.0;S.data[11][5]=-2.0;S.data[11][6]=0.0;S.data[11][7]=-2.0;S.data[11][8]=0.0;S.data[11][9]=1.0;S.data[11][10]=0.0;S.data[11][11]=5.0;S.data[11][12]=2.0;S.data[11][13]=-1.0;S.data[11][14]=-3.0;S.data[11][15]=-2.0;S.data[11][16]=-3.0;S.data[11][17]=-3.0;S.data[11][18]=-2.0;S.data[11][19]=-3.0;S.data[12][0]=-3.0;S.data[12][1]=0.0;S.data[12][2]=0.0;S.data[12][3]=-1.0;S.data[12][4]=-1.0;S.data[12][5]=-2.0;S.data[12][6]=0.0;S.data[12][7]=-1.0;S.data[12][8]=1.0;S.data[12][9]=1.0;S.data[12][10]=-1.0;S.data[12][11]=2.0;S.data[12][12]=5.0;S.data[12][13]=-1.0;S.data[12][14]=-3.0;S.data[12][15]=-2.0;S.data[12][16]=-3.0;S.data[12][17]=-3.0;S.data[12][18]=-2.0;S.data[12][19]=-3.0;S.data[13][0]=-1.0;S.data[13][1]=-1.0;S.data[13][2]=-1.0;S.data[13][3]=-2.0;S.data[13][4]=-1.0;S.data[13][5]=-3.0;S.data[13][6]=-2.0;S.data[13][7]=-3.0;S.data[13][8]=-2.0;S.data[13][9]=0.0;S.data[13][10]=-2.0;S.data[13][11]=-1.0;S.data[13][12]=-1.0;S.data[13][13]=5.0;S.data[13][14]=1.0;S.data[13][15]=2.0;S.data[13][16]=-2.0;S.data[13][17]=0.0;S.data[13][18]=-1.0;S.data[13][19]=-1.0;S.data[14][0]=-1.0;S.data[14][1]=-2.0;S.data[14][2]=-2.0;S.data[14][3]=-3.0;S.data[14][4]=-1.0;S.data[14][5]=-4.0;S.data[14][6]=-3.0;S.data[14][7]=-3.0;S.data[14][8]=-3.0;S.data[14][9]=-3.0;S.data[14][10]=-3.0;S.data[14][11]=-3.0;S.data[14][12]=-3.0;S.data[14][13]=1.0;S.data[14][14]=4.0;S.data[14][15]=2.0;S.data[14][16]=1.0;S.data[14][17]=0.0;S.data[14][18]=-1.0;S.data[14][19]=-3.0;S.data[15][0]=-1.0;S.data[15][1]=-2.0;S.data[15][2]=-2.0;S.data[15][3]=-3.0;S.data[15][4]=-1.0;S.data[15][5]=-4.0;S.data[15][6]=-3.0;S.data[15][7]=-4.0;S.data[15][8]=-3.0;S.data[15][9]=-2.0;S.data[15][10]=-3.0;S.data[15][11]=-2.0;S.data[15][12]=-2.0;S.data[15][13]=2.0;S.data[15][14]=2.0;S.data[15][15]=4.0;S.data[15][16]=3.0;S.data[15][17]=0.0;S.data[15][18]=-1.0;S.data[15][19]=-2.0;S.data[16][0]=-1.0;S.data[16][1]=-2.0;S.data[16][2]=-2.0;S.data[16][3]=-2.0;S.data[16][4]=0.0;S.data[16][5]=-3.0;S.data[16][6]=-3.0;S.data[16][7]=-3.0;S.data[16][8]=-2.0;S.data[16][9]=-2.0;S.data[16][10]=-3.0;S.data[16][11]=-3.0;S.data[16][12]=-2.0;S.data[16][13]=1.0;S.data[16][14]=3.0;S.data[16][15]=1.0;S.data[16][16]=4.0;S.data[16][17]=-1.0;S.data[16][18]=-1.0;S.data[16][19]=-3.0;S.data[17][0]=-2.0;S.data[17][1]=-2.0;S.data[17][2]=-2.0;S.data[17][3]=-4.0;S.data[17][4]=-2.0;S.data[17][5]=-3.0;S.data[17][6]=-3.0;S.data[17][7]=-3.0;S.data[17][8]=-3.0;S.data[17][9]=-3.0;S.data[17][10]=-1.0;S.data[17][11]=-3.0;S.data[17][12]=-3.0;S.data[17][13]=0.0;S.data[17][14]=0.0;S.data[17][15]=0.0;S.data[17][16]=-1.0;S.data[17][17]=6.0;S.data[17][18]=3.0;S.data[17][19]=1.0;S.data[18][0]=-2.0;S.data[18][1]=-2.0;S.data[18][2]=-2.0;S.data[18][3]=-3.0;S.data[18][4]=-2.0;S.data[18][5]=-3.0;S.data[18][6]=-2.0;S.data[18][7]=-3.0;S.data[18][8]=-2.0;S.data[18][9]=-1.0;S.data[18][10]=2.0;S.data[18][11]=-2.0;S.data[18][12]=-2.0;S.data[18][13]=-1.0;S.data[18][14]=-1.0;S.data[18][15]=-1.0;S.data[18][16]=-1.0;S.data[18][17]=3.0;S.data[18][18]=7.0;S.data[18][19]=2.0;S.data[19][0]=-2.0;S.data[19][1]=-3.0;S.data[19][2]=-3.0;S.data[19][3]=-4.0;S.data[19][4]=-3.0;S.data[19][5]=-2.0;S.data[19][6]=-4.0;S.data[19][7]=-4.0;S.data[19][8]=-3.0;S.data[19][9]=-2.0;S.data[19][10]=-2.0;S.data[19][11]=-3.0;S.data[19][12]=-3.0;S.data[19][13]=-1.0;S.data[19][14]=-3.0;S.data[19][15]=-2.0;S.data[19][16]=-3.0;S.data[19][17]=1.0;S.data[19][18]=2.0;S.data[19][19]=11.0;
 		return S;}
	
	
	boolean Identity(Residue R1,Residue R2){
		try {
		 int x1=this.ResidueName.get(R1.Residue_Name);
		 int x2=this.ResidueName.get(R2.Residue_Name);
		 
		 if(x1==x2){
			 return true;}
		 else return false; 
		}catch(Exception e){
			 return false;}
	 			}
	
	ArrayList<Residue> getListRfromR2(ArrayList<Residue2>ListResidues2){
	ArrayList<Residue>ListResidues =  new ArrayList<Residue>();
	int n = ListResidues2.size();
	int[]SSE=this.correctSSElabel(ListResidues2);
	for(int i=0;i<n;i++) {
		Residue2 R = ListResidues2.get(i);
		int polarit= this.polarity.get(R.Residue_Name);
		int label= SSE[i];
		ListResidues.add(new Residue(R,label,polarit));
	}
	return ListResidues; }
	
	ArrayList<ArrayList<Residue>> getListListResiduefromListlistResidue2(ArrayList<ArrayList<Residue2>>ListlistRe2){
		ArrayList<ArrayList<Residue>>ListlistRe =  new ArrayList<ArrayList<Residue>>(ListlistRe2.size());
		for(int i=0;i<ListlistRe2.size();i++)
		 {
			ListlistRe.add(this.getListRfromR2(ListlistRe2.get(i)));
		}
		return ListlistRe; }

	void test() throws Exception{
		ArrayList<Residue> ListResidues = this.listListResidue.get(0);
		String chain = ListResidues.get(0).Chain_Name;
	String h="";
		for (int i = 0; i < ListResidues.size(); i++) {
			Residue R = ListResidues.get(i);
		if(R.label==1) {
		h=h+R.Residue_number+",";
		}
				}
								
h=h.substring(0,h.length()-1);
//String howJmol = "select ;spacefill off;wireframe off;cartoons on;select "+h+" colour green";
h="*"+chain+"&("+h+");" ;
String howJmol = "select ;spacefill off;wireframe off;cartoons on;select *:"+chain+";spacefill off;wireframe off;cartoons on;colour chain; select "+h+" colour green";
new OpenJmol("").openPDBfile(this.path_file,howJmol);	
}
	
	double angle(Point P1,Point P2,Point P3,Point P4){
		Point V1=new Point(P2.x-P1.x,P2.y-P1.y,P2.z-P1.z);
		Point V2=new Point(P3.x-P2.x,P3.y-P2.y,P3.z-P2.z);
		Point V3=new Point(P4.x-P3.x,P4.y-P3.y,P4.z-P3.z);
		Point N1 = new Point(V1.y*V2.z-V1.z*V2.y,V1.z*V2.x-V1.x*V2.z,V1.x*V2.y-V1.y*V2.x);
		Point N2 = new Point(V2.y*V3.z-V2.z*V3.y,V2.z*V3.x-V2.x*V3.z,V2.x*V3.y-V2.y*V3.x);
		//double angle = Math.acos((N1.x*N2.x+N1.y*N2.y+N1.z*N2.z)/(Math.sqrt(N1.x*N1.x+N1.y*N1.y+N1.z*N1.z)*Math.sqrt(N2.x*N2.x+N2.y*N2.y+N2.z*N2.z)));
	
		double x = N1.x*N2.x+N1.y*N2.y+N1.z*N2.z;
		double y = (V1.x*N2.x+V1.y*N2.y+V1.z*N2.z)*Math.sqrt(V2.x*V2.x+V2.y*V2.y+V2.z*V2.z);
		if(x==0&&y==0) return 1000;
		//else return Math.atan2(y, x);

		else return (180*Math.atan2(y, x))/Math.PI;
		}
	
	double cos(Point CA_i_prev, Point CA_i, Point CA_j_prev, Point CA_j) {
		Point N1 = new Point(CA_i.x - CA_i_prev.x, CA_i.y - CA_i_prev.y, CA_i.z - CA_i_prev.z);
		Point N2 = new Point(CA_j.x - CA_j_prev.x, CA_j.y - CA_j_prev.y, CA_j.z - CA_j_prev.z);
		return (N1.x * N2.x + N1.y * N2.y + N1.z * N2.z)
			/ (Math.sqrt(N1.x * N1.x + N1.y * N1.y + N1.z * N1.z) * Math.sqrt(N2.x * N2.x + N2.y * N2.y + N2.z * N2.z));
	}

	double hydrogenBondSimilarity(Point CA_i_prev, Point CA_i, Point CB_i, Point CA_i_next, Point CA_j_prev, Point CA_j,
		Point CB_j, Point CA_j_next) {
		return (this.cos(CA_i_prev, CA_i, CA_j_prev, CA_j) + this.cos(CA_i_next, CA_i, CA_j_next, CA_j)
			+ this.cos(CB_i, CA_i, CB_j, CB_i)) / 3;
	}

	double hydrogenBondSimilarity(Point CA_i_prev, Point CA_i, Point CA_i_next, Point CA_j_prev, Point CA_j,
		Point CA_j_next) {
		return (this.cos(CA_i_prev, CA_i, CA_j_prev, CA_j) + this.cos(CA_i_next, CA_i, CA_j_next, CA_j)) / 2;
	}

	/*
	void correctSSElabel11(){
		 int [] MyLabel=this.getSSElabel();
	
		 for(int i=0;i<MyLabel.length;i++) {
			this.SSE[i]=MyLabel[i];
		 }	 
	}
	
	
	void correctSSElabel2(){
		 int [] MyLabel=this.getSSElabel();
		 System.out.println(MyLabel.length+"adad  "+this.listOH.size());
		 for(int i=0;i<MyLabel.length;i++) {	
			if(MyLabel[i]==2){
					this.SSE[i]=3;
					Point N=this.listOH.get(2*i);
					 for(int j=0;j<MyLabel.length;j++) {
						 	
							if(MyLabel[j]==2&&(j>i+2||j<i-2)){
								Point O=this.listOH.get(2*j+1);
						 		double d = O.distanceTo(N);
								 if(d<2.5) {
									 this.SSE[i]=2;
									 break;
								 			}
								 }
								 
											}	 
						 		
							}	 
		 								}}
		 
		 							
	void correctSSElabel111(){
		 int [] MyLabel=this.getSSElabel();
		 int n = MyLabel.length;
		 for(int i=2;i<n-2;i++) {
			if(MyLabel[i]==1){
				
				Point P1= this.ListResidues2.get(i).list_Atoms.get(1).Atom_Coordinate;
				Point P2= this.ListResidues2.get(i+2).list_Atoms.get(1).Atom_Coordinate;
		 		double d1 = P1.distanceTo(P2);
		 		Point P11= this.ListResidues2.get(i).list_Atoms.get(1).Atom_Coordinate;
				Point P22= this.ListResidues2.get(i-2).list_Atoms.get(1).Atom_Coordinate;
		 		double d2 = P11.distanceTo(P22);
				 if((d1<5.49+0.2&&d1>5.49-0.2)||(d2<5.49+0.2&&d2>5.49-0.2)) this.SSE[i]=1;
				 else this.SSE[i]=3;
							}	 
		 								}
		 
		 if(MyLabel[0]==1){
			 	Point P1= this.ListResidues2.get(0).list_Atoms.get(1).Atom_Coordinate;
				Point P2= this.ListResidues2.get(2).list_Atoms.get(1).Atom_Coordinate;
		 		double d1 = P1.distanceTo(P2);
				 if((d1<5.49+0.2&&d1>5.49-0.2)) this.SSE[0]=1;
				 else this.SSE[0]=3;
							}
		 if(MyLabel[1]==1){
			 	Point P1= this.ListResidues2.get(1).list_Atoms.get(1).Atom_Coordinate;
				Point P2= this.ListResidues2.get(3).list_Atoms.get(1).Atom_Coordinate;
		 		double d1 = P1.distanceTo(P2);
				 if((d1<5.49+0.2&&d1>5.49-0.2)) this.SSE[1]=1;
				 else this.SSE[1]=3;
							}
		 
		 if(MyLabel[n-1]==1){
			 	Point P1= this.ListResidues2.get(n-1).list_Atoms.get(1).Atom_Coordinate;
				Point P2= this.ListResidues2.get(n-3).list_Atoms.get(1).Atom_Coordinate;
		 		double d1 = P1.distanceTo(P2);
				 if((d1<5.49+0.2&&d1>5.49-0.2)) this.SSE[n-1]=1;
				 else this.SSE[n-1]=3;
							}
	
		 if(MyLabel[n-2]==1){
			 	Point P1= this.ListResidues2.get(n-2).list_Atoms.get(1).Atom_Coordinate;
				Point P2= this.ListResidues2.get(n-4).list_Atoms.get(1).Atom_Coordinate;
		 		double d1 = P1.distanceTo(P2);
				 if((d1<5.49+0.2&&d1>5.49-0.2)) this.SSE[n-2]=1;
				 else this.SSE[n-2]=3;
							}
		 
	
	}
	*/
	
	/*void correctSSElabel11(){
		 int [] MyLabel=this.getSSElabel();
	
		 for(int i=0;i<MyLabel.length;i++) {
			this.SSE[i]=MyLabel[i];
		 }	 
	}*/
	
	int[]  correctSSElabel(ArrayList<Residue2>ListResidues2){
		 int [] MyLabel=this.getSSElabel(ListResidues2);
		 int n = MyLabel.length;
		 int[] SSE = new int[n];
		 if(n<8){
			 for(int k=0;k<MyLabel.length;k++) 
				  SSE[k]=MyLabel[k];
			 }
		 else{
		 int i=2;			
		 while (i<n-2) {
			if(MyLabel[i]==1){
				 if(MyLabel[i+1]==1&&MyLabel[i+2]==1) {
					 SSE[i]=1;
					 SSE[i+1]=1;
					 SSE[i+2]=1;
					 i=i+3;}
				 
				 else { 
					 	if(MyLabel[i-1]==1&&MyLabel[i-2]==1) {
						 SSE[i]=1;
						 i=i+1;}
					
					 	else {
						 	SSE[i]=3; 
						 	i++;}
					 		}
							}
			else i++;
		 								}
		 
		 for(int j1=0;j1<2;j1++) {
				if(MyLabel[j1]==1){
					 if((MyLabel[j1+1]==1&&MyLabel[j1+2]==1)) SSE[j1]=1;
					 else SSE[j1]=3;
								}	 
			 								}
		 
		 
		 for(int l=n-1;l>n-3;l--) {
				if(MyLabel[l]==1){
					 if((MyLabel[l-1]==1&&MyLabel[l-2]==1)) SSE[l]=1;
					 else SSE[l]=3;
								}	 
			 								}
		
		 
		 
	 int j=2;			
	 while (j<n-2) {
		if(MyLabel[j]==2){
			 if(MyLabel[j+1]==2&&MyLabel[j+2]==2) {
				 SSE[j]=2;
				 SSE[j+1]=2;
				 SSE[j+2]=2;
				 j=j+3;}
			 
			 else {
				 
				 if(MyLabel[j-1]==2&&MyLabel[j-2]==2) {
					 SSE[j]=2;
					 j=j+1;}
				 
				 	else {
					 	SSE[j]=3; 
					 	j++;}
				 		}
						}
		else j++;
	 								}
	 
	 
	 for(int j1=0;j1<2;j1++) {
			if(MyLabel[j1]==2){
				 if((MyLabel[j1+1]==2&&MyLabel[j1+2]==2)) SSE[j1]=2;
				 else SSE[j1]=3; 
							}	 
		 								}
	 
	 
	 for(int l=n-1;l>n-3;l--) {
			if(MyLabel[l]==2){
				 if((MyLabel[l-1]==2&&MyLabel[l-2]==2)) SSE[l]=2;
				 else SSE[l]=3;
							}	 
		 								}
	 for(int k=0;k<MyLabel.length;k++) {
		 if(MyLabel[k]==3)  SSE[k]=3;
	 } }
	 return SSE;
 }
	/*
	 * void correctSSElabel1111(){ int [] MyLabel=this.getSSElabel(); int n = MyLabel.length; for(int
	 * i=0;i<MyLabel.length;i++) { if(MyLabel[i]==2){ this.SSE[i]=3; Point N1=this.listOH.get(2*i); Point
	 * O1=this.listOH.get(2*i+1); for(int j=0;j<MyLabel.length;j++) { if(MyLabel[j]==2&&(j>i+2||j<i-2)){ Point
	 * N2=this.listOH.get(2*j); Point O2=this.listOH.get(2*j+1); double d1 = O1.distanceTo(N2); double d2 =
	 * O2.distanceTo(N1); if (d1<5) System.out.println(d1); if(d1<4.5||d2<4.5) { this.SSE[i]=2; break; }}}}} for(int
	 * i=2;i<MyLabel.length-2;i++) { if(MyLabel[i]==2){ Residue2 R1 =this.ListResidues2.get(i); Point
	 * P1=R1.list_Atoms.get(1).Atom_Coordinate; Residue2 R2 =this.ListResidues2.get(i+2); Point
	 * P2=R2.list_Atoms.get(1).Atom_Coordinate; double d1 = P1.distanceTo(P2); Residue2 R22
	 * =this.ListResidues2.get(i-2); Point P22=R22.list_Atoms.get(1).Atom_Coordinate; double d11 = P1.distanceTo(P22);
	 * if((d1>6.7-0.32&&d1<6.7+0.32)||(d11>6.7-0.32&&d11<6.7+0.32)) this.SSE[i]=2; else this.SSE[i]=3; } } for(int
	 * k=0;k<MyLabel.length;k++) { if(MyLabel[k]==2) this.SSE[k]=2; } int j=2; while (j<n-2) { if(MyLabel[j]==2){
	 * if(MyLabel[j+1]==2&&MyLabel[j+2]==2) { this.SSE[j]=2; this.SSE[j+1]=2; this.SSE[j+2]=2; j=j+3;} else {
	 * if(MyLabel[j-1]==2&&MyLabel[j-2]==2) { this.SSE[j]=2; j=j+1;} else { this.SSE[j]=3; MyLabel[j]=3; j++;} } } else
	 * j++; } for(int j1=0;j1<2;j1++) { if(MyLabel[j1]==2){ if((MyLabel[j1+1]==2&&MyLabel[j1+2]==2)) this.SSE[j1]=2;
	 * else {this.SSE[j1]=3; MyLabel[j1]=3;} } } for(int l=n-1;l>n-3;l--) { if(MyLabel[l]==2){
	 * if((MyLabel[l-1]==2&&MyLabel[l-2]==2)) this.SSE[l]=2; else {this.SSE[l]=3; MyLabel[l]=3;} } } for(int
	 * i=0;i<MyLabel.length;i++) { if(MyLabel[i]==2){ this.SSE[i]=3; Residue2 R1 =this.ListResidues2.get(i); Point
	 * CA1=R1.list_Atoms.get(1).Atom_Coordinate; for(int j1=0;j1<MyLabel.length;j1++) {
	 * if(MyLabel[j1]==2&&(j1>i+1||j1<i-1)){ Residue2 R2 =this.ListResidues2.get(j1); Point
	 * CA2=R2.list_Atoms.get(1).Atom_Coordinate; double d = CA1.distanceTo(CA2); if(d<4.88+0.43&&d>4.88-0.43) {
	 * this.SSE[i]=2; break; }}}}} for(int k=0;k<MyLabel.length;k++) { if(MyLabel[k]==2) this.SSE[k]=2; } int i =2;
	 * while (i<n-3) { if(MyLabel[i]==1){ if(MyLabel[i+1]==1&&MyLabel[i+2]==1) { this.SSE[i]=1; this.SSE[i+1]=1;
	 * this.SSE[i+2]=1; i=i+3;} else { if(MyLabel[i-1]==1&&MyLabel[i-2]==1) { this.SSE[i]=1; i=i+1;} else {
	 * this.SSE[i]=3; i++;} } } else i++; } for(int j1=0;j1<2;j1++) { if(MyLabel[j1]==1){
	 * if((MyLabel[j1+1]==1&&MyLabel[j1+2]==1)) this.SSE[j1]=1; else this.SSE[j1]=3; } } for(int l=n-1;l>n-3;l--) {
	 * if(MyLabel[l]==1){ if((MyLabel[l-1]==1&&MyLabel[l-2]==1)) this.SSE[l]=1; else this.SSE[l]=3; } } int i =3; while
	 * (i<n-3) { if(MyLabel[i]==1){ if(MyLabel[i+1]==1&&MyLabel[i+2]==1&&MyLabel[i+3]==1) { this.SSE[i]=1;
	 * this.SSE[i+1]=1; this.SSE[i+2]=1; this.SSE[i+3]=1; i=i+4;} else {
	 * if(MyLabel[i-1]==1&&MyLabel[i-2]==1&&MyLabel[i-3]==1) { this.SSE[i]=1; i=i+1;} else { this.SSE[i]=3; i++;} } }
	 * else i++; } for(int j1=0;j1<3;j1++) { if(MyLabel[j1]==1){
	 * if((MyLabel[j1+1]==1&&MyLabel[j1+2]==1&&MyLabel[j1+3]==1)) this.SSE[j1]=1; else this.SSE[j1]=3; } } for(int
	 * l=n-1;l>n-4;l--) { if(MyLabel[l]==1){ if((MyLabel[l-1]==1&&MyLabel[l-2]==1&&MyLabel[l-3]==1)) this.SSE[l]=1; else
	 * this.SSE[l]=3; } } int i =4; while (i<n-4) { if(MyLabel[i]==1){
	 * if(MyLabel[i+1]==1&&MyLabel[i+2]==1&&MyLabel[i+3]==1&&MyLabel[i+4]==1) { this.SSE[i]=1; this.SSE[i+1]=1;
	 * this.SSE[i+2]=1; this.SSE[i+3]=1; this.SSE[i+4]=1; i=i+5;} else {
	 * if(MyLabel[i-1]==1&&MyLabel[i-2]==1&&MyLabel[i-3]==1&&MyLabel[i-4]==1) { this.SSE[i]=1; i=i+1;} else {
	 * this.SSE[i]=3; i++;} } } else i++; } for(int j1=0;j1<3;j1++) { if(MyLabel[j1]==1){
	 * if((MyLabel[j1+1]==1&&MyLabel[j1+2]==1&&MyLabel[j1+3]==1&&MyLabel[j1+4]==1)) this.SSE[j1]=1; else this.SSE[j1]=3;
	 * } } for(int l=n-1;l>n-5;l--) { if(MyLabel[l]==1){
	 * if((MyLabel[l-1]==1&&MyLabel[l-2]==1&&MyLabel[l-3]==1&&MyLabel[l-4]==1)) this.SSE[l]=1; else this.SSE[l]=3; } }
	 * for(int k=0;k<MyLabel.length;k++) { if(MyLabel[k]==3) this.SSE[k]=3; } }
	 */
	

	
	
	
	public MT get_F_Matrix2(MT S,double p){
		MT F=new MT(S.M,S.N);
		double Match=0,Insert=0,Delete=0;
	for (int i=0;i<F.M;i++) F.data[i][0]=i*p;
	for (int j=0;j<F.N;j++) F.data[0][j]=j*p;
	for (int i=1;i<F.M;i++)
		for (int j=1;j<F.N;j++){ 
		Match = F.data[i-1][j-1] + S.data[i][j];
      	Delete = F.data[i-1][j] + p;
      	Insert = F.data[i][j-1] + p;
      F.data[i][j]=Math.max(Match,Math.max(Insert, Delete));
						}
					return F;
						}
	public MT get_F_Matrix(MT S,double p){
		MT F=new MT(S.M,S.N);
		double Match=0,Insert=0,Delete=0;
	for (int i=0;i<F.M;i++) F.data[i][0]=0;
	for (int j=0;j<F.N;j++) F.data[0][j]=0;
	for (int i=1;i<F.M;i++)
		for (int j=1;j<F.N;j++){ 
		Match = F.data[i-1][j-1] + S.data[i][j];
      	Delete = F.data[i-1][j] + p;
      	Insert = F.data[i][j-1] + p;
      F.data[i][j]=Math.max(Match,Math.max(Insert, Delete));
						}
					return F;
						}
	
	MT getSimilarityMaTrix1(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput){
		//Secondary structure assignment
		MT S= new MT(ListHit.size(),ListInput.size());
		for (int i=0;i<ListHit.size();i++)
			for (int j=0;j<ListInput.size();j++){
				if(ListHit.get(i).label==ListInput.get(j).label)S.data[i][j]=1;
				else S.data[i][j]=0;
			}
		return S;	
				}
	
	MT getSimilarityMaTrix2(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,int Lmin){
		//Secondary structure assignment
		MT S= new MT(ListHit.size(),ListInput.size());
		double ex = (double)1.0/3.0;
		double d0=0.5;
		if (Lmin>15) d0=1.24*Math.pow((Lmin-15),ex)-1.8;
		
		for (int i=0;i<ListHit.size();i++)
			for (int j=0;j<ListInput.size();j++){
				double dij = ListHit.get(i).get_distanceTo(ListInput.get(j));
				S.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
			}
		return S;	
				}

	/*PreAlignment shorten(PreAlignment Pre){
		ArrayList<Residue> newListHit= new ArrayList<Residue>();
		ArrayList<Residue> newListInput= new ArrayList<Residue>();
		for(int i=0;i<Pre.ListHitResidues.size();i++){
			if(Pre.ListHitResidues.get(i).label==Pre.ListInputResidues.get(i).label)
			{newListHit.add(Pre.ListHitResidues.get(i));
			newListInput.add(Pre.ListInputResidues.get(i));}

		}
			PreAlignment newP=new PreAlignment(newListHit,newListInput);
			System.out.println(newP.ListHitResidues.size()+" vs "+Pre.ListHitResidues.size());
		return newP;
	}*/
	
	
	
	
	
	MT combineSSE(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,MT S1){
		MT S2= new MT(S1.M,S1.N); 
		for (int i = 0; i < S2.M; i++) 
          	  for (int j = 0; j < S2.N; j++){
          		Residue H =ListHit.get(i);
				Residue I =ListInput.get(j);
          		  	if(H.label==I.label) 
          		  	///if(H.label==I.label&&H.polarity==I.polarity)
          		  		 S2.data[i][j]=S1.data[i][j]+0.5;
          		  	else S2.data[i][j]=S1.data[i][j];
          	  }
		
		return S2;
	}





// PreAlignment HeuriticIterationUsingScoreUsingOneFragment_remoteEvolutionScore(ArrayList<Residue> ListHit,
	// ArrayList<Residue> ListInput, String knownpath) throws Exception {
	// // PreAlignment Pre= this.shorten(this.initialAlignment(ListHit, ListInput));
	// // try{
	// ArrayList<PreAlignment> initials = new ArrayList<PreAlignment>();
	// // double da=0.5;
	// // LinkedList<PreAlignment> frs = this.fragmentAlignments(6, ListHit, ListInput);
	// // Collections.sort(frs, new PreAlignmentRMSDComparator());
	// LinkedList<PreAlignment> frs = this.fragmentAlignments(ListHit, ListInput);
	// Collections.sort(frs, new PreAlignmentTMscoreComparator());
	// // for (int u = frs.size() - 1; u > frs.size() - 7; u--) {
	// for (int u = 0; u < Math.min(50, frs.size()); u++) {
	// System.out.println("uuuu" + u);
	// PreAlignment pre = frs.get(u);
	// pre = this.HeuriticIteration_for_one_InitialAlignment(ListHit, ListInput, pre, knownpath);
	// if (pre.getTMscore() > 0.5)
	// return pre;
	// else
	// initials.add(pre);
	// }
	//
	// PreAlignment pre1 = initials.get(0);
	// double tm1 = pre1.getTMscore();
	// for (int k = 1; k < initials.size(); k++) {
	// double tmk = initials.get(k).getTMscore();
	// if (tmk > 0.5) {
	// return pre1;
	// }
	// if (tmk > tm1) {
	// pre1 = initials.get(k);
	// tm1 = pre1.getTMscore();
	// }
	// }
	// return pre1;
	// }
	

	PreAlignment usingFragment_tmScore_assembly(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput)
		throws Exception {
		ArrayList<PreAlignment> pres = this.complete_FragmentAlignments(ListHit, ListInput);
		if (pres.size() > 0) {
			PreAlignment pre0 = pres.get(0);
			for (int k = 1; k < pres.size(); k++) {
				PreAlignment prek = pres.get(k);
				if (prek.getTMscore() > pre0.getTMscore())
					pre0 = prek;
			}
			return pre0;
		} else
			return null;

	}

	PreAlignment usingSeqAlignmnet(ArrayList<Residue> hit, ArrayList<Residue> input) throws Exception {
		ArrayList<PreAlignment> pres = this.initialAlignmentUsingSeqAlignment(hit, input);
		if (pres.size() > 0) {
			PreAlignment pre0 = pres.get(0);
			for (int k = 1; k < pres.size(); k++) {
				PreAlignment prek = pres.get(k);
				if (prek.getTMscore() > pre0.getTMscore())
					pre0 = prek;
			}
			return pre0;
		} else
			return null;

	}

	// PreAlignment usingFragment_tmScore_assembly(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput)
	// throws Exception {
	// ArrayList<PreAlignment> pres = this.complete_FragmentAlignments(ListHit, ListInput);
	// if (pres.size() > 0) {
	// PreAlignment pre0 = this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(ListHit, ListInput,
	// pres.get(0));
	// for(int k=1;k<pres.size();k++){
	// PreAlignment prek = this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(ListHit, ListInput,
	// pres.get(k));
	// if(prek.getTMscore()>pre0.getTMscore())pre0=prek;
	// }
	// return pre0;
	// } else
	// return null;
	//
	// }

//	PreAlignment HeuriticIteration11(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput, String knownpath)
//		throws Exception {
//		// PreAlignment Pre= this.shorten(this.initialAlignment(ListHit, ListInput));
//		// try{
//		ArrayList<PreAlignment> initials = new ArrayList<PreAlignment>();
//		// double da=0.5;
//		ArrayList<CompleteFragmentAlignment> cfrs = this.complete_FragmentAlignments(ListHit, ListInput);
//
//		for(CompleteFragmentAlignment cfr:cfrs){
//
//			ArrayList<Residue> ListHitResidues= new ArrayList<Residue>();
//			ArrayList<Residue> ListInputResidues= new ArrayList<Residue>();
//			ArrayList<FragmentAlignment> ls=cfr.getFragmentAlignments();
//			for (int i=0;i<ls.size();i++){
//				ListHitResidues.addAll(ls.get(i).getHit().getListResidue());
//				ListInputResidues.addAll(ls.get(i).getInput().getListResidue());
//			}
//			System.out.println("sizessss" + ListHitResidues.size());
//			PreAlignment pre= new PreAlignment(ListHitResidues,ListInputResidues,ListInput.size()); 
//			System.out.println("sizessss" + pre.getListHitResidues().size());
//			if (ListHitResidues.size() > 0) {
//				initials.add(this.HeuriticIteration_for_one_InitialAlignment(ListHit, ListInput, pre, knownpath));
//			}
//		}
//		
//		PreAlignment pre1= initials.get(0);
//		for(int k=1;k<initials.size();k++){
//			if(initials.get(k).getTMscore()>pre1.getTMscore())pre1=initials.get(k);
//		}
//		return pre1;
//	}


	PreAlignment usingTMscoreMTcoverALLfragments(ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput, String knownpath) throws Exception {
		PreAlignment pre1 = this.usingTMscoreMTcoverALLfragmentsNoSSE(ListHit, ListInput, knownpath);
		PreAlignment pre2 = this.usingTMscoreMTcoverALLfragmentsUsingSSE(ListHit, ListInput, knownpath);
		if (pre1.getTMscore() > pre2.getTMscore()) {
			System.out.println("no SSE ");
			return pre1;
		} else {
			System.out.println("SSE");
			return pre2;
		}
	}

	PreAlignment usingTMscoreMTcoverALLfragmentsNoSSE(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput,
		String knownpath) throws Exception {

		PreAlignment pre = this.heuriticIterationUsingTMscoreMatrixCoverALLfragments(0.0, ListHit, ListInput, knownpath);
		// PreAlignment pre2 = this.HeuriticIterationUsingScoreMTcoverALLfragments(-0.6, ListHit, ListInput, knownpath);
		double p = 0.0, best = 0.0;
		for (int i = 0; i < 3; i++) {
			p = p - 0.4;
			PreAlignment pre1 = this.heuriticIterationUsingTMscoreMatrixCoverALLfragments(p, ListHit, ListInput, knownpath);
			if (pre1.getTMscore() > pre.getTMscore()) {
				pre = pre1;
				best = p;
			}
		}
		System.out.println("best gap, no SSE " + best);
		System.out.println("final tmScore= " + pre.getTMscore());
		return pre;

	}
	
	PreAlignment usingTMscoreMTcoverALLfragmentsUsingSSE(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput,
		String knownpath) throws Exception {

		PreAlignment pre = this.heuriticIterationUsingTMscoreSSEmatrixCoverALLfragments(0.0, ListHit, ListInput,
			knownpath);
		// PreAlignment pre2 = this.HeuriticIterationUsingScoreMTcoverALLfragments(-0.6, ListHit, ListInput, knownpath);
		double p = 0.0, best = 0.0;
		for (int i = 0; i < 3; i++) {
			p = p - 0.4;
			PreAlignment pre1 = this.heuriticIterationUsingTMscoreSSEmatrixCoverALLfragments(p, ListHit, ListInput,
				knownpath);
			if (pre1.getTMscore() > pre.getTMscore()) {
				pre = pre1;
				best = p;
			}
		}
		System.out.println("best gap, no SSE " + best);
		System.out.println("final tmScore= " + pre.getTMscore());
		return pre;
	}
	
	PreAlignment heuriticIterationUsingTMscoreSSEmatrixCoverALLfragments(double gap, ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput, String knownpath) throws Exception {
		int min = Math.min(ListHit.size(), ListInput.size());
		MT score = this.similarityMatrixFromFragmentsUsingSSE(ListHit, ListInput);
		PreAlignment pre = this.align(min, ListHit, ListInput, score, gap);// p = 0.0;-0.6
		int ct = 0;
		double cur = pre.getTMscore();
		System.out.println("size pre alignment " + pre.getListHitResidues().size());
		// System.out.println("tmScore= " + pre.getTMscore());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;// 0.168;
		double d8 = 1.5 * Math.pow(min * 1.0, 0.3) + 3.5;
		if (min > 19)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;
		System.out.println("d0= " + d0);
		System.out.println("d8= " + d8);
		while (ct < 10) {
			System.out.println("loop: " + ct);
			MT newScore = new MT(ListHit.size(), ListInput.size());
			MT R = pre.get_rotational_Matrix();
			Point O2 = pre.center_of_HitResidues();// pdb 25
			Point O1 = pre.center_of_inputResidues();
			for (int i = 0; i < ListHit.size(); i++)
				for (int j = 0; j < ListInput.size(); j++) {
					Residue H = ListHit.get(i);
					Residue I = ListInput.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);
					newScore.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					if (H.label == I.label)
						newScore.data[i][j] = newScore.data[i][j] + 0.5;
					if (dij > d8)
						newScore.data[i][j] = 0.0;
				}
			
			pre = this.align(min, ListHit, ListInput, newScore, gap);
			
			// do here
			double tm = pre.getTMscore();
			if (Math.abs(cur - tm) < 0.01||pre.getListHitResidues().size()<5) {
				break;
			} else {
				ct++;
				cur = tm;
				if(d8<4.0) d8=4.0;
			}
		}
		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		return pre;
	}

	PreAlignment heuriticIterationUsingTMscoreMatrixCoverALLfragments(double gap, ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput, String knownpath) throws Exception {
		int min = Math.min(ListHit.size(), ListInput.size());
		MT score = this.similarityMatrixFromFragments(ListHit, ListInput);
		PreAlignment pre = this.align(min, ListHit, ListInput, score, gap);// p = 0.0;-0.6

		int ct = 0;
		double cur = pre.getTMscore();
		System.out.println("size pre alignment " + pre.getListHitResidues().size());
		// System.out.println("tmScore= " + pre.getTMscore());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;// 0.168;
		double d8 = 1.5 * Math.pow(min * 1.0, 0.3) + 3.5;
		if (min > 19)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;
		System.out.println("d0= " + d0);
		while (ct < 10) {
			System.out.println("loop: " + ct);
			MT newScore = new MT(ListHit.size(), ListInput.size());
			MT R = pre.get_rotational_Matrix();
			Point O2 = pre.center_of_HitResidues();// pdb 25
			Point O1 = pre.center_of_inputResidues();
			for (int i = 0; i < ListHit.size(); i++)
				for (int j = 0; j < ListInput.size(); j++) {
					Residue H = ListHit.get(i);
					Residue I = ListInput.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);
					newScore.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					if (dij > d8)
						newScore.data[i][j] = 0.0;
					// if(H.label==I.label)
					// S.data[i][j]=S.data[i][j]+0.5;
				}
			pre = this.align(min, ListHit, ListInput, newScore, gap);
			// do here
			double tm = pre.getTMscore();
			if (Math.abs(cur - tm) < 0.01) {
				break;
			} else {
				ct++;
				cur = tm;
			}
		}
		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		return pre;
	}


	String[] heuriticIteration_for_one_InitialAlignmentUsingFrTMalign22(ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput, PreAlignment Pre, HashMap<String, String> hm) throws Exception {

		// PreAlignment Pre= this.shorten(this.initialAlignment(ListHit, ListInput));
		// try{
		// PreAlignment Pre = this.initialAlignment(ListHit, ListInput);
		if (Pre == null)
			return null;
		int ct = 0;
		double cur = 10;
		// System.out.println("sizessss " + Pre.getListHitResidues().size());
		int min = Math.min(ListHit.size(), ListInput.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		double d8 = 1.5 * Math.pow(min * 1.0, 0.3) + 3.5;
		if (min > 19)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;
		// System.out.println("d0= " + d0);
		// System.out.println("d8= " + d8);
		MT S = new MT(ListHit.size(), ListInput.size());
		while (ct < 15) {
			// System.out.println("loop: " + ct);
			// MT S = new MT(ListHit.size(), ListInput.size());
			MT R = Pre.get_rotational_Matrix();
			Point O2 = Pre.center_of_HitResidues();// pdb 25
			Point O1 = Pre.center_of_inputResidues();
			for (int i = 0; i < ListHit.size(); i++)
				for (int j = 0; j < ListInput.size(); j++) {
					Residue H = ListHit.get(i);
					Residue I = ListInput.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);
					S.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					if (dij > d8)
						S.data[i][j] = 0.0;
					// if(H.label==I.label)
					// S.data[i][j]=S.data[i][j]+0.5;
				}

			Pre = this.align(min, ListHit, ListInput, S, -0.6);

			// do here
			double tm = Pre.getTMscore();
			if (Math.abs(cur - tm) < 0.001 || Pre.getListHitResidues().size() < 8) {
				// System.out.println("Final tmScore= " + tm);
				// Pre = new PreAlignment(Pre, tm);
				break;
			} else {
				ct++;
				cur = tm;
				if (d8 > 4.5)
					d8 = d8 - 1.5;
				else
					d8 = 4.5;
			}
		}

		String[] a = this.align22(min, ListHit, ListInput, S, -0.6, hm);
		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		return a;
	}

	PreAlignment heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput, PreAlignment Pre)
		throws Exception {

		// PreAlignment Pre= this.shorten(this.initialAlignment(ListHit, ListInput));
		// try{
		//PreAlignment Pre = this.initialAlignment(ListHit, ListInput);
		if (Pre == null)
			return null;
		int ct = 0;
		double cur = 10;
		// System.out.println("sizessss " + Pre.getListHitResidues().size());
		int min = Math.min(ListHit.size(), ListInput.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		double d8 = 1.5 * Math.pow(min * 1.0, 0.3) + 3.5;
		if (min > 19)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;
		// System.out.println("d0= " + d0);
		// System.out.println("d8= " + d8);
		while (ct < 15) {
			// System.out.println("loop: " + ct);
			MT S = new MT(ListHit.size(), ListInput.size());
			MT R = Pre.get_rotational_Matrix();
			Point O2 = Pre.center_of_HitResidues();// pdb 25
			Point O1 = Pre.center_of_inputResidues();
			for (int i = 0; i < ListHit.size(); i++)
				for (int j = 0; j < ListInput.size(); j++) {
					Residue H = ListHit.get(i);
					Residue I = ListInput.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);
					S.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					if (dij > d8)
						S.data[i][j] = 0.0;
					// if(H.label==I.label)
					// S.data[i][j]=S.data[i][j]+0.5;
				}


			Pre = this.align(min, ListHit, ListInput, S, -0.6);

			// do here
			double tm = Pre.getTMscore();
			if (Math.abs(cur - tm) < 0.001 || Pre.getListHitResidues().size() < 8) {
				// System.out.println("Final tmScore= " + tm);
				// Pre = new PreAlignment(Pre, tm);
				break;
			} else {
				ct++;
				cur = tm;
				if (d8 > 4.5)
					d8 = d8 - 1.5;
				else
					d8 = 4.5;
			}
		}
		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		return Pre;
	}

	ArrayList<PreAlignment> initialAlignmentUsingSeqAlignment(ArrayList<Residue> hit, ArrayList<Residue> input)
		throws Exception {
		ArrayList<PreAlignment> ls = new ArrayList<PreAlignment>();
		int lmin = Math.min(hit.size(), input.size());
		MT S62 = new MT(hit.size(), input.size());
		MT S45 = new MT(hit.size(), input.size());
		for (int i = 0; i < hit.size(); i++)
			for (int j = 0; j < input.size(); j++) {
				char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
				char b = this.WWW_Three2One_III(input.get(j).Residue_Name);
				S62.data[i][j] = this.BLOSUM62_Calc(a, b);
				S45.data[i][j] = this.BLOSUM45_Calc(a, b);
			}
		ls.add(this.align(lmin, hit, input, S62, -1));
		ls.add(this.align(lmin, hit, input, S45, -1));
		ls.add(this.alignUsingDP_SmithWaterman(hit, input, S45, -1, lmin));
		ls.add(this.alignUsingDP_SmithWaterman(hit, input, S62, -1, lmin));
		return ls;
	}

	PreAlignment HeuriticIteration_for_one_InitialAlignmentUsingEvolScore(ArrayList<Residue> hit,
		ArrayList<Residue> input, PreAlignment Pre) throws Exception {

		int lmin = Math.min(hit.size(), input.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		double d8 = 1.5 * Math.pow(lmin * 1.0, 0.3) + 3.5;
		if (lmin > 19)
			d0 = 1.24 * Math.pow((lmin - 15), ex) - 1.8;
		System.out.println("d0= " + d0);
		int ct = 0;
		double cur = 10;
		System.out.println("size before " + Pre.getListHitResidues().size());
		System.out.println("using evolution score ");
		while (ct < 15) {
			System.out.println("loop: " + ct);
			MT S = new MT(hit.size() - 2, input.size() - 2);
			MT R = Pre.get_rotational_Matrix();
			Point O2 = Pre.center_of_HitResidues();// pdb 25
			Point O1 = Pre.center_of_inputResidues();
			for (int i = 1; i < hit.size() - 1; i++)
				for (int j = 1; j < input.size() - 1; j++) {
					Residue H = hit.get(i);
					Residue I = input.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);

					double hydrSim = 0.0;
					if (hit.get(i).list_Atoms.size() > 4 && input.get(j).list_Atoms.size() > 4) {
						hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
							hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i).list_Atoms.get(4).Atom_Coordinate,
							hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
							input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
							input.get(j).list_Atoms.get(1).Atom_Coordinate,
							input.get(j).list_Atoms.get(4).Atom_Coordinate,
							input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
					} else {
						hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
							hit.get(i).list_Atoms.get(1).Atom_Coordinate,
							hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
							input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
							input.get(j).list_Atoms.get(1).Atom_Coordinate,
							input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
					}
					char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
					char b = this.WWW_Three2One_III(input.get(j).Residue_Name);

					double CLESUM = this.CLESUM_Calc(a, b);
					double dd = 1.0 / (1 + (dij * dij / (d0 * d0)));
					double BLOSUM = this.BLOSUM62_Calc(a, b);
					double scoreij = Math.max(0, BLOSUM + CLESUM) * hydrSim * dd;
					S.data[i - 1][j - 1] = scoreij;
					//System.out.println("scoreij " + scoreij);
					if (dij > d8 || scoreij < 0)
						S.data[i - 1][j - 1] = 0.0;
					// sum=sum+scoreii;
				}

			int s1 = hit.size();
			Residue h0 = hit.get(0);
			Residue h_last = hit.get(s1 - 1);
			hit.remove(s1 - 1);
			hit.remove(0);

			int s2 = input.size();
			Residue i0 = input.get(0);
			Residue i_last = input.get(s2 - 1);
			input.remove(s2 - 1);
			input.remove(0);
			// done remove the first, and last element
			// next is DP with different gap, algorithm, pick the best one
			ArrayList<PreAlignment> la = new ArrayList<PreAlignment>(4);
			ArrayList<String> ss = new ArrayList<String>(4);
			PreAlignment pr = this.align(lmin, hit, input, S, 0.0);
			if (pr != null) {
				la.add(pr);
				ss.add("global,p=0.0");
			}
			PreAlignment pr1 = this.align(lmin, hit, input, S, -0.6);
			if (pr1 != null) {
				la.add(pr1);
				ss.add("global,p=-0.6");
			}

			PreAlignment pr2 = this.alignUsingDP_SmithWaterman(hit, input, S, 0.0, lmin);
			if (pr2 != null) {
				la.add(pr2);
				ss.add("loccal,p=0.0");
			}
			PreAlignment pr3 = this.alignUsingDP_SmithWaterman(hit, input, S, -0.6, lmin);
			if (pr3 != null) {
				la.add(pr3);
				ss.add("local,p=-0.6");
			}

			Pre = la.get(0);
			double tm = Pre.getTMscore();
			int kk = 0;
			for (int k = 1; k < la.size(); k++) {
				double tmk = la.get(k).getTMscore();
				if (tmk > tm) {
					Pre = la.get(k);
					tm = tmk;
					kk = k;
				}
			}

			hit.add(0, h0);
			hit.add(hit.size() - 1, h_last);
			input.add(0, i0);
			input.add(input.size() - 1, i_last);
			// add back
			System.out.println("tmScore= " + tm);
			System.out.println(ss.get(kk));
			// do here
			if (Math.abs(cur - tm) < 0.0001) {
				break;
			} else {
				ct++;
				cur = tm;
				d8 = d8 - 1.5;
			}
		}

		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		System.out.println("size after " + Pre.getListHitResidues().size());
		return Pre;
	}

	PreAlignment usingTMalign_3_initial(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput)
		throws Exception {
		// 3 initial

		int min = Math.min(ListHit.size(), ListInput.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (min > 15)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;
		double d8 = 1.5 * Math.pow(min * 1.0, 0.3) + 3.5;

		System.out.println("d0= " + d0);
		PreAlignment Pre = this.initialAlignment(ListHit, ListInput);
		if (Pre == null)
			return null;
		int ct = 0;
		double cur = Pre.getTMscore();
		while (ct < 15) {
			System.out.println("loop: " + ct);
			System.out.println("length: " + Pre.ListHitResidues.size());
			System.out.println("tmScore= " + Pre.getTMscore());
			// MT S1=this.getSimilarityMTfromPreAlignmentTM(ListHit,ListInput,Pre);
			MT S = new MT(ListHit.size(), ListInput.size());
			MT R = Pre.get_rotational_Matrix();
			Point O2 = Pre.center_of_HitResidues();// pdb 25
			Point O1 = Pre.center_of_inputResidues();
			for (int i = 0; i < ListHit.size(); i++)
				for (int j = 0; j < ListInput.size(); j++) {
					Residue H = ListHit.get(i);
					Residue I = ListInput.get(j);
					Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
					MT I1 = new MT(3, 1);
					I1.data[0][0] = CAI.x - O1.x;
					I1.data[1][0] = CAI.y - O1.y;
					I1.data[2][0] = CAI.z - O1.z;
					MT I2 = R.times(I1);
					double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
						+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
					double dij = Math.sqrt(ddij);
					S.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					if (dij > d8)
						S.data[i][j] = 0.0;
					// if(H.label==I.label)
					// S.data[i][j]=S.data[i][j]+0.5;
				}


			Pre = this.align(min, ListHit, ListInput, S, -0.6);

			// do here
			double tm = Pre.getTMscore();
			if (Math.abs(cur - tm) < 0.001 || Pre.getListHitResidues().size() < 10) {
				break;
			} else {
				ct++;
				cur = tm;
				if (d8 > 4.5)
					d8 = d8 - 1.0;
				else
					d8 = 4.5;
			}
		}
		// Alignment A = new Alignment(Pre,true,knownpath);
		// if(cur>=0.4||A.RMSD<4.0)
		return Pre;
	}

	double calc_score(MT matrix, int x, int y, MT S, double gap) {
		// The score is based on the up, left, and upper-left neighbors.
		double diag_score = matrix.data[x - 1][y - 1] + +S.data[x - 1][y - 1];
		double up_score = matrix.data[x - 1][y] + gap;
		double left_score = matrix.data[x][y - 1] + gap;
		return Math.max(0, Math.max(diag_score, Math.max(up_score, left_score)));
	}

	MT create_score_matrix(int rows, int cols, MT S, double gap) {
		MT score_matrix = new MT(S.M + 1, S.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.
		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}
		return score_matrix;
	}

	void traceback(MT score_matrix, int max_pos_i, int max_pos_j) {
		/*
		 * This function traces a path from the bottom-right to the top-left corner of the scoring matrix. Each move
		 * corresponds to a match, mismatch, or gap in one or both of the sequences being aligned. Moves are determined
		 * by the score of three adjacent squares: the upper square, the left square, and the diagonal upper-left
		 * square. WHAT EACH MOVE REPRESENTS diagonal: match/mismatch up: gap in sequence 1 left: gap in sequence 2
		 */

		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		// aligned_seq1 = []
		// aligned_seq2 = []
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append(seq2[y - 1])
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}

		// aligned_seq1.append(seq1[x - 1])
		// aligned_seq2.append(seq2[y - 1])
	}

	int next_move(MT score_matrix, int x, int y) {
		double diag = score_matrix.data[x - 1][y - 1];
		double up = score_matrix.data[x - 1][y];
		double left = score_matrix.data[x][y - 1];
		if (diag >= up && diag >= left) {// Tie goes to the DIAG move.
			if (diag != 0)
				return 1;
			else
				return 0; // 1 signals a DIAG move. 0 signals the end.
		} else if (up > diag && up >= left) {// Tie goes to UP move.
			if (up != 0)
				return 2;
			else
				return 0; // UP move or end.
		} else if (left > diag && left > up) {
			if (left != 0)
				return 3;
			else
				return 0; // LEFT move or end.
		} else {
			System.out.println("invalid move during traceback");
			return -10;
		}
	}

	PreAlignment refineBeforeHeuriticIteration(int Lmin, FragmentAlignment fra) throws Exception {
		ArrayList<Residue> hit_f = fra.getHit().getListResidue();
		ArrayList<Residue> input_f = fra.getInput().getListResidue();

		PreAlignment Pre = new PreAlignment(hit_f, input_f, Lmin);
		// System.out.println(Pre.ListHitResidues.size());
		MT S1 = this.getRMSDsimilarityMaTrixfromPreAlignment1(0.5, Pre, Lmin, 7.0);

		PreAlignment Pre1 = this.align(Lmin, hit_f, input_f, S1, -1.0);
		PreAlignment Pre2 = this.align(Lmin, hit_f, input_f, S1, 0.0);
		// double rmsd1 = Pre1.get_RMSD();
		// double rmsd2 = Pre2.get_RMSD();
		double tm1 = Pre1.getTMscore();
		double tm2 = Pre2.getTMscore();
		// double rmsd = Math.min(rmsd1, rmsd2);
		double tmScore = Math.max(tm1, tm2);
		// System.out.println("rmsd1= " + rmsd1);
		// System.out.println("rmsd2= " + rmsd2);
		System.out.println("tm score1= " + tm1);
		System.out.println("tm score2= " + tm2);
		System.out.println("----------------");

		if (tm1 > tm2)
			Pre = Pre1;
		else
			Pre = Pre2;
		System.out.println(Pre.ListHitResidues.size());
		// if (rmsd > 2.6) {
		return Pre;
		// } else {
		// return new FragmentAlignment(new Fragment(new ArrayList<Residue>()),
		// new Fragment(new ArrayList<Residue>()));
		// }
	}

	PreAlignment assembly(int Lmin, CompleteFragmentAlignment cfr) throws Exception {
		ArrayList<Residue> ListHit = new ArrayList<Residue>();
		ArrayList<Residue> ListInput = new ArrayList<Residue>();
		ArrayList<FragmentAlignment> frams = cfr.getFragmentAlignments();
		for (FragmentAlignment fra : frams) {
			ListHit.addAll(fra.getHit().getListResidue());
			ListInput.addAll(fra.getInput().getListResidue());
		}
		PreAlignment Pre = new PreAlignment(ListHit, ListInput, Lmin);
		return Pre;
	}

	PreAlignment refineBeforeHeuriticIteration(int min, CompleteFragmentAlignment cfr) throws Exception {
		ArrayList<Residue> ListHit = new ArrayList<Residue>();
		ArrayList<Residue> ListInput= new ArrayList<Residue>();
		ArrayList<FragmentAlignment> frams = cfr.getFragmentAlignments();
		for (FragmentAlignment fra : frams){
			ListHit.addAll(fra.getHit().getListResidue());
			ListInput.addAll(fra.getInput().getListResidue());
		}
		ArrayList<PreAlignment> pres = new ArrayList<PreAlignment>();
		PreAlignment Pre = new PreAlignment(ListHit, ListInput, min);
		// System.out.println(Pre.ListHitResidues.size());
		double d8 = 1.5 * Math.pow(min, 0.3) + 3.5;
		MT S1 = this.getRMSDsimilarityMaTrixfromPreAlignment1(0.5, Pre, min, d8);
		pres.add(this.align(min, ListHit, ListInput, S1, -1.0));
		pres.add(this.align(min, ListHit, ListInput, S1, 0.0));

		MT S2 = this.getRMSDsimilarityMaTrixfromPreAlignment1(0.0, Pre, min, d8);
		pres.add(this.align(min, ListHit, ListInput, S2, -1.0));
		pres.add(this.align(min, ListHit, ListInput, S2, 0.0));

		// MT S3 = this.getRMSDsimilarityMaTrixfromPreAlignment2(Pre, 6.0);
		// PreAlignment p = this.align(min, ListHit, ListInput, S3, 0.0);
		// pres.add(p);
		// MT S4 = this.getRMSDsimilarityMaTrixfromPreAlignment2(p, 5.0);
		// PreAlignment p1 = this.align(min, ListHit, ListInput, S4, 0.0);
		// pres.add(p1);
		PreAlignment pre0 = pres.get(0);
		for (int k = 1; k < pres.size(); k++) {
			PreAlignment prek = pres.get(k);
			if (prek.getTMscore() > pre0.getTMscore())
				pre0 = prek;
		}

		return this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(pre0.getListHitResidues(),
			pre0.getListInputResidues(), pre0);
		// return pre0;

	}




	PreAlignment initialAlignment(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput) {
	PreAlignment A1 = this.initialAlignment1(ListHit, ListInput);//best SSE
	PreAlignment A2 = this.initialAlignment2(ListHit, ListInput);//best rmsd
	PreAlignment A3 = this.initialAlignment3(ListHit, ListInput);//best tmscore
	PreAlignment A4 = this.initialAlignment4(ListHit, ListInput,A3);//half-half
	ArrayList<Double> listTM= new ArrayList<Double>();
	     if(A1!=null)listTM.add(A1.getTMscore());else listTM.add(0.0);
	     if(A2!=null)listTM.add(A2.getTMscore());else listTM.add(0.0);
	     if(A3!=null)listTM.add(A3.getTMscore());else listTM.add(0.0);
	     if(A4!=null)listTM.add(A4.getTMscore());else listTM.add(0.0);
	
		
		
	
		 int max = this.getMax(listTM)+1;
		 
		
		if(max==1) 
			 {
			 System.out.println("sse alignment is the best,tmScore="+listTM.get(0)); 
			 return A1;
			 }
		 else if(max==2) 
			 {
			System.out.println("sliding window,rmsd is the best,tmscore="+listTM.get(1));
			 return A2;
			 }
		 else if(max==3) 
		 {
		System.out.println("sliding windows,tmscore is the best,tmscore="+listTM.get(2));
		 return A3;
		 }
		 else //if(max==4) 
		 {
		System.out.println("half-half-32 is the best,tmscore="+listTM.get(3));
		 return A4;
		 }
		 
		 
		
}
	
	double[] GLscore3(ArrayList<Residue> ListHitFregment, ArrayList<Residue> ListInputFregment) {
		// double da= 0.25, 0.5, 1.0 or 1.5
		double GLscore1 = 0, GLscore2 = 0, GLscore3 = 0, GLscore4 = 0;
		double[] GLscores = new double[4];
		ArrayList<Point> l2 = new ArrayList<Point>();
		for (Residue R : ListHitFregment)
			for (Representative_Atom atom : R.list_Atoms)
				l2.add(atom.Atom_Coordinate);

		ArrayList<Point> l1 = new ArrayList<Point>();
		for (Residue R : ListInputFregment)
			for (Representative_Atom atom : R.list_Atoms)
				l1.add(atom.Atom_Coordinate);
		Point O1 = this.get_geometric_average_Point(l1);
		Point O2 = this.get_geometric_average_Point(l2);
		MT Y = this.get_MT_from(l1).translation_to_the_Origin(O1);
		MT X = this.get_MT_from(l2).translation_to_the_Origin(O2);
		MT S = this.The_best_rotation(X, Y);

		for (int i = 1; i < X.M; i = i + 3) {
			MT I = new MT(3, 1);
			I.data[0][0] = Y.data[i][0];
			I.data[1][0] = Y.data[i][1];
			I.data[2][0] = Y.data[i][2];
			MT R = S.times(I);

			double di = Math.pow(R.data[0][0] - X.data[i][0], 2) + Math.pow(R.data[1][0] - X.data[i][1], 2)
				+ Math.pow(R.data[2][0] - X.data[i][2], 2);
			GLscore1 = GLscore1 + 1 / (1 + (di / (0.25 * 0.25)));
			GLscore2 = GLscore2 + 1 / (1 + (di / (0.5 * 0.5)));
			GLscore3 = GLscore3 + 1 / (1 + (di / (1.0 * 1.0)));
			GLscore4 = GLscore4 + 1 / (1 + (di / (1.5 * 1.5)));
		}

		GLscores[0] = GLscore1;
		GLscores[1] = GLscore2;
		GLscores[2] = GLscore3;
		GLscores[3] = GLscore4;

		return GLscores;
	}

	double GLscore(ArrayList<Residue> ListHitFregment,ArrayList<Residue> ListInputFregment,double da){
		double GLscore=0;
		ArrayList<Point> l2=new ArrayList<Point>();
		for(Residue R : ListHitFregment )
			for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
		
		ArrayList<Point> l1=new ArrayList<Point>();
		for(Residue R : ListInputFregment)
			for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
		Point O1 = this.get_geometric_average_Point(l1);
		Point O2 = this.get_geometric_average_Point(l2);
		MT Y=this.get_MT_from(l1).translation_to_the_Origin(O1);
		MT X=this.get_MT_from(l2).translation_to_the_Origin(O2);
		MT S=this.The_best_rotation(X,Y);
		
		for(int i=1;i<X.M;i=i+3){
			MT I = new MT(3,1);
			I.data[0][0]=Y.data[i][0];
			I.data[1][0]=Y.data[i][1];
			I.data[2][0]=Y.data[i][2];
			MT R= S.times(I);
		
			double di=Math.pow(R.data[0][0]-X.data[i][0],2)+Math.pow(R.data[1][0]-X.data[i][1],2)+Math.pow(R.data[2][0]-X.data[i][2],2);
			double dda=da*da;
			GLscore=GLscore+ 1/(1+(di/dda));
		}
	
		
		
		
		return GLscore;
	}
	
	int numberIdenticalSSE(ArrayList<Residue> ListHitFregment,ArrayList<Residue> ListInputFregment){
		int count=0;
		for(int i=0;i<ListHitFregment.size();i++){
			if(ListHitFregment.get(i).label==ListInputFregment.get(i).label)count++;
		}
		return count;
	}
	
	
	
	
double GLscore2(ArrayList<Residue> ListHit,ArrayList<Residue> ListInput,double da){
		int max = Math.max(ListHit.size(),ListInput.size());
		int min = Math.min(ListHit.size(),ListInput.size());
			ArrayList<Residue> newListHit0= new ArrayList<Residue>(min);
			ArrayList<Residue> newListInput0= new ArrayList<Residue>(min);
			for(int j=0;j<min;j++){
				newListHit0.add(ListHit.get(j));
				newListInput0.add(ListInput.get(j));
			}
			double maxxx =this.GLscore(newListHit0,newListInput0,da);
			
			for(int i=1;i<max-min+1;i++){
				ArrayList<Residue> newListHit= new ArrayList<Residue>(min);
				ArrayList<Residue> newListInput= new ArrayList<Residue>(min);
				if(ListHit.size()>=ListInput.size()){
				for(int j=0;j<min;j++){
					newListHit.add(ListHit.get(j+i));
					newListInput.add(ListInput.get(j));
										}}
				else {
					for(int j=0;j<min;j++){
						newListHit.add(ListHit.get(j));
						newListInput.add(ListInput.get(j+i));
					}}
				
				double newValue = this.GLscore(newListHit,newListInput,da);
				if(newValue>maxxx) maxxx=newValue;
			}
			
			return maxxx;

	}
	int numberIdenticalSSE2(ArrayList<Residue> ListHit,ArrayList<Residue> ListInput){
		int max = Math.max(ListHit.size(),ListInput.size());
		int min = Math.min(ListHit.size(),ListInput.size());
			ArrayList<Residue> newListHit0= new ArrayList<Residue>(min);
			ArrayList<Residue> newListInput0= new ArrayList<Residue>(min);
			for(int j=0;j<min;j++){
				newListHit0.add(ListHit.get(j));
				newListInput0.add(ListInput.get(j));
			}
			int maxxx =this.numberIdenticalSSE(newListHit0,newListInput0);
			
			for(int i=1;i<max-min+1;i++){
				ArrayList<Residue> newListHit= new ArrayList<Residue>(min);
				ArrayList<Residue> newListInput= new ArrayList<Residue>(min);
				if(ListHit.size()>=ListInput.size()){
				for(int j=0;j<min;j++){
					newListHit.add(ListHit.get(j+i));
					newListInput.add(ListInput.get(j));
										}}
				else {
					for(int j=0;j<min;j++){
						newListHit.add(ListHit.get(j));
						newListInput.add(ListInput.get(j+i));
					}}
				
				int newValue = this.numberIdenticalSSE(newListHit,newListInput);
				if(newValue>maxxx) maxxx=newValue;
			}
			
			return maxxx;

	}
	
	
	LinkedList<FragmentAlignment> fragmentAlignments1(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput)
		throws Exception {
		LinkedList<FragmentAlignment> listInitialAlignment = new LinkedList<FragmentAlignment>();
		int min = Math.min(ListHit.size(), ListInput.size());
		int L = 8;
		if (min > 100)
			L = 12;
		int size1 = (int) (ListHit.size() / L);
		int size2 = (int) (ListInput.size() / L);
		ArrayList<Fragment> ListHitFr = new ArrayList<Fragment>(size1);
		ArrayList<Fragment> ListInputFr = new ArrayList<Fragment>(size2);
		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> ListHitFragment = new ArrayList<Residue>();
				ArrayList<Residue> ListInputFragment = new ArrayList<Residue>();
				for (int i = i1 * L; i < (i1 + 1) * L; i++)
					ListHitFragment.add(ListHit.get(i));
				for (int j = i2 * L; j < (i2 + 1) * L; j++)
					ListInputFragment.add(ListInput.get(j));

				ListHitFr.add(new Fragment(ListHitFragment));
				ListInputFr.add(new Fragment(ListInputFragment));
				// next step is calculating S(i1,i2)
				int IdenticalSSE = this.numberIdenticalSSE(ListHitFragment, ListInputFragment);
				double GLscore = this.GLscore(ListHitFragment, ListInputFragment, 0.5);
				listInitialAlignment.add(new FragmentAlignment(new Fragment(ListHitFragment),
					new Fragment(ListInputFragment), GLscore, IdenticalSSE));

			}
		}

		Collections.sort(listInitialAlignment, new FragmentAlignmentComparator());
		System.out.println(listInitialAlignment.get(0).GLscore + " first");
		System.out.println(listInitialAlignment.get(1).GLscore + " second");
		System.out.println(listInitialAlignment.get(2).GLscore + " third");

		return listInitialAlignment;
	}

	double getEvolutionSimilarityScore(ArrayList<Residue> hit, ArrayList<Residue> input) {
		// score=Math.max(0, BLOSUM+CLESUM);
		int size = hit.size();
		int Lmin = Math.min(hit.size(), input.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (Lmin > 15)
			d0 = 1.24 * Math.pow((Lmin - 15), ex) - 1.8;
		double sum = 0.0;
		for (int i = 1; i < size - 1; i++) {
			char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
			char b = this.WWW_Three2One_III(input.get(i).Residue_Name);
			double CLESUM = this.CLESUM_Calc(a, b);
			double dii = hit.get(i).list_Atoms.get(1).Atom_Coordinate
				.distanceTo(input.get(i).list_Atoms.get(1).Atom_Coordinate);
			double dd = 1.0 / (1 + (dii * dii / (d0 * d0)));
			double BLOSUM = this.BLOSUM62_Calc(a, b);
			double scoreii = Math.max(0, BLOSUM + CLESUM);
			sum = sum + scoreii;
		}
		System.out.println("CYS: " + this.BLOSUM62_Calc(this.WWW_Three2One_III("CYS"), this.WWW_Three2One_III("CYS")));
		return sum;
	}

	double[] evolutionSimilarityScore(ArrayList<Residue> hit, ArrayList<Residue> input, int Lmin) {
		// score=Math.max(0, BLOSUM+CLESUM);
		int size = hit.size();
		// int Lmin = Math.min(hit.size(), input.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (Lmin > 15)
			d0 = 1.24 * Math.pow((Lmin - 15), ex) - 1.8;
		double blosum = 0.0;
		double clesum = 0.0;
		double hydr = 0.0;
		double evolv = 0.0;
		for (int i = 1; i < size - 1; i++) {
			double hydrSim = 0.0;
			if (hit.get(i).list_Atoms.size() > 4 && input.get(i).list_Atoms.size() > 4) {
				hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
					hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i).list_Atoms.get(4).Atom_Coordinate,
					hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
					input.get(i - 1).list_Atoms.get(1).Atom_Coordinate, input.get(i).list_Atoms.get(1).Atom_Coordinate,
					input.get(i).list_Atoms.get(4).Atom_Coordinate, input.get(i + 1).list_Atoms.get(1).Atom_Coordinate);
			} else {
				hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
					hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
					input.get(i - 1).list_Atoms.get(1).Atom_Coordinate, input.get(i).list_Atoms.get(1).Atom_Coordinate,
					input.get(i + 1).list_Atoms.get(1).Atom_Coordinate);
			}
			char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
			char b = this.WWW_Three2One_III(input.get(i).Residue_Name);
			double CLESUM = this.CLESUM_Calc(a, b);
			double dii = hit.get(i).list_Atoms.get(1).Atom_Coordinate
				.distanceTo(input.get(i).list_Atoms.get(1).Atom_Coordinate);
			double dd = 1.0 / (1 + (dii * dii / (d0 * d0)));
			double BLOSUM = this.BLOSUM62_Calc(a, b);
			double scoreij = Math.max(0, BLOSUM + CLESUM) * hydrSim * dd;

			blosum = blosum + BLOSUM;
			clesum = clesum + CLESUM;
			hydr = hydr + hydrSim;
			evolv = evolv + scoreij;
		}
		double[] a = new double[4];
		a[0] = blosum / (size - 2);
		a[1] = clesum / (size - 2);
		a[2] = hydr / (size - 2);
		a[3] = evolv / (size - 2);
		System.out.println("CYS: " + this.BLOSUM62_Calc(this.WWW_Three2One_III("CYS"), this.WWW_Three2One_III("CYS")));
		return a;
	}

	double[] evolutionSimilarityScore1(ArrayList<Residue> hit, ArrayList<Residue> input, int Lmin) {
		// score=Math.max(0, BLOSUM+CLESUM);
		int size1 = hit.size();
		int size2 = input.size();
		MT S = new MT(size1 - 2, size2 - 2);// sacrifice the first and last
		MT S1 = new MT(size1 - 2, size2 - 2);// sacrifice the first and last
		MT S2 = new MT(size1 - 2, size2 - 2);// sacrifice the first and last
		MT S3 = new MT(size1 - 2, size2 - 2);// sacrifice the first and last
		// int Lmin=Math.min(hit.size(), input.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (Lmin > 15)
			d0 = 1.24 * Math.pow((Lmin - 15), ex) - 1.8;
		// double sum=0.0;
		for (int i = 1; i < size1 - 1; i++)
			for (int j = 1; j < size2 - 1; j++) {
				double hydrSim = 0.0;
				if (hit.get(i).list_Atoms.size() > 4 && input.get(j).list_Atoms.size() > 4) {
					hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
						hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i).list_Atoms.get(4).Atom_Coordinate,
						hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j).list_Atoms.get(1).Atom_Coordinate, input.get(j).list_Atoms.get(4).Atom_Coordinate,
						input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
				} else {
					hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
						hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j).list_Atoms.get(1).Atom_Coordinate,
						input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
				}
				char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
				char b = this.WWW_Three2One_III(input.get(j).Residue_Name);
				double CLESUM = this.CLESUM_Calc(a, b);
				double dij = hit.get(i).list_Atoms.get(1).Atom_Coordinate
					.distanceTo(input.get(j).list_Atoms.get(1).Atom_Coordinate);
				double dd = 1.0 / (1 + (dij * dij / (d0 * d0)));
				double BLOSUM = this.BLOSUM62_Calc(a, b);
				double scoreij = Math.max(0, BLOSUM + CLESUM) * hydrSim * dd;
				S.data[i - 1][j - 1] = scoreij;
				S1.data[i - 1][j - 1] = BLOSUM;
				S2.data[i - 1][j - 1] = CLESUM;
				S3.data[i - 1][j - 1] = hydrSim;
				// sum=sum+scoreii;
			}
		double blosum = 0.0;
		double clesum = 0.0;
		double hydr = 0.0;
		double evolv = 0.0;
		for (int i = 0; i < S1.M; i++) {
			blosum = blosum + S1.data[i][i];
			clesum = clesum + S2.data[i][i];
			hydr = hydr + S3.data[i][i];
			evolv = evolv + S.data[i][i];
		}
		double[] a = new double[4];
		a[0] = blosum / S1.M;
		a[1] = clesum / S1.M;
		a[2] = hydr / S1.M;
		a[3] = evolv / S1.M;
		System.out.println("CYS: " + this.BLOSUM62_Calc(this.WWW_Three2One_III("CYS"), this.WWW_Three2One_III("CYS")));
		return a;
	}

	ArrayList<HashMap<String, String>> creatColorJmolValueUsingBlosum2(PreAlignment pre) {
		ArrayList<HashMap<String, String>> aa = new ArrayList<HashMap<String, String>>(2);
		HashMap<String, String> input = new HashMap<String, String>();
		HashMap<String, String> hit = new HashMap<String, String>();
		int n = pre.getListHitResidues().size();
		for (int i = 0; i < n; i++) {
			String inn = pre.getListInputResidues().get(i).Residue_Name;
			String hitt = pre.getListHitResidues().get(i).Residue_Name;
			String s3 = pre.getListInputResidues().get(i).get_ResidueName_ChainName_ResidueNumber();
			String s4 = pre.getListHitResidues().get(i).get_ResidueName_ChainName_ResidueNumber();
			if (this.equivalent_identical(inn, hitt)) {
				input.put(s3, "100.00");
				hit.put(s4, "100.00");
			} else if (this.similar(inn, hitt)) {
				input.put(s3, " 70.00");
				hit.put(s4, " 70.00");
			} else {
				input.put(s3, " 30.00");
				hit.put(s4, " 30.00");
			}

		}
		aa.add(input);
		aa.add(hit);
		return aa;
	}

	ArrayList<HashMap<String, String>> creatColorJmolValueUsingBlosum(PreAlignment pre) {
		ArrayList<HashMap<String, String>> aa = new ArrayList<HashMap<String, String>>(2);
		HashMap<String, String> input = new HashMap<String, String>();
		HashMap<String, String> hit = new HashMap<String, String>();
		int n = pre.getListHitResidues().size();
		for (int i = 0; i < n; i++) {
			String inn = pre.getListInputResidues().get(i).Residue_Name;
			String hitt = pre.getListHitResidues().get(i).Residue_Name;
			String s3 = pre.getListInputResidues().get(i).get_ResidueName_ChainName_ResidueNumber();
			String s4 = pre.getListHitResidues().get(i).get_ResidueName_ChainName_ResidueNumber();

			char a = this.WWW_Three2One_III(hitt);
			char b = this.WWW_Three2One_III(inn);
			double BLOSUM = this.BLOSUM62_Calc(a, b);
			String va = "";
			if (BLOSUM <= 0)
				va = "  0.00";
			else {
				BLOSUM = 10 * BLOSUM;
				if (BLOSUM < 10.0)
					va = "  " + String.format("%.2f", BLOSUM);
				else if (BLOSUM < 100.0)
					va = " " + String.format("%.2f", BLOSUM);
				else
					va = "100.00";
			}
			input.put(s3, va);
			hit.put(s4, va);

		}
		aa.add(input);
		aa.add(hit);
		return aa;
	}

	ArrayList<HashMap<String, String>> creatColorJmolValueUsingDistance(PreAlignment pre) {
		ArrayList<HashMap<String, String>> aa = new ArrayList<HashMap<String, String>>(2);
		HashMap<String, String> input = new HashMap<String, String>();
		HashMap<String, String> hit = new HashMap<String, String>();
		int n = pre.getListHitResidues().size();
		MT S = new MT(n, n);
		MT R = pre.get_rotational_Matrix();
		Point O2 = pre.center_of_HitResidues();// pdb 25
		Point O1 = pre.center_of_inputResidues();
		for (int i = 0; i < n; i++) {
			Residue I = pre.getListInputResidues().get(i);
			Residue H = pre.getListHitResidues().get(i);
			Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
			Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
			MT I1 = new MT(3, 1);
			I1.data[0][0] = CAI.x - O1.x;
			I1.data[1][0] = CAI.y - O1.y;
			I1.data[2][0] = CAI.z - O1.z;
			MT I2 = R.times(I1);
			double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
				+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
			double d = 10 * Math.sqrt(ddij);// Fabio suggest :)

			String s3 = pre.getListInputResidues().get(i).get_ResidueName_ChainName_ResidueNumber();
			String s4 = pre.getListHitResidues().get(i).get_ResidueName_ChainName_ResidueNumber();
			String s = "";
			if (d < 10.0)
				s = "  " + String.format("%.2f", d);
			else if (d < 100.0)
				s = " " + String.format("%.2f", d);
			else
				s = "" + String.format("%.2f", d);
			s = s.replace(',', '.');
			input.put(s3, s);
			hit.put(s4, s);
		}

		aa.add(input);
		aa.add(hit);
		return aa;
	}

	public boolean similar(String s1, String s2) {
		String[][] table = new String[4][9];
		table[0][0] = " VAL";
		table[0][1] = "AVAL";
		table[0][2] = "BVAL";
		table[0][3] = " LEU";
		table[0][4] = "ALEU";
		table[0][5] = "BLEU";
		table[0][6] = " ILE";
		table[0][7] = "AILE";
		table[0][8] = "BILE";
		table[1][0] = " ASP";
		table[1][1] = "AASP";
		table[1][2] = "BASP";
		table[1][3] = " GLU";
		table[1][4] = "AGLU";
		table[1][5] = "BGLU";
		table[2][0] = " SER";
		table[2][1] = "ASER";
		table[2][2] = "BSER";
		table[2][3] = " THR";
		table[2][4] = "ATHR";
		table[2][5] = "BTHR";
		table[3][0] = " ASN";
		table[3][1] = "AASN";
		table[3][2] = "BASN";
		table[3][3] = " GLN";
		table[3][4] = "AGLN";
		table[3][5] = "BGLN";

		if (this.equivalent_identical(s1, s2))
			return false;
		else {
			int t1 = 0, t2 = 10;
			for (int i = 0; i < 4; i++)
				for (int j = 0; j < 9; j++) {
					if (table[i][j] != null) {
						if (table[i][j].equalsIgnoreCase(s1))
							t1 = i;
						if (table[i][j].equalsIgnoreCase(s2))
							t2 = i;
					}
				}
			if (t1 == t2)
				return true;
			else
				return false;
		}
	}

	public boolean equivalent_identical(String s1, String s2) {
		String[][] table = new String[20][3];
		table[0][0] = " GLY";
		table[0][1] = "AGLY";
		table[0][2] = "BGLY";
		table[1][0] = " ALA";
		table[1][1] = "AALA";
		table[1][2] = "BALA";
		table[2][0] = " VAL";
		table[2][1] = "AVAL";
		table[2][2] = "BVAL";
		table[3][0] = " LEU";
		table[3][1] = "ALEU";
		table[3][2] = "BLEU";
		table[4][0] = " ILE";
		table[4][1] = "AILE";
		table[4][2] = "BILE";
		table[5][0] = " PHE";
		table[5][1] = "APHE";
		table[5][2] = "BPHE";
		table[6][0] = " ASP";
		table[6][1] = "AASP";
		table[6][2] = "BASP";
		table[7][0] = " GLU";
		table[7][1] = "AGLU";
		table[7][2] = "BGLU";
		table[8][0] = " LYS";
		table[8][1] = "ALYS";
		table[8][2] = "BLYS";
		table[9][0] = " SER";
		table[9][1] = "ASER";
		table[9][2] = "BSER";
		table[10][0] = " THR";
		table[10][1] = "ATHR";
		table[10][2] = "BTHR";
		table[11][0] = " TYR";
		table[11][1] = "ATYR";
		table[11][2] = "BTYR";
		table[12][0] = " CYS";
		table[12][1] = "ACYS";
		table[12][2] = "BCYS";
		table[13][0] = " ASN";
		table[13][1] = "AASN";
		table[13][2] = "BASN";
		table[14][0] = " GLN";
		table[14][1] = "AGLN";
		table[14][2] = "BGLN";
		table[15][0] = " PRO";
		table[15][1] = "APRO";
		table[15][2] = "BPRO";
		table[16][0] = " MET";
		table[16][1] = "AMET";
		table[16][2] = "BMET";
		table[17][0] = " ARG";
		table[17][1] = "AARG";
		table[17][2] = "BARG";
		table[18][0] = " HIS";
		table[18][1] = "AHIS";
		table[18][2] = "BHIS";
		table[19][0] = " TRP";
		table[19][1] = "ATRP";
		table[19][2] = "BTRP";

		int t1 = 0, t2 = 100;
		for (int i = 0; i < 20; i++)
			for (int j = 0; j < 3; j++) {
				if (table[i][j].equalsIgnoreCase(s1))
					t1 = i;
				if (table[i][j].equalsIgnoreCase(s2))
					t2 = i;
			}
		if (t1 == t2)
			return true;
		else
			return false;
	}

	MT getEvolutionSimilarityScoreMatrix(ArrayList<Residue> hit, ArrayList<Residue> input, int Lmin) {
		// score=Math.max(0, BLOSUM+CLESUM);
		int size1 = hit.size();
		int size2 = input.size();
		MT S = new MT(size1 - 2, size2 - 2);// sacrifice the first and last
		// int Lmin=Math.min(hit.size(), input.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (Lmin > 15)
			d0 = 1.24 * Math.pow((Lmin - 15), ex) - 1.8;
		// double sum=0.0;
		for (int i = 1; i < size1 - 1; i++)
			for (int j = 1; j < size2 - 1; j++) {
				double hydrSim = 0.0;
				if (hit.get(i).list_Atoms.size() > 4 && input.get(j).list_Atoms.size() > 4) {
					hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
						hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i).list_Atoms.get(4).Atom_Coordinate,
						hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j).list_Atoms.get(1).Atom_Coordinate, input.get(j).list_Atoms.get(4).Atom_Coordinate,
						input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
				} else {
					hydrSim = this.hydrogenBondSimilarity(hit.get(i - 1).list_Atoms.get(1).Atom_Coordinate,
						hit.get(i).list_Atoms.get(1).Atom_Coordinate, hit.get(i + 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j - 1).list_Atoms.get(1).Atom_Coordinate,
						input.get(j).list_Atoms.get(1).Atom_Coordinate,
						input.get(j + 1).list_Atoms.get(1).Atom_Coordinate);
				}
				char a = this.WWW_Three2One_III(hit.get(i).Residue_Name);
				char b = this.WWW_Three2One_III(input.get(j).Residue_Name);
				double CLESUM = this.CLESUM_Calc(a, b);
				double dij = hit.get(i).list_Atoms.get(1).Atom_Coordinate
					.distanceTo(input.get(j).list_Atoms.get(1).Atom_Coordinate);
				double dd = 1.0 / (1 + (dij * dij / (d0 * d0)));
				double BLOSUM = this.BLOSUM62_Calc(a, b);
				double scoreij = Math.max(0, BLOSUM + CLESUM) * hydrSim * dd;
				S.data[i - 1][j - 1] = scoreij;
				if (dij > 3 * d0)
					S.data[i - 1][j - 1] = 0.0;
				// sum=sum+scoreii;
			}
		System.out.println("CYS: " + this.BLOSUM62_Calc(this.WWW_Three2One_III("CYS"), this.WWW_Three2One_III("CYS")));
		return S;
	}

	LinkedList<PreAlignment> fragmentAlignments(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput)
		throws Exception {
		LinkedList<PreAlignment> listInitialAlignment = new LinkedList<PreAlignment>();
		int min = Math.min(ListHit.size(), ListInput.size());
		int fragmentLength = 8;
		if (min > 100)
			fragmentLength = 12;
		int size1 = (int) (ListHit.size() / fragmentLength);
		int size2 = (int) (ListInput.size() / fragmentLength);
		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> hit = new ArrayList<Residue>();
				ArrayList<Residue> input = new ArrayList<Residue>();
				for (int i = i1 * fragmentLength; i < (i1 + 1) * fragmentLength; i++)
					hit.add(ListHit.get(i));
				for (int j = i2 * fragmentLength; j < (i2 + 1) * fragmentLength; j++)
					input.add(ListInput.get(j));

				// next step is calculating S(i1,i2)

				listInitialAlignment.add(new PreAlignment(hit, input, input.size()));

			}
		}

		// Collections.sort(listInitialAlignment, new PreAlignmentRMSDComparator());

		return listInitialAlignment;
	}

	LinkedList<PreAlignment> fragmentAlignments1(int fragmentLength, ArrayList<Residue> ListHit,
		ArrayList<Residue> ListInput)
		throws Exception {
		LinkedList<PreAlignment> listInitialAlignment = new LinkedList<PreAlignment>();
		int min = Math.min(ListHit.size(), ListInput.size());
		// int fragmentLength = 6;
		// if (min > 100)
		// L = 12;
		int size1 = (int) (ListHit.size() / fragmentLength);
		int size2 = (int) (ListInput.size() / fragmentLength);
		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> hit = new ArrayList<Residue>();
				ArrayList<Residue> input = new ArrayList<Residue>();
				for (int i = i1 * fragmentLength; i < (i1 + 1) * fragmentLength; i++)
					hit.add(ListHit.get(i));
				for (int j = i2 * fragmentLength; j < (i2 + 1) * fragmentLength; j++)
					input.add(ListInput.get(j));

				// next step is calculating S(i1,i2)

				listInitialAlignment.add(new PreAlignment(hit, input, input.size()));

			}
		}

		// Collections.sort(listInitialAlignment, new PreAlignmentRMSDComparator());

		return listInitialAlignment;
	}


	ArrayList<PreAlignment> complete_FragmentAlignments(ArrayList<Residue> hit, ArrayList<Residue> input)
		throws Exception {
		
		// Fr-TMalign initial alignment
		ArrayList<PreAlignment> listInitialAlignment = new ArrayList<PreAlignment>();
		int min = Math.min(hit.size(), input.size());
		int fragmentLength = 8;
		// if (min <= 200)
		// fragmentLength = 8;
		// else if (min >= 200 && min < 400)
		// fragmentLength = 12;
		// else
		// fragmentLength = 16;
		// System.out.println("leng Frag" + fragmentLength);
		int size1 = (int) (hit.size() / fragmentLength);
		int size2 = (int) (input.size() / fragmentLength);
		MT S1 = new MT(size1, size2);
		MT S4 = new MT(size1, size2);
		MT S2 = new MT(size1, size2);
		S5 = new MT(size1, size2);
		MT S3 = new MT(size1, size2);
		MT S6 = new MT(size1, size2);
		MT S7 = new MT(size1, size2);
		MT S8 = new MT(size1, size2);
		ArrayList<Fragment> ListHitFr = new ArrayList<Fragment>(size1);
		ArrayList<Fragment> ListInputFr = new ArrayList<Fragment>(size2);
		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> ListHitFragment = new ArrayList<Residue>();
				ArrayList<Residue> ListInputFragment = new ArrayList<Residue>();
				for (int i = i1 * fragmentLength; i < (i1 + 1) * fragmentLength; i++)
					ListHitFragment.add(hit.get(i));
				for (int j = i2 * fragmentLength; j < (i2 + 1) * fragmentLength; j++)
					ListInputFragment.add(input.get(j));

				ListHitFr.add(new Fragment(ListHitFragment));
				ListInputFr.add(new Fragment(ListInputFragment));
				// next step is calculating S(i1,i2)

				int IdenticalSSE = this.numberIdenticalSSE(ListHitFragment, ListInputFragment);
				// double GLscore = this.GLscore(ListHitFragment, ListInputFragment, da);
				double[] GLscores = this.GLscore3(ListHitFragment, ListInputFragment);
				// System.out.println(GLscores[0]);
				// System.out.println(GLscores[1]);
				// System.out.println(GLscores[2]);
				// System.out.println(GLscores[3]);


				S1.data[i1][i2] = GLscores[0] + 0.5 * IdenticalSSE;
				S2.data[i1][i2] = GLscores[1] + 0.5 * IdenticalSSE;
				S3.data[i1][i2] = GLscores[2] + 0.5 * IdenticalSSE;
				S4.data[i1][i2] = GLscores[3] + 0.5 * IdenticalSSE;

				S5.data[i1][i2] = GLscores[0];
				S6.data[i1][i2] = GLscores[1];
				S7.data[i1][i2] = GLscores[2];
				S8.data[i1][i2] = GLscores[3];
			}
		}
		// next step is to align two sets of fragments
		
		/*
		 * We have used two scoring matrices for DP, G(I, J) and (G(I, J)+S(I, J))/2, along with three different gap
		 * opening penalties of -0.6, -0.1 and 0.0, which are chosen empirically to generate various fragment alignments
		 */

		double[] p = new double[3];
		p[0] = -0.6;
		p[1] = 0.0;
		int checkToStop = 0;
		MT SS5 = S5;
		for (int u = 0; u < 2; u++) {
			// System.out.println("da = 0.25, SSE");
			// listInitialAlignment.addAll(this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S1,
			// p[u],
			// hit, input, checkToStop));
			// System.out.println("da = 0.5, SSE");
			// listInitialAlignment.addAll(this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S2,
			// p[u],
			// hit, input, checkToStop));
			// System.out.println("da = 1.0, SSE");
			// listInitialAlignment
			// .addAll(
			// this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S3, p[u],
			// hit, input, checkToStop));
			// System.out.println("da = 1.5, SSE");
			// listInitialAlignment
			// .addAll(
			// this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S4, p[u],
			// hit, input, checkToStop));
			System.out.println("da = 0.25");
			S5 = SS5;
			for (int k = 0; k < 50; k++) {
				System.out.println("loop" + k);
				listInitialAlignment
					.addAll(this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, p[u], hit, input));
			}
			// System.out.println("da = 0.5");
			// listInitialAlignment
			// .addAll(
			// this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S6, p[u],
			// hit, input, checkToStop));
			// System.out.println("da = 1.0");
			// listInitialAlignment
			// .addAll(
			// this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S7, p[u],
			// hit, input, checkToStop));
			// System.out.println("da = 1.5, SSE");
			// listInitialAlignment
			// .addAll(
			// this.alignTwoListOfFragmentsUsingSmithWaterman(ListHitFr, ListInputFr, S8, p[u],
			// hit, input, checkToStop));
		}

		return listInitialAlignment;
	}

	PreAlignment usingFragmentsWithEvolScore(ArrayList<Residue> hit, ArrayList<Residue> input, String knownpath)
		throws Exception {

		ArrayList<PreAlignment> initials = new ArrayList<PreAlignment>();
		LinkedList<PreAlignment> ls = new LinkedList<PreAlignment>();
		int Lmin = Math.min(hit.size(), input.size());
		int fragmentLength = 20;
		int size1 = (int) (hit.size() / fragmentLength);
		int size2 = (int) (input.size() / fragmentLength);
		// MT S1 = new MT(size1, size2);

		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> hitFrag = new ArrayList<Residue>();
				ArrayList<Residue> inputFrag = new ArrayList<Residue>();
				for (int i = i1 * fragmentLength; i < (i1 + 1) * fragmentLength; i++)
					hitFrag.add(hit.get(i));
				for (int j = i2 * fragmentLength; j < (i2 + 1) * fragmentLength; j++)
					inputFrag.add(input.get(j));
				// next step is calculating S(i1,i2)
				double evolScore = this.getEvolutionSimilarityScore(hitFrag, inputFrag);
				ls.add(new PreAlignment(hitFrag, inputFrag, evolScore));

				// S1.data[i1][i2] = 0.5 * GLscores[0] + 0.5 * IdenticalSSE;
			}
		}

		// sort

		Collections.sort(ls, new PreAlignmentEvolScoreComparator());
		// refine
		for (int u = 0; u < Math.min(20, ls.size()); u++) {
			System.out.println("uuuu" + u);
			PreAlignment pre = this.HeuriticIteration_for_one_InitialAlignmentUsingEvolScore(hit, input, ls.get(u));
			initials.add(pre);
		}

		PreAlignment pre0 = initials.get(0);
		double tm = pre0.getTMscore();
		for (int k = 1; k < initials.size(); k++) {
			double tmk = initials.get(k).getTMscore();
			if (tmk > tm) {
				pre0 = initials.get(k);
				tm = tmk;
			}
		}

		return pre0;
	}

	MT similarityMatrixFromFragmentsUsingSSE(ArrayList<Residue> hit, ArrayList<Residue> input) throws Exception {
		// Fr-TMalign initial alignment
		int L = 8;// length Fragment
		int lmin = Math.min(hit.size(), input.size());
		if (lmin > 100)
			L = 12;
		int size1 = (int) (hit.size() / L);
		int size2 = (int) (input.size() / L);
		// MT score = new MT(size1 * L, size2 * L);

		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;// 0.168;// 0.5;
		double d8 = 1.5 * Math.pow(lmin * 1.0, 0.3) + 3.5;
		if (lmin > 19)
			d0 = 1.24 * Math.pow((lmin - 15), ex) - 1.8;
		System.out.println("d0= " + d0);

		MT score = new MT(hit.size(), input.size());
		for (int u = size1 * L; u < hit.size(); u++)
			for (int v = size2 * L; v < input.size(); v++) {
				score.data[u][v] = 0.0;
			}

		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> ListHitFragment = new ArrayList<Residue>();
				ArrayList<Residue> ListInputFragment = new ArrayList<Residue>();
				for (int i = i1 * L; i < (i1 + 1) * L; i++)
					ListHitFragment.add(hit.get(i));
				for (int j = i2 * L; j < (i2 + 1) * L; j++)
					ListInputFragment.add(input.get(j));
				// next step is calculating Score(u,v)

				PreAlignment Pre = new PreAlignment(ListHitFragment, ListInputFragment, L);
				// MT S = new MT(ListHitFragment.size(),ListInputFragment.size());
				MT R = Pre.get_rotational_Matrix();
				Point O2 = Pre.center_of_HitResidues();// pdb 25
				Point O1 = Pre.center_of_inputResidues();
				for (int i = 0; i < ListHitFragment.size(); i++)
					for (int j = 0; j < ListInputFragment.size(); j++) {
						Residue H = ListHitFragment.get(i);
						Residue I = ListInputFragment.get(j);
						Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
						Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
						MT I1 = new MT(3, 1);
						I1.data[0][0] = CAI.x - O1.x;
						I1.data[1][0] = CAI.y - O1.y;
						I1.data[2][0] = CAI.z - O1.z;
						MT I2 = R.times(I1);
						double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2)
							+ Math.pow(CAH.y - O2.y - I2.data[1][0], 2) + Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
						double dij = Math.sqrt(ddij);
						score.data[i + i1 * L][j + i2 * L] = 1.0 / (1 + (dij * dij / (d0 * d0)));
						if (H.label == I.label)
							score.data[i + i1 * L][j + i2 * L] = score.data[i + i1 * L][j + i2 * L] + 0.5;
						if (dij > d8)
							score.data[i + i1 * L][j + i2 * L] = 0.0;

					}

				// finish calculating S(u,v)

			}
		}
		// next step is to align two sets of fragments

		/*
		 * We have used two scoring matrices for DP, G(I, J) and (G(I, J)+S(I, J))/2, along with three different gap
		 * opening penalties of -0.6, -0.1 and 0.0, which are chosen empirically to generate various fragment alignments
		 */

		return score;
	}

	MT similarityMatrixFromFragments(ArrayList<Residue> hit, ArrayList<Residue> input) throws Exception {
		// Fr-TMalign initial alignment
		int L = 8;// length Fragment
		int lmin = Math.min(hit.size(), input.size());
		if (lmin > 100)
			L = 12;
		int size1 = (int) (hit.size() / L);
		int size2 = (int) (input.size() / L);
		// MT score = new MT(size1 * L, size2 * L);

		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;// 0.168;// 0.5;
		double d8 = 1.5 * Math.pow(lmin * 1.0, 0.3) + 3.5;
		if (lmin > 19)
			d0 = 1.24 * Math.pow((lmin - 15), ex) - 1.8;
		System.out.println("d0= " + d0);

		MT score = new MT(hit.size(), input.size());
		for (int u = size1 * L; u < hit.size(); u++)
			for (int v = size2 * L; v < input.size(); v++) {
				score.data[u][v] = 0.0;
			}


		for (int i1 = 0; i1 < size1; i1++) {
			for (int i2 = 0; i2 < size2; i2++) {
				ArrayList<Residue> ListHitFragment = new ArrayList<Residue>();
				ArrayList<Residue> ListInputFragment = new ArrayList<Residue>();
				for (int i = i1 * L; i < (i1 + 1) * L; i++)
					ListHitFragment.add(hit.get(i));
				for (int j = i2 * L; j < (i2 + 1) * L; j++)
					ListInputFragment.add(input.get(j));
				// next step is calculating Score(u,v)

				PreAlignment Pre = new PreAlignment(ListHitFragment, ListInputFragment, L);
				// MT S = new MT(ListHitFragment.size(),ListInputFragment.size());
				MT R = Pre.get_rotational_Matrix();
				Point O2 = Pre.center_of_HitResidues();// pdb 25
				Point O1 = Pre.center_of_inputResidues();
				for (int i = 0; i < ListHitFragment.size(); i++)
					for (int j = 0; j < ListInputFragment.size(); j++) {
						Residue H = ListHitFragment.get(i);
						Residue I = ListInputFragment.get(j);
						Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
						Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
						MT I1 = new MT(3, 1);
						I1.data[0][0] = CAI.x - O1.x;
						I1.data[1][0] = CAI.y - O1.y;
						I1.data[2][0] = CAI.z - O1.z;
						MT I2 = R.times(I1);
						double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2)
							+ Math.pow(CAH.y - O2.y - I2.data[1][0], 2) + Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
						double dij = Math.sqrt(ddij);
						score.data[i + i1 * L][j + i2 * L] = 1.0 / (1 + (dij * dij / (d0 * d0)));
						if (dij > d8)
							score.data[i + i1 * L][j + i2 * L] = 0.0;
						// if (H.label == I.label)
						// score.data[i + i1 * L][j + i2 * L] = score.data[i + i1 * L][j + i2 * L] + 0.5;
					}

				// finish calculating S(u,v)

			}
		}
		// next step is to align two sets of fragments

		/*
		 * We have used two scoring matrices for DP, G(I, J) and (G(I, J)+S(I, J))/2, along with three different gap
		 * opening penalties of -0.6, -0.1 and 0.0, which are chosen empirically to generate various fragment alignments
		 */

		return score;
	}
	PreAlignment initialAlignment5(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,double da,double Gap){
		//Fr-TMalign initial alignment
	MT S= new MT(ListHit.size(),ListInput.size());
	int min= Math.min(ListHit.size(),ListInput.size());
	int L=8; if(min>100) L=12;
	for (int i1=0;i1<ListHit.size();i1=i1+L){
		for (int j1=0;j1<ListInput.size();j1=j1+L){
			ArrayList<Residue> ListHitFregment= new ArrayList<Residue>();
			ArrayList<Residue> ListInputFregment= new ArrayList<Residue>();
			for(int i=i1;i<Math.min(i1+L,ListHit.size());i++)ListHitFregment.add(ListHit.get(i));
			for (int j=j1;j<Math.min(j1+L,ListInput.size());j++)ListInputFregment.add(ListInput.get(j));
		
	if(ListHitFregment.size()==ListInputFregment.size()){
			int IdenticalSSE=this.numberIdenticalSSE(ListHitFregment, ListInputFregment);
			double GLscore=this.GLscore(ListHitFregment, ListInputFregment, da);
			for(int i=i1;i<i1+L;i++){
				for (int j=j1;j<j1+L;j++){
					S.data[i][j]=0.5*GLscore+0.5*IdenticalSSE;
										}}	
													}
	else{
		int IdenticalSSE=this.numberIdenticalSSE2(ListHitFregment, ListInputFregment);
		double GLscore=this.GLscore2(ListHitFregment, ListInputFregment, da);
		for(int i=i1;i<Math.min(i1+L,ListHit.size());i++){
			for (int j=j1;j<Math.min(j1+L,ListInput.size());j++){
				S.data[i][j]=0.5*GLscore+0.5*IdenticalSSE;
									}}
	}
			
	
												}
					}
	
		return this.align(min, ListHit, ListInput, S, Gap);
}
	
	
	
	PreAlignment initialAlignment1(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput){
					//Secondary structure assignment
				MT S= new MT(ListHit.size(),ListInput.size());
		int min = Math.min(ListHit.size(), ListInput.size());
				for (int i=0;i<ListHit.size();i++)
					for (int j=0;j<ListInput.size();j++){
						if(ListHit.get(i).label==ListInput.get(j).label) S.data[i][j]=1;
						else S.data[i][j]=0;
					}
		return this.align(min, ListHit, ListInput, S, -1);
		}
	
	PreAlignment initialAlignment3(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput){
		int max = Math.max(ListHit.size(),ListInput.size());
		int min = Math.min(ListHit.size(),ListInput.size());
			ArrayList<Residue> newListHit0= new ArrayList<Residue>(min);
			ArrayList<Residue> newListInput0= new ArrayList<Residue>(min);
			for(int j=0;j<min;j++){
				newListHit0.add(ListHit.get(j));
				newListInput0.add(ListInput.get(j));
			}
			PreAlignment best0 = new PreAlignment(newListHit0,newListInput0,ListInput.size());
			
			for(int i=1;i<max-min+1;i++){
				ArrayList<Residue> newListHit= new ArrayList<Residue>(min);
				ArrayList<Residue> newListInput= new ArrayList<Residue>(min);
				if(ListHit.size()>=ListInput.size()){
				for(int j=0;j<min;j++){
					newListHit.add(ListHit.get(j+i));
					newListInput.add(ListInput.get(j));
										}}
				else {
					for(int j=0;j<min;j++){
						newListHit.add(ListHit.get(j));
						newListInput.add(ListInput.get(j+i));
					}}
				
				PreAlignment best = new PreAlignment(newListHit,newListInput,ListInput.size());
				if(best.getTMscore()>best0.getTMscore()) best0=best;
			}
			
			if(best0.ListHitResidues.size()>2) return best0; else return null;
		}
	PreAlignment initialAlignment2(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput){
		int max = Math.max(ListHit.size(),ListInput.size());
		int min = Math.min(ListHit.size(),ListInput.size());
			ArrayList<Residue> newListHit0= new ArrayList<Residue>(min);
			ArrayList<Residue> newListInput0= new ArrayList<Residue>(min);
			for(int j=0;j<min;j++){
				newListHit0.add(ListHit.get(j));
				newListInput0.add(ListInput.get(j));
			}
			PreAlignment best0 = new PreAlignment(newListHit0,newListInput0,ListInput.size());
			
			for(int i=1;i<max-min+1;i++){
				ArrayList<Residue> newListHit= new ArrayList<Residue>(min);
				ArrayList<Residue> newListInput= new ArrayList<Residue>(min);
				if(ListHit.size()>=ListInput.size()){
				for(int j=0;j<min;j++){
					newListHit.add(ListHit.get(j+i));
					newListInput.add(ListInput.get(j));
										}}
				else {
					for(int j=0;j<min;j++){
						newListHit.add(ListHit.get(j));
						newListInput.add(ListInput.get(j+i));
					}}
				
				PreAlignment best = new PreAlignment(newListHit,newListInput,ListInput.size());
				if(best.get_RMSD()>best0.get_RMSD()) best0=best;
			}
			
			if(best0.ListHitResidues.size()>2) return best0; else return null;
		}
	
	
	
	PreAlignment initialAlignment4(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,PreAlignment best3 ){
		if(best3==null) return null;	
		int min = Math.min(ListHit.size(), ListInput.size());
		MT S2= this.getSimilarityMTfromPreAlignmentTM(ListHit, ListInput, best3);
			MT S3= new MT(S2.M,S2.N);
			for (int i = 0; i < S3.M; i++) 
	          	  for (int j = 0; j < S3.N; j++){
	          		Residue H =ListHit.get(i);
					Residue I =ListInput.get(j);
	          		  	if(H.label==I.label) 
	          		  	///if(H.label==I.label&&H.polarity==I.polarity)
	          		  		 S3.data[i][j]=S2.data[i][j]+0.5;
	          		  	else S3.data[i][j]=S2.data[i][j];
	          	  }
		return this.align(min, ListHit, ListInput, S3, -1);
			
		}
	int getMax(ArrayList<Double> P){
		double currentMax = P.get(0);
		int max=0;
		for(int i=1;i<P.size();i++){
			if(P.get(i)>currentMax){currentMax = P.get(i);max=i;}
			}
		return max;
	}
	
	MT getSimilarityMTfromPreAlignment(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,PreAlignment pre){
			
			MT S = new MT(ListHit.size(),ListInput.size());
			MT R= pre.get_rotational_Matrix();
			Point O2=pre.center_of_HitResidues();//pdb 25
			Point O1=pre.center_of_inputResidues();
			for (int i=0;i<ListHit.size();i++)
				for (int j=0;j<ListInput.size();j++){
					Residue H =ListHit.get(i);
					Residue I =ListInput.get(j);
					Point CAH=H.list_Atoms.get(1).Atom_Coordinate;
					Point CAI=I.list_Atoms.get(1).Atom_Coordinate;
					MT I1= new MT(3,1);
						I1.data[0][0]=CAI.x-O1.x;
						I1.data[1][0]=CAI.y-O1.y;
						I1.data[2][0]=CAI.z-O1.z;
						MT I2=R.times(I1);
						double ddij=Math.pow(CAH.x-O2.x-I2.data[0][0],2)+Math.pow(CAH.y-O2.y-I2.data[1][0],2)+Math.pow(CAH.z-O2.z-I2.data[2][0],2);
						//double dij=Math.sqrt(ddij);
						//if(H.label==I.label)
						S.data[i][j]=100/(5+ddij);
						//else S.data[i][j]=100/(5+ddij);
				}
		return S;}
	
	MT getRMSDsimilarityMaTrixfromPreAlignment1(double sse, PreAlignment pre, int min, double d8) {
		ArrayList<Residue> ListHit = pre.getListHitResidues();
		ArrayList<Residue> ListInput = pre.getListInputResidues();
		MT S = new MT(ListHit.size(), ListInput.size());
		MT R = pre.get_rotational_Matrix();
		Point O2 = pre.center_of_HitResidues();// pdb 25
		Point O1 = pre.center_of_inputResidues();
		// min = Math.min(ListInput.size(), ListHit.size());
		double ex = (double) 1.0 / 3.0;
		double d0 = 0.5;
		if (min > 15)
			d0 = 1.24 * Math.pow((min - 15), ex) - 1.8;

		for (int i = 0; i < ListHit.size(); i++)
			for (int j = 0; j < ListInput.size(); j++) {
				Residue H = ListHit.get(i);
				Residue I = ListInput.get(j);
				Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
				Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
				MT I1 = new MT(3, 1);
				I1.data[0][0] = CAI.x - O1.x;
				I1.data[1][0] = CAI.y - O1.y;
				I1.data[2][0] = CAI.z - O1.z;
				MT I2 = R.times(I1);
				double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
					+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
				double dij = Math.sqrt(ddij);
				S.data[i][j] = 1 / (1 + (dij * dij / (d0 * d0)));
				if (H.label == I.label)
					S.data[i][j] = S.data[i][j] + sse;
				if (dij > d8)
					S.data[i][j] = 0.0;
				// S.data[i][j] = dij;

			}
		return S;
	}

	MT getRMSDsimilarityMaTrixfromPreAlignment2(PreAlignment pre, double d8) {
		ArrayList<Residue> ListHit = pre.getListHitResidues();
		ArrayList<Residue> ListInput = pre.getListInputResidues();
		MT S = new MT(ListHit.size(), ListInput.size());
		MT R = pre.get_rotational_Matrix();
		Point O2 = pre.center_of_HitResidues();// pdb 25
		Point O1 = pre.center_of_inputResidues();

		for (int i = 0; i < ListHit.size(); i++)
			for (int j = 0; j < ListInput.size(); j++) {
				Residue H = ListHit.get(i);
				Residue I = ListInput.get(j);
				Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
				Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
				MT I1 = new MT(3, 1);
				I1.data[0][0] = CAI.x - O1.x;
				I1.data[1][0] = CAI.y - O1.y;
				I1.data[2][0] = CAI.z - O1.z;
				MT I2 = R.times(I1);
				double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
					+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
				double dij = Math.sqrt(ddij);
				// S.data[i][j] = 1 / (1 + (dij * dij / (d0 * d0)));
				if (dij > d8)
					S.data[i][j] = -1.0;
				else
					S.data[i][j] = d8 - dij;

			}
		return S;
	}
	MT getRMSD_SSE_similarityMaTrixfromPreAlignment(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput,
		PreAlignment pre) {
		MT S = new MT(ListHit.size(), ListInput.size());
		MT R = pre.get_rotational_Matrix();
		Point O2 = pre.center_of_HitResidues();// pdb 25
		Point O1 = pre.center_of_inputResidues();

		// int min = Math.min(ListHit.size(),ListInput.size());
		// double ex = (double)1.0/3.0;
		// double d0=0.5;
		// if (min>15) d0=1.24*Math.pow((min-15),ex)-1.8;
		for (int i = 0; i < ListHit.size(); i++)
			for (int j = 0; j < ListInput.size(); j++) {
				Residue H = ListHit.get(i);
				Residue I = ListInput.get(j);
				Point CAH = H.list_Atoms.get(1).Atom_Coordinate;
				Point CAI = I.list_Atoms.get(1).Atom_Coordinate;
				MT I1 = new MT(3, 1);
				I1.data[0][0] = CAI.x - O1.x;
				I1.data[1][0] = CAI.y - O1.y;
				I1.data[2][0] = CAI.z - O1.z;
				MT I2 = R.times(I1);
				double ddij = Math.pow(CAH.x - O2.x - I2.data[0][0], 2) + Math.pow(CAH.y - O2.y - I2.data[1][0], 2)
					+ Math.pow(CAH.z - O2.z - I2.data[2][0], 2);
				double dij = Math.sqrt(ddij);
				// S.data[i][j]=1.0/(1+(dij*dij/(d0*d0)));
				S.data[i][j] = dij;
				if (H.label == I.label) // if(H.label==I.label&&H.polarity==I.polarity)
					S.data[i][j] = S.data[i][j] + 0.5;

			}
		return S;
	}

	MT getSimilarityMTfromPreAlignmentTM(ArrayList<Residue>ListHit,ArrayList<Residue>ListInput,PreAlignment pre){
		MT S = new MT(ListHit.size(),ListInput.size());
		MT R= pre.get_rotational_Matrix();
		Point O2=pre.center_of_HitResidues();//pdb 25
		Point O1=pre.center_of_inputResidues();

		int min = Math.min(ListHit.size(),ListInput.size());
		double ex = (double)1.0/3.0;
		double d0=0.5;
		if (min>15) d0=1.24*Math.pow((min-15),ex)-1.8;
		for (int i=0;i<ListHit.size();i++)
			for (int j=0;j<ListInput.size();j++){
				Residue H =ListHit.get(i);
				Residue I =ListInput.get(j);
				Point CAH=H.list_Atoms.get(1).Atom_Coordinate;
				Point CAI=I.list_Atoms.get(1).Atom_Coordinate;
				MT I1= new MT(3,1);
					I1.data[0][0]=CAI.x-O1.x;
					I1.data[1][0]=CAI.y-O1.y;
					I1.data[2][0]=CAI.z-O1.z;
					MT I2=R.times(I1);
					double ddij=Math.pow(CAH.x-O2.x-I2.data[0][0],2)+Math.pow(CAH.y-O2.y-I2.data[1][0],2)+Math.pow(CAH.z-O2.z-I2.data[2][0],2);
					double dij=Math.sqrt(ddij);	
				
				S.data[i][j] = 1.0 / (1 + (dij * dij / (d0 * d0)));
					//if(H.label==I.label)
					//S.data[i][j]=S.data[i][j]+0.5;
			}
	return S;}
	
	
	
	PreAlignment alignUsingDP_SmithWaterman(ArrayList<Residue> ListHit, ArrayList<Residue> ListInput, MT S, double gap,
		int Lmin) throws Exception {
		// int min = Math.min(ListHit.size(),ListInput.size());
		MT score_matrix = new MT(S.M + 1, S.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.
		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}
		if (max_pos_i == -1)
			return null;
		ArrayList<Residue> newListHit = new ArrayList<Residue>();
		ArrayList<Residue> newListInput = new ArrayList<Residue>();
		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit.add(0, ListHit.get(x - 1));
				newListInput.add(0, ListInput.get(y - 1));
				// S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				x -= 1;
			} else {
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit.add(0, ListHit.get(x - 1));
		newListInput.add(0, ListInput.get(y - 1));
		// S.data[x - 1][y - 1] = 0.0;// clear alignment for the next sub optimal

		return new PreAlignment(newListHit, newListInput, Lmin);
	}

	ArrayList<PreAlignment> alignTwoListOfFragmentsUsingSmithWaterman(ArrayList<Fragment> ls_hit_frs,
		ArrayList<Fragment> ls_input_frs, double gap, ArrayList<Residue> hit, ArrayList<Residue> input)
			throws Exception {
		ArrayList<PreAlignment> pres = new ArrayList<PreAlignment>();
		// if (checkToStop == 1000)
		// return pres;
		int Lmin = Math.min(hit.size(), input.size());
		MT score_matrix = new MT(S5.M + 1, S5.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.

		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S5, gap);
				// if (score > max_score) {
				// max_score = score;
				// max_pos_i = i;
				// max_pos_j = j;
				// }
				score_matrix.data[i][j] = score;
			}

		for (int i = 1; i < score_matrix.M; i++) {
			int j = score_matrix.N - 1;
			if (score_matrix.data[i][j] > max_score) {
				max_score = score_matrix.data[i][j];
				max_pos_i = i;
				max_pos_j = j;
			}
		}

		for (int j = 1; j < score_matrix.N; j++) {
			int i = score_matrix.M - 1;
			if (score_matrix.data[i][j] > max_score) {
				max_score = score_matrix.data[i][j];
				max_pos_i = i;
				max_pos_j = j;
			}
		}
		if (max_pos_i == -1) {
			System.out.println("max position: " + max_pos_i + "," + max_pos_j);
			return pres;
		}
		System.out.println("max position: " + max_pos_i + "," + max_pos_j);
		String path = "";

		// if (max_pos_i == -1) {
		// System.out.println("aaaaaa: " + max_pos_i + "," + max_pos_j);
		// return pres;
		// }
		ArrayList<Fragment> newListHit = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput = new ArrayList<Fragment>();
		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		// aligned_seq1 = []
		// aligned_seq2 = []
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit.add(0, ls_hit_frs.get(x - 1));
				newListInput.add(0, ls_input_frs.get(y - 1));
				path = path + "(" + (x - 1) + "," + (y - 1) + ")";
				S5.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				x -= 1;
			} else {
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit.add(0, ls_hit_frs.get(x - 1));
		newListInput.add(0, ls_input_frs.get(y - 1));
		path = path + "(" + (x - 1) + "," + (y - 1) + ")";
		S5.data[x - 1][y - 1] = 0.0;// clear alignment for the next sub optimal
		S5.data[max_pos_i - 1][max_pos_j - 1] = 0.0;
		System.out.println("F  " + score_matrix.data[max_pos_i][max_pos_j]);
		System.out.println(path);
		CompleteFragmentAlignment P1 = new CompleteFragmentAlignment(newListHit, newListInput);
		if (newListHit.size() > 2) {
			PreAlignment pr = this.refineBeforeHeuriticIteration(Lmin, P1);
			PreAlignment pre0 = this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(hit, input, pr);

			// PreAlignment pre1 = this.HeuriticIteration_for_one_InitialAlignmentUsingEvolScore(hit, input, pr);
			// System.out.println("using evolution, tm=" + pre1.getTMscore());
			System.out.println("using fr tm, tm=" + pre0.getTMscore());
			double tm0 = 0.0;
			if (pre0 != null)
				tm0 = pre0.getTMscore();
			if (tm0 > 0.2) {
				System.out.println("numberfr" + " " + newListHit.size() + "tmscore " + tm0);
				pres.add(pre0);
			}

		}

		return pres;
	}

	ArrayList<PreAlignment> alignTwoListOfFragmentsUsingSmithWaterman111111111(ArrayList<Fragment> ls_hit_frs,
		ArrayList<Fragment> ls_input_frs, MT S, double gap, ArrayList<Residue> hit, ArrayList<Residue> input,
		int checkToStop)
			throws Exception {
		ArrayList<PreAlignment> pres = new ArrayList<PreAlignment>();
		if (checkToStop == 1000)
			return pres;
		int Lmin = Math.min(hit.size(), input.size());
		MT score_matrix = new MT(S.M + 1, S.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.
		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				score_matrix.data[i][j] = this.calc_score(score_matrix, i, j, S, gap);
			}

		for (int i = 1; i < score_matrix.M; i++) {
			int j = score_matrix.N - 1;
			if (score_matrix.data[i][j] > max_score) {
				max_score = score_matrix.data[i][j];
				max_pos_i = i;
				max_pos_j = j;
				}
		}

		for (int j = 1; j < score_matrix.N; j++) {
			int i = score_matrix.M - 1;
			if (score_matrix.data[i][j] > max_score) {
				max_score = score_matrix.data[i][j];
					max_pos_i = i;
					max_pos_j = j;
				}
			}

		System.out.println("max position: " + max_pos_i + "," + max_pos_j);
		String path = "";

		// if (max_pos_i == -1) {
		// System.out.println("aaaaaa: " + max_pos_i + "," + max_pos_j);
		// return pres;
		// }
		ArrayList<Fragment> newListHit = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput = new ArrayList<Fragment>();
		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		// aligned_seq1 = []
		// aligned_seq2 = []
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit.add(0, ls_hit_frs.get(x - 1));
				newListInput.add(0, ls_input_frs.get(y - 1));
				path = path + "(" + (x - 1) + "," + (y - 1) + ")";
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				x -= 1;
			} else {
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit.add(0, ls_hit_frs.get(x - 1));
		newListInput.add(0, ls_input_frs.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for the next sub optimal

		System.out.println("number fr " + checkToStop + " " + newListHit.size());

		System.out.println(path);
		CompleteFragmentAlignment P1 = new CompleteFragmentAlignment(newListHit, newListInput);
		if (newListHit.size() > 1) {
			PreAlignment pr = this.refineBeforeHeuriticIteration(Lmin, P1);

			PreAlignment pre0 = this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign(hit, input, pr);
			double tm0 = 0.0;
			if (pre0 != null)
				tm0 = pre0.getTMscore();
			if (tm0 > 0.2) {
				System.out.println("numberfr" + " " + newListHit.size() + " loop " + checkToStop + "tmscore " + tm0);
				pres.add(pre0);
			}
 else {
				checkToStop++;
				pres.addAll(this.alignTwoListOfFragmentsUsingSmithWaterman(ls_hit_frs, ls_input_frs, gap, hit, input));
			}
		}

		else {
			checkToStop++;
			pres.addAll(this.alignTwoListOfFragmentsUsingSmithWaterman(ls_hit_frs, ls_input_frs, gap, hit, input));
		}
		return pres;
	}

	ArrayList<PreAlignment> alignTwoListOfFragmentsUsingSmithWaterman111(int Lmin, ArrayList<Fragment> ListHit,
		ArrayList<Fragment> ListInput, MT S, double gap) throws Exception {
		// int min = Math.min(ListHit.size(),ListInput.size());
		MT score_matrix = new MT(S.M + 1, S.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.
		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput = new ArrayList<Fragment>();
		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		// aligned_seq1 = []
		// aligned_seq2 = []
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit.add(0, ListHit.get(x - 1));
				newListInput.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				x -= 1;
			} else {
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit.add(0, ListHit.get(x - 1));
		newListInput.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for the next sub optimal

		CompleteFragmentAlignment P1 = new CompleteFragmentAlignment(newListHit, newListInput);


		// get the second suboptimal

		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}


		ArrayList<Fragment> newListHit2 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput2 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;
		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit2.add(0, ListHit.get(x - 1));
				newListInput2.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}
			else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit2.add(0, ListHit.get(x - 1));
		newListInput2.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

		CompleteFragmentAlignment P2 = new CompleteFragmentAlignment(newListHit2, newListInput2);
		// finish the second

		// get the third suboptimal

		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}


				ArrayList<Fragment> newListHit3 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput3 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;

		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit3.add(0, ListHit.get(x - 1));
				newListInput3.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			} else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit3.add(0, ListHit.get(x - 1));
		newListInput3.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
		CompleteFragmentAlignment P3 = new CompleteFragmentAlignment(newListHit3, newListInput3);
		// finish the second
		
		// recalculating score matrix, max position
				// reset
				max_score = 0;
				max_pos_i = -1;
				max_pos_j = -1;
				for (int i = 1; i < score_matrix.M; i++)
					for (int j = 1; j < score_matrix.N; j++) {
						double score = this.calc_score(score_matrix, i, j, S, gap);
						if (score > max_score) {
							max_score = score;
							max_pos_i = i;
							max_pos_j = j;
						}
						score_matrix.data[i][j] = score;
					}


				ArrayList<Fragment> newListHit4 = new ArrayList<Fragment>();
				ArrayList<Fragment> newListInput4 = new ArrayList<Fragment>();
				// reset
				END = 0;
				DIAG = 1;
				UP = 2;
				LEFT = 3;
				x = max_pos_i;
				y = max_pos_j;

				move = this.next_move(score_matrix, x, y);
				while (move != END) {
					if (move == DIAG) {
						newListHit4.add(0, ListHit.get(x - 1));
						newListInput4.add(0, ListInput.get(y - 1));
						S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
						x -= 1;
						y -= 1;
					} else if (move == UP) {
						// aligned_seq1.append(seq1[x - 1])
						// aligned_seq2.append('-')
						x -= 1;
					} else {
						// aligned_seq1.append('-')
						// aligned_seq2.append(seq2[y - 1])
						y -= 1;
					}

					move = this.next_move(score_matrix, x, y);
				}
				newListHit4.add(0, ListHit.get(x - 1));
				newListInput4.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

				CompleteFragmentAlignment P4 = new CompleteFragmentAlignment(newListHit4, newListInput4);
		
		
				// recalculating score matrix, max position
				// reset
				max_score = 0;
				max_pos_i = -1;
				max_pos_j = -1;
				for (int i = 1; i < score_matrix.M; i++)
					for (int j = 1; j < score_matrix.N; j++) {
						double score = this.calc_score(score_matrix, i, j, S, gap);
						if (score > max_score) {
							max_score = score;
							max_pos_i = i;
							max_pos_j = j;
						}
						score_matrix.data[i][j] = score;
					}


				ArrayList<Fragment> newListHit5 = new ArrayList<Fragment>();
				ArrayList<Fragment> newListInput5 = new ArrayList<Fragment>();
				// reset
				END = 0;
				DIAG = 1;
				UP = 2;
				LEFT = 3;
				x = max_pos_i;
				y = max_pos_j;

				move = this.next_move(score_matrix, x, y);
				while (move != END) {
					if (move == DIAG) {
						newListHit5.add(0, ListHit.get(x - 1));
						newListInput5.add(0, ListInput.get(y - 1));
						S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
						x -= 1;
						y -= 1;
					} else if (move == UP) {
						// aligned_seq1.append(seq1[x - 1])
						// aligned_seq2.append('-')
						x -= 1;
					} else {
						// aligned_seq1.append('-')
						// aligned_seq2.append(seq2[y - 1])
						y -= 1;
					}

					move = this.next_move(score_matrix, x, y);
				}
				newListHit5.add(0, ListHit.get(x - 1));
				newListInput5.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

				CompleteFragmentAlignment P5 = new CompleteFragmentAlignment(newListHit5, newListInput5);
		
		ArrayList<PreAlignment> list = new ArrayList<PreAlignment>(3);
		System.out.println("newListHit1 " + newListHit.size());
		System.out.println("newListHit2 " + newListHit2.size());
		System.out.println("newListHit3 " + newListHit3.size());
		System.out.println("newListHit4 " + newListHit4.size());
		System.out.println("newListHit5 " + newListHit5.size());

		if (newListHit.size() > 2) {
			PreAlignment pr = this.refineBeforeHeuriticIteration(Lmin, P1);

			list.add(pr);
		}
		if (newListHit2.size() > 2)
			list.add(this.refineBeforeHeuriticIteration(Lmin, P2));
		if (newListHit3.size() > 2)
			list.add(this.refineBeforeHeuriticIteration(Lmin, P3));
		if (newListHit4.size() > 2)
			list.add(this.refineBeforeHeuriticIteration(Lmin, P4));
		if (newListHit5.size() > 2)
			list.add(this.refineBeforeHeuriticIteration(Lmin, P5));
		return list;
	}

	ArrayList<PreAlignment> alignTwoListOfFragmentsUsingSmithWaterman1(int Lmin, ArrayList<Fragment> ListHit,
		ArrayList<Fragment> ListInput, MT S, double gap) throws Exception {
		// int min = Math.min(ListHit.size(),ListInput.size());
		MT score_matrix = new MT(S.M + 1, S.N + 1);
		for (int i = 0; i < score_matrix.M; i++)
			score_matrix.data[i][0] = 0;
		for (int j = 0; j < score_matrix.N; j++)
			score_matrix.data[0][j] = 0;
		// Fill the scoring matrix.
		double max_score = 0;
		int max_pos_i = -1;
		int max_pos_j = -1; // The row and columbn of the highest score in matrix.
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput = new ArrayList<Fragment>();
		int END = 0, DIAG = 1, UP = 2, LEFT = 3;
		// aligned_seq1 = []
		// aligned_seq2 = []
		int x = max_pos_i;
		int y = max_pos_j;
		int move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit.add(0, ListHit.get(x - 1));
				newListInput.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			}

			else if (move == UP) {
				x -= 1;
			} else {
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit.add(0, ListHit.get(x - 1));
		newListInput.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for the next sub optimal

		CompleteFragmentAlignment P1 = new CompleteFragmentAlignment(newListHit, newListInput);

		// get the second suboptimal

		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit2 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput2 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;
		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit2.add(0, ListHit.get(x - 1));
				newListInput2.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			} else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit2.add(0, ListHit.get(x - 1));
		newListInput2.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

		CompleteFragmentAlignment P2 = new CompleteFragmentAlignment(newListHit2, newListInput2);
		// finish the second

		// get the third suboptimal

		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit3 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput3 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;

		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit3.add(0, ListHit.get(x - 1));
				newListInput3.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			} else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit3.add(0, ListHit.get(x - 1));
		newListInput3.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
		CompleteFragmentAlignment P3 = new CompleteFragmentAlignment(newListHit3, newListInput3);
		// finish the second
		
		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit4 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput4 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;

		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit4.add(0, ListHit.get(x - 1));
				newListInput4.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			} else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit4.add(0, ListHit.get(x - 1));
		newListInput4.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

		CompleteFragmentAlignment P4 = new CompleteFragmentAlignment(newListHit4, newListInput4);
		
		
		// recalculating score matrix, max position
		// reset
		max_score = 0;
		max_pos_i = -1;
		max_pos_j = -1;
		for (int i = 1; i < score_matrix.M; i++)
			for (int j = 1; j < score_matrix.N; j++) {
				double score = this.calc_score(score_matrix, i, j, S, gap);
				if (score > max_score) {
					max_score = score;
					max_pos_i = i;
					max_pos_j = j;
				}
				score_matrix.data[i][j] = score;
			}

		ArrayList<Fragment> newListHit5 = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput5 = new ArrayList<Fragment>();
		// reset
		END = 0;
		DIAG = 1;
		UP = 2;
		LEFT = 3;
		x = max_pos_i;
		y = max_pos_j;

		move = this.next_move(score_matrix, x, y);
		while (move != END) {
			if (move == DIAG) {
				newListHit5.add(0, ListHit.get(x - 1));
				newListInput5.add(0, ListInput.get(y - 1));
				S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal
				x -= 1;
				y -= 1;
			} else if (move == UP) {
				// aligned_seq1.append(seq1[x - 1])
				// aligned_seq2.append('-')
				x -= 1;
			} else {
				// aligned_seq1.append('-')
				// aligned_seq2.append(seq2[y - 1])
				y -= 1;
			}

			move = this.next_move(score_matrix, x, y);
		}
		newListHit5.add(0, ListHit.get(x - 1));
		newListInput5.add(0, ListInput.get(y - 1));
		S.data[x - 1][y - 1] = 0.0;// clear alignment for next sub optimal

		CompleteFragmentAlignment P5 = new CompleteFragmentAlignment(newListHit5, newListInput5);
		
		ArrayList<PreAlignment> list = new ArrayList<PreAlignment>(3);
		System.out.println("newListHit1 " + newListHit.size());
		System.out.println("newListHit2 " + newListHit2.size());
		System.out.println("newListHit3 " + newListHit3.size());
		System.out.println("newListHit4 " + newListHit4.size());
		System.out.println("newListHit5 " + newListHit5.size());

		if (newListHit.size() > 2) {
			list.add(this.assembly(Lmin, P1));
		}
		if (newListHit2.size() > 2)
			list.add(this.assembly(Lmin, P2));
		if (newListHit3.size() > 2)
			list.add(this.assembly(Lmin, P3));
		if (newListHit4.size() > 2)
			list.add(this.assembly(Lmin, P4));
		if (newListHit5.size() > 2)
			list.add(this.assembly(Lmin, P5));
		return list;
	}
	public CompleteFragmentAlignment alignTwoListOfFragmentsUsingNeedleman(ArrayList<Fragment> ListHit,
		ArrayList<Fragment> ListInput, MT S,
		double p) {
		//int min = Math.min(ListHit.size(),ListInput.size());
		MT F=new MT(S.M+1,S.N+1);
		boolean[][] dir = new boolean[S.M+1][S.N+1];
		double D=0,H=0,V=0;
	for (int i=0;i<F.M;i++) {F.data[i][0]=0;dir[i][0]=false;}
	for (int j=0;j<F.N;j++) {F.data[0][j]=0;dir[0][j]=false;} 
	for (int i=1;i<F.M;i++)
		for (int j=1;j<F.N;j++){ 
		D = F.data[i-1][j-1] + S.data[i-1][j-1];
      	H = F.data[i-1][j];
      	if(dir[i-1][j]) H=H+p;
      	V = F.data[i][j-1];
      	if(dir[i][j-1])V=V+p;
      	if(D>=H&&D>=V) {
        dir[i][j]=true;
        F.data[i][j]=D;}
      	else{
      		dir[i][j]=false;
      		if(V>=H) F.data[i][j]=V;
      		else F.data[i][j]=H;
      		}
      }
	
	

		ArrayList<Fragment> newListHit = new ArrayList<Fragment>();
		ArrayList<Fragment> newListInput = new ArrayList<Fragment>();
	
  		int i=F.M-1,j=F.N-1;
  		double H1=0,V1=0;
  while (i > 0&&j > 0)
  {
    
    if (dir[i][j]){
    	
				newListHit.add(0, ListHit.get(i - 1));
				newListInput.add(0, ListInput.get(j - 1));
    		i=i-1;
    		j=j-1;
    	
    	
    			}
 
    else {
    	 		H1=F.data[i-1][j];
    	          if(dir[i-1][j]) H1=H1+p;
    	          V1=F.data[i][j-1];
    	          if(dir[i][j-1])V1=V1+p;
    	          if(V1>=H1) j=j-1;
    	          else i=i-1;         
    } 
  }
	
		CompleteFragmentAlignment P = new CompleteFragmentAlignment(newListHit, newListInput);

		return P;
	}
	
	
	
	public PreAlignment align(int Lmin, ArrayList<Residue> ListHit, ArrayList<Residue> ListInput, MT S, double p) {
		//int min = Math.min(ListHit.size(),ListInput.size());
		MT F=new MT(S.M+1,S.N+1);
		boolean[][] dir = new boolean[S.M+1][S.N+1];
		double D=0,H=0,V=0;
	for (int i=0;i<F.M;i++) {F.data[i][0]=0;dir[i][0]=false;}
	for (int j=0;j<F.N;j++) {F.data[0][j]=0;dir[0][j]=false;} 
	for (int i=1;i<F.M;i++)
		for (int j=1;j<F.N;j++){ 
		D = F.data[i-1][j-1] + S.data[i-1][j-1];
      	H = F.data[i-1][j];
      	if(dir[i-1][j]) H=H+p;
      	V = F.data[i][j-1];
      	if(dir[i][j-1])V=V+p;
      	if(D>=H&&D>=V) {
        dir[i][j]=true;
        F.data[i][j]=D;}
      	else{
      		dir[i][j]=false;
      		if(V>=H) F.data[i][j]=V;
      		else F.data[i][j]=H;
      		}
      }
	
	

		ArrayList<Residue> newListHit= new ArrayList<Residue>();
		ArrayList<Residue> newListInput= new ArrayList<Residue>();
	
  		int i=F.M-1,j=F.N-1;
  		double H1=0,V1=0;
  while (i > 0&&j > 0)
  {
    
    if (dir[i][j]){
				// if (S.data[i - 1][j - 1] > 0) {
				newListHit.add(0, ListHit.get(i - 1));
				newListInput.add(0, ListInput.get(j - 1));
				// }
    		i=i-1;
    		j=j-1;
    	
    	
    			}
 
    else {
    	 		H1=F.data[i-1][j];
    	          if(dir[i-1][j]) H1=H1+p;
    	          V1=F.data[i][j-1];
    	          if(dir[i][j-1])V1=V1+p;
    	          if(V1>=H1) j=j-1;
    	          else i=i-1;         
    } 
  }
	
		PreAlignment P = new PreAlignment(newListHit, newListInput, Lmin);

if(newListHit.size()>2) return P; else return null;
	}
	
	public String[] align22(int Lmin, ArrayList<Residue> ListHit, ArrayList<Residue> ListInput, MT S, double p,
		HashMap<String, String> hm) {
		// int min = Math.min(ListHit.size(),ListInput.size());
		MT F = new MT(S.M + 1, S.N + 1);
		boolean[][] dir = new boolean[S.M + 1][S.N + 1];
		double D = 0, H = 0, V = 0;
		for (int i = 0; i < F.M; i++) {
			F.data[i][0] = 0;
			dir[i][0] = false;
		}
		for (int j = 0; j < F.N; j++) {
			F.data[0][j] = 0;
			dir[0][j] = false;
		}
		for (int i = 1; i < F.M; i++)
			for (int j = 1; j < F.N; j++) {
				D = F.data[i - 1][j - 1] + S.data[i - 1][j - 1];
				H = F.data[i - 1][j];
				if (dir[i - 1][j])
					H = H + p;
				V = F.data[i][j - 1];
				if (dir[i][j - 1])
					V = V + p;
				if (D >= H && D >= V) {
					dir[i][j] = true;
					F.data[i][j] = D;
				} else {
					dir[i][j] = false;
					if (V >= H)
						F.data[i][j] = V;
					else
						F.data[i][j] = H;
				}
			}

		ArrayList<Residue> newListHit = new ArrayList<Residue>();
		ArrayList<Residue> newListInput = new ArrayList<Residue>();
		String hitt = "";
		String inn = "";
		String st = "";
		int i = F.M - 1, j = F.N - 1;
		double H1 = 0, V1 = 0;
		while (i > 0 && j > 0) {

			if (dir[i][j]) {
				// if (S.data[i - 1][j - 1] > 0) {
				newListHit.add(0, ListHit.get(i - 1));
				newListInput.add(0, ListInput.get(j - 1));
				hitt = hm.get(ListHit.get(i - 1).Residue_Name) + ListHit.get(i - 1).Residue_number + "\t" + hitt;
				inn = hm.get(ListInput.get(j - 1).Residue_Name) + ListInput.get(j - 1).Residue_number + "\t" + inn;
				if (hm.get(ListHit.get(i - 1).Residue_Name).compareTo(hm.get(ListInput.get(j - 1).Residue_Name)) == 0)
					st = "*" + "\t" + st;
				else
					st = " " + "\t" + st;
				// }
				i = i - 1;
				j = j - 1;

			}

			else {
				H1 = F.data[i - 1][j];
				if (dir[i - 1][j])
					H1 = H1 + p;
				V1 = F.data[i][j - 1];
				if (dir[i][j - 1])
					V1 = V1 + p;

				if (V1 >= H1) {
					hitt = "-" + "\t" + hitt;
					inn = hm.get(ListInput.get(j - 1).Residue_Name) + ListInput.get(j - 1).Residue_number + "\t" + inn;
					st = " " + "\t" + st;
					j = j - 1;
				} else {
					hitt = hm.get(ListHit.get(i - 1).Residue_Name) + ListHit.get(i - 1).Residue_number + "\t" + hitt;
					inn = "-" + "\t" + inn;
					st = " " + "\t" + st;
					i = i - 1;
				}
			}
		}

		String[] a = new String[3];
		a[0] = hitt;
		a[1] = inn;
		a[2] = st;
		return a;
	}
	
	
	
	
	
	
 int [] getSSElabel111(){
	int n = this.ListResidues2.size();
	int[] SSLabel = new int[n];
	java.util.Arrays.fill(SSLabel,3);
	for(int i=1;i<n-1;i++) {
		Residue2 R0 =this.ListResidues2.get(i-1);
		Residue2 R1 =this.ListResidues2.get(i);
		Residue2 R2 =this.ListResidues2.get(i+1);
		
		//N,CA,C
		Point P1=R0.list_Atoms.get(2).Atom_Coordinate;
		Point P2=R1.list_Atoms.get(0).Atom_Coordinate;
		Point P3=R1.list_Atoms.get(1).Atom_Coordinate;
		Point P4=R1.list_Atoms.get(2).Atom_Coordinate;
		double p = this.angle(P1, P2, P3, P4);
		
		Point S1=R1.list_Atoms.get(0).Atom_Coordinate;
		Point S2=R1.list_Atoms.get(1).Atom_Coordinate;
		Point S3=R1.list_Atoms.get(2).Atom_Coordinate;
		Point S4=R2.list_Atoms.get(0).Atom_Coordinate;
		double s = this.angle(S1, S2, S3, S4);
	
		if(s>-90&&s<30&&p>-90&&p<-30) SSLabel[i-1] = 1;
		//if(s>-90&&s<60&&p<0) SSLabel[i] = 1;
		else if(((s>90&&s<180)||(s>-180&&s<-150))&&((p>-180&&p<-30)||(p>150&&p<180))) SSLabel[i-1] = 2;
		System.out.println(p+" "+s);
		}
	
	SSLabel[n-1] = SSLabel[n-3];
	SSLabel[n-2] = SSLabel[n-3];
	//SSLabel[0] = SSLabel[1];
	return SSLabel;
	}
	
 int [] getSSElabel(ArrayList<Residue2>ListResidues2){
		int n = ListResidues2.size();
		int[] SSLabel = new int[n];
		//java.util.Arrays.fill(SSLabel,3);
		if(n<8)	for(int i=0;i<n;i++) {SSLabel[i] = 4;
		}
		else {
		for(int i=0;i<n-4;i++) {
			Residue2 R0 =ListResidues2.get(i);
			Residue2 R2 =ListResidues2.get(i+2);
			Residue2 R3 =ListResidues2.get(i+3);
			Residue2 R4 =ListResidues2.get(i+4);
			Point CA0=R0.list_Atoms.get(1).Atom_Coordinate;
			Point CA2=R2.list_Atoms.get(1).Atom_Coordinate;
			Point CA3=R3.list_Atoms.get(1).Atom_Coordinate;
			Point CA4=R4.list_Atoms.get(1).Atom_Coordinate;
			double d2 = CA0.distanceTo(CA2);
			double d3 = CA0.distanceTo(CA3);
			double d4 = CA0.distanceTo(CA4);
			
			if(Math.abs(d2-5.45)<2.1&&Math.abs(d3-5.18)<2.1&&Math.abs(d4-6.37)<2.1) SSLabel[i] = 1;
			else if(Math.abs(d2-6.1)<1.42&&Math.abs(d3-10.4)<1.42&&Math.abs(d4-13)<1.42) SSLabel[i] = 2;
			else SSLabel[i] = 3;
			}
		
		
		for(int i=n-1;i>n-5;i--) {
			Residue2 R0 =ListResidues2.get(i);
			Residue2 R2 =ListResidues2.get(i-2);
			Residue2 R3 =ListResidues2.get(i-3);
			Residue2 R4 =ListResidues2.get(i-4);
			Point CA0=R0.list_Atoms.get(1).Atom_Coordinate;
			Point CA2=R2.list_Atoms.get(1).Atom_Coordinate;
			Point CA3=R3.list_Atoms.get(1).Atom_Coordinate;
			Point CA4=R4.list_Atoms.get(1).Atom_Coordinate;
			double d2 = CA0.distanceTo(CA2);
			double d3 = CA0.distanceTo(CA3);
			double d4 = CA0.distanceTo(CA4);
			if(Math.abs(d2-5.45)<2.1&&Math.abs(d3-5.18)<2.1&&Math.abs(d4-6.37)<2.1) SSLabel[i] = 1;
			else if(Math.abs(d2-6.1)<1.42&&Math.abs(d3-10.4)<1.42&&Math.abs(d4-13)<1.42) SSLabel[i] = 2;
			else SSLabel[i] = 3;
			}}
		return SSLabel;
		}
 
	
 public void fill_hashmap3() {
	 this.residue_position.put("CYS",new Integer(0));
		this.residue_position.put("SER",new Integer(1));
		this.residue_position.put("THR",new Integer(2));
		this.residue_position.put("PRO",new Integer(3));
		this.residue_position.put("ALA",new Integer(4));
		this.residue_position.put("GLY",new Integer(5));
		this.residue_position.put("ASN",new Integer(6));
		this.residue_position.put("ASP",new Integer(7));
		this.residue_position.put("GLU",new Integer(8));
		this.residue_position.put("GLN",new Integer(9));
		this.residue_position.put("HIS",new Integer(10));
		this.residue_position.put("ARG",new Integer(11));
		this.residue_position.put("LYS",new Integer(12));
		this.residue_position.put("MET",new Integer(13));
		this.residue_position.put("ILE",new Integer(14));
		this.residue_position.put("LEU",new Integer(15));
		this.residue_position.put("VAL",new Integer(16));
		this.residue_position.put("PHE",new Integer(17));
		this.residue_position.put("TYR",new Integer(18));
		this.residue_position.put("TRP",new Integer(19));

		
		}
 
	public HashMap<String, String> aa_shortname() {
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("ALA", "A");
		hm.put("ARG", "R");
		hm.put("ASN", "N");
		hm.put("ASP", "D");
		hm.put("ASX", "B");
		hm.put("CYS", "C");
		hm.put("GLN", "Q");
		hm.put("GLU", "E");
		hm.put("GLX", "Z");
		hm.put("GLY", "G");
		hm.put("HIS", "H");
		hm.put("ILE", "I");
		hm.put("LEU", "L");
		hm.put("LYS", "K");
		hm.put("MET", "M");
		hm.put("PHE", "F");
		hm.put("PRO", "P");
		hm.put("SER", "S");
		hm.put("THR", "T");
		hm.put("TRP", "W");
		hm.put("TYR", "Y");
		hm.put("VAL", "V");
		return hm;
	}
 public void fill_hashmap() {
	String s= "ASP-GLU-ARG-HIS-LYS-ASN-GLN-SER-THR-TYR-ALA-CYS-GLY-MET-ILE-LEU-VAL-PHE-PRO-TRP-ZN-FE-CA-CU-MG";
		String [] name= s.split("-");
			for(int i=0;i<10;i++)  this.polarity.put(name[i],new Integer(1));//polar
			for(int i=10;i<20;i++)  this.polarity.put(name[i],new Integer(2));//nonpolar
			for(int i=20;i<name.length;i++)  this.polarity.put(name[i],new Integer(3));// ion
					
			/*for(int i=0;i<name.length;i++) 
				System.out.println(name[i]+" "+this.polarity.get(name[i]));*/
	
	}

	public void fill_hashmap2() {
	String s= "ASP-VAL-ARG-HIS-LYS-ASN-GLN-SER-THR-TYR-ALA-CYS-GLY-MET-PHE-PRO-TRP-ZN-FE-CA-CU-MG";
		String [] name= s.split("-");
			for(int i=0;i<22;i++)  this.ResidueName.put(name[i],new Integer(i));
			
			this.ResidueName.put("GLU",new Integer(0));
			this.ResidueName.put("ILE",new Integer(1));
			this.ResidueName.put("LEU",new Integer(1));
			/*for(int i=0;i<name.length;i++) 
			System.out.println(name[i]+" "+this.ResidueName.get(name[i]));
			*/
			
	}
	
		
	
	
	
	public void all_alignments1()throws Exception{
		//LinkedList<Alignment> myAlignments = new LinkedList<Alignment>(); 
		ArrayList<Alignment> myAlignments1 = new ArrayList<Alignment>(); 
	//	ArrayList<Alignment> myAlignments2 = new ArrayList<Alignment>(); 
		//ArrayList<Alignment> myAlignments3 = new ArrayList<Alignment>();
		
		File folder = new File(this.KnownPath);
		if (folder.isFile()) {
			this.KnownPath = folder.getParent();
			String name = folder.getName();
			int le = name.length();
			String PDBcode = folder.getName().substring(le - 8, le - 4);
			System.out.println("protein  " + PDBcode + ": done");

			ArrayList<ArrayList<Residue>> listListResiduesFromDataBase;
			if (this.has == true)
				listListResiduesFromDataBase = this.get_list_all_residues_from_PDBfile(folder.getAbsolutePath(),
					PDBcode);
			else {
				ArrayList<ArrayList<Residue2>> listListResidue2s = this
					.get_list_all_residues_from_PDBfile2(folder.getAbsolutePath(), PDBcode);
				listListResiduesFromDataBase = this.getListListResiduefromListlistResidue2(listListResidue2s);
			}
			for (ArrayList<Residue> ListResidues : this.listListResidue) {
				for (ArrayList<Residue> listR25 : listListResiduesFromDataBase) {
					if (ListResidues.size() > 0) {
						//PreAlignment Pre = this.usingTMalign_3_initial(listR25, ListResidues);
						// this.usingFragmentsWithEvolScore(listR25,ListResidues,folder.getAbsolutePath());
						// PreAlignment Pre = this.usingSeqAlignmnet(listR25, ListResidues);
						PreAlignment Pre = this.usingFragment_tmScore_assembly(listR25, ListResidues);

						// PreAlignment Pre = this.usingTMscoreMTcoverALLfragments(listR25,
						// ListResidues, folder.getAbsolutePath());

						if (Pre != null) {
							if (Pre.ListHitResidues.size() > 2) {
								// int blosum = this.BlosSum62Score(Pre.ListHitResidues, Pre.ListHitResidues);
								double[] a = this.evolutionSimilarityScore(Pre.ListHitResidues, Pre.ListHitResidues,
									Pre.Lmin);
								ArrayList<HashMap<String, String>> Color1 = this.creatColorJmolValueUsingDistance(Pre);
								ArrayList<HashMap<String, String>> Color2 = this.creatColorJmolValueUsingBlosum(Pre);
								HashMap<String, String> hm = this.aa_shortname();
								String[] seqAl = this.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign22(
									listR25, ListResidues, Pre, hm);
								Alignment A = new Alignment(Pre, folder.getAbsolutePath(), this.KnownPath, a, Color1,
									Color2, seqAl);

								// Alignment A = new Alignment(this.shorten(Pre));
								// if(A.RMSD<this.maximumRMSD)

								if (A.score > this.minTMscore)
									myAlignments1.add(A);

							}
						}
			}
				}
			}
		
		} else {
			int count = 0;

			for (File file : folder.listFiles()) {
				// if (count < 1500) {
					count++;
					String name = file.getName();
					int le = name.length();
					String PDBcode = file.getName().substring(le - 8, le - 4);
					System.out.println("protein " + count + " " + PDBcode + ": done");

				ArrayList<ArrayList<Residue>> listListResiduesFromDataBase;
					if (this.has == true)
						listListResiduesFromDataBase = this.get_list_all_residues_from_PDBfile(file.getAbsolutePath(),
							PDBcode);
					else {
						ArrayList<ArrayList<Residue2>> listListResidue2s = this
							.get_list_all_residues_from_PDBfile2(file.getAbsolutePath(), PDBcode);
						listListResiduesFromDataBase = this.getListListResiduefromListlistResidue2(listListResidue2s);
					}
					for (ArrayList<Residue> ListResidues : this.listListResidue) {
						System.out.println("input protein chain " + ListResidues.get(0).Chain_Name + ":done");
						for (ArrayList<Residue> listR25 : listListResiduesFromDataBase) {
							if (ListResidues.size() > 0) {
								// PreAlignment Pre = this.heuriticIterationUsingScoreMTcoverALLfragments(listR25,
								// ListResidues, file.getAbsolutePath());
								PreAlignment Pre = this.usingFragment_tmScore_assembly(listR25, ListResidues);

								if (Pre != null) {
									if (Pre.ListHitResidues.size() > 2) {
										double[] a = this.evolutionSimilarityScore(Pre.ListHitResidues,
											Pre.ListHitResidues, Pre.Lmin);
										ArrayList<HashMap<String, String>> color1 = this
											.creatColorJmolValueUsingDistance(Pre);
										ArrayList<HashMap<String, String>> color2 = this
											.creatColorJmolValueUsingBlosum(Pre);
										HashMap<String, String> hm = this.aa_shortname();
										String[] seqAl = this
											.heuriticIteration_for_one_InitialAlignmentUsingFrTMalign22(listR25,
												ListResidues, Pre, hm);
										Alignment A = new Alignment(Pre, file.getAbsolutePath(), this.KnownPath, a,
											color1, color2, seqAl);
										// Alignment A = new Alignment(Pre, file.getAbsolutePath(), this.KnownPath);
										// Alignment A = new Alignment(this.shorten(Pre));
										// if(A.RMSD<this.maximumRMSD)

										if (A.score > this.minTMscore)
											myAlignments1.add(A);

									}
								}
			}
						}
					}
				// } if(count<1500)
			}
		}
	
		MyDBengine	SAVE = new MyDBengine(); 
		Myresult result1 = new Myresult(myAlignments1);
		String path1 = "OutputFiles" + File.separator + "result1";
		SAVE.SerialObject(path1,result1);
		
		
		/*
		for (File file : folder.listFiles()) {
			if(count<3000&&count>=1500)
			{
			count++;
		

String name = file.getName();
int le = name.length();
String PDBcode = file.getName().substring(le-8,le-4);
		

System.out.println("protein "+count +" "+PDBcode+": done");
if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
	ArrayList<ArrayList<Residue>> listListResidues;
		if(this.has==true)
			listListResidues = this.get_list_all_residues_from_PDBfile(file.getAbsolutePath(),PDBcode);
		else  {
			ArrayList<ArrayList<Residue2>> listListResidue2s = this.get_list_all_residues_from_PDBfile2(file.getAbsolutePath(),PDBcode);
			listListResidues=this.getListListResiduefromListlistResidue2(listListResidue2s);
		}												
for(ArrayList<Residue> listR25: listListResidues){
	if(ListResidues.size()>0){
	PreAlignment Pre = this.HeuriticIteration(listR25, ListResidues,file.getAbsolutePath());
	if(Pre!=null){
	if(Pre.ListHitResidues.size()>2){
	Alignment A = new Alignment(Pre,true,file.getAbsolutePath());
	//Alignment A = new Alignment(this.shorten(Pre));
	//if(A.RMSD<this.maximumRMSD)
	if(A.score>this.minTMscore)
		myAlignments2.add(A);}}
	
}}
	
}





		
		} 	} 
Myresult result2 = new Myresult(myAlignments2);
String path2 = System.getProperty("user.dir") + File.separator +"OutputFiles"+ File.separator + "result2";
SAVE.SerialObject(path2,result2);




for (File file : folder.listFiles()) {
	if(count>=3000)
	{
	count++;


String name = file.getName();
int le = name.length();
String PDBcode = file.getName().substring(le-8,le-4);


System.out.println("protein "+count +" "+PDBcode+": done");


if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
ArrayList<ArrayList<Residue>> listListResidues;
if(this.has==true)
	listListResidues = this.get_list_all_residues_from_PDBfile(file.getAbsolutePath(),PDBcode);
else  {
	ArrayList<ArrayList<Residue2>> listListResidue2s = this.get_list_all_residues_from_PDBfile2(file.getAbsolutePath(),PDBcode);
	listListResidues=this.getListListResiduefromListlistResidue2(listListResidue2s);
}												
for(ArrayList<Residue> listR25: listListResidues){
if(ListResidues.size()>0){
PreAlignment Pre = this.HeuriticIteration(listR25, ListResidues,file.getAbsolutePath());
if(Pre!=null){
if(Pre.ListHitResidues.size()>2){
Alignment A = new Alignment(Pre,true,file.getAbsolutePath());
//Alignment A = new Alignment(this.shorten(Pre));
//if(A.RMSD<this.maximumRMSD)
if(A.score>this.minTMscore)
myAlignments3.add(A);}}

}}

}



}}
Myresult result3 = new Myresult(myAlignments3);
String path3 = System.getProperty("user.dir") + File.separator +"OutputFiles"+ File.separator + "result3";
SAVE.SerialObject(path3,result3);
		
		*/
		
		
	}
	
	
	
	
	
	
	/*LinkedList<Alignment> all_alignments2()throws Exception{
		LinkedList<Alignment> myAlignments = new LinkedList<Alignment>(); 
		
		
		File file= new File(this.KnownPath);
		

		
		String name = file.getName();
		int le = name.length();
		String PDBcode = file.getName().substring(le-8,le-4);

		if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
			ArrayList<ArrayList<Residue>> listListResidues;
				if(this.has==true)
					listListResidues = this.get_list_all_residues_from_PDBfile(file.getAbsolutePath(),PDBcode);
				else  {
					ArrayList<ArrayList<Residue2>> listListResidue2s = this.get_list_all_residues_from_PDBfile2(file.getAbsolutePath(),PDBcode);
					listListResidues=this.getListListResiduefromListlistResidue2(listListResidue2s);
				}												
		for(ArrayList<Residue> listR25: listListResidues){
			if(ListResidues.size()>0){
			PreAlignment Pre = this.HeuriticIteration(listR25, ListResidues,file.getAbsolutePath());
			
				System.out.print(Pre);
			
			if(Pre!=null){
			if(Pre.ListHitResidues.size()>2){
			Alignment A = new Alignment(Pre,true,file.getAbsolutePath());
			//Alignment A = new Alignment(this.shorten(Pre));
			//if(A.RMSD<this.maximumRMSD)
			
			if(A.score>0.4){
				myAlignments.add(A);}
			
			
			
			
			}}
			
		}}
			
		}
		
		
				
		return myAlignments;				
	}
	*/
	
	public LinkedList<Alignment> IMPROVEDalignments(String name1,String name2)throws Exception{
		LinkedList<Alignment> myAlignments = new LinkedList<Alignment>(); 
		MyDBengine	SAVE = new MyDBengine(); 
		String path1 = "Result" + File.separator + name1;
		Myresult result1 =(Myresult)SAVE.DeserialObject(path1);
		ArrayList<Alignment> l1=result1.getResult();
		
		String path2 = "Result" + File.separator + name2;
		Myresult result2 =(Myresult)SAVE.DeserialObject(path2);
		ArrayList<Alignment> l2=result2.getResult();
		for(Alignment A:l2){
	if(l1.contains(A)){} else myAlignments.add(A);
		}
		return myAlignments;
}
	
	public LinkedList<Alignment> get_all_alignments()throws Exception{
		LinkedList<Alignment> myAlignments = new LinkedList<Alignment>(); 
		MyDBengine	SAVE = new MyDBengine(); 
		String path1 = "OutputFiles" + File.separator + "result1";
		Myresult result1 =(Myresult)SAVE.DeserialObject(path1);
		if(result1.getResult().size()>0)
		myAlignments.addAll(result1.getResult());
		
		// String path2 = "OutputFiles" + File.separator + "result2";
		// Myresult result2 =(Myresult)SAVE.DeserialObject(path2);
		// if(result2.getResult().size()>0)
		// myAlignments.addAll(result2.getResult());
		// String path3 = "OutputFiles" + File.separator + "result3";
		// Myresult result3 =(Myresult)SAVE.DeserialObject(path3);
		// if(result3.getResult().size()>0)
		// myAlignments.addAll(result3.getResult());
		return myAlignments;
}
	
	
/*
 		
public void SAVE_all_alignments()throws Exception{
	//LinkedList<Alignment> myAlignments = new LinkedList<Alignment>(); 
	ArrayList<Alignment> myAlignments1 = new ArrayList<Alignment>(); 
	ArrayList<Alignment> myAlignments2 = new ArrayList<Alignment>(); 
	ArrayList<Alignment> myAlignments3 = new ArrayList<Alignment>(); 

	ArrayList<String> listPDB25 = this.get_ListPBD25();
	int n = listPDB25.size();
	int m=0;// 3DRF;
	//n=2353 ;//1S5N;//1WUI//4253  3759  3757
	for (int i=m;i<1500;i++)
			{
	String path = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+listPDB25.get(i)+".pdb";
	String PDBcode = listPDB25.get(i);
	System.out.println("protein "+i +" "+PDBcode+": done");
	int[] neiborSIZE=null;

	if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
		ArrayList<ArrayList<Node>> ListlistNODE ;
			if(this.has==true)
				ListlistNODE  = this.get_list_NODE2(path,PDBcode,this.polarityCheck);
			else  ListlistNODE  = this.get_list_NODE(path,PDBcode,this.polarityCheck);
			
			for(ArrayList<Node> listNODE :ListlistNODE ){
				if(listNODE.size()!=0){
			
			
			if(listNODE.size()<9500)	
			{
				
				ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
				FindCLIQUE f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
				
				ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
				for (int U=0;U<listCLIQUE.size();U++)
							{
					ArrayList<Integer> Cliq = listCLIQUE.get(U);
					ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
					for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
					Alignment A= new Alignment(MaximalClique,true);
					if(A.RMSD<this.maximumRMSD)
					myAlignments1.add(A);
				}
			}
			else if(listNODE.size()>9500&&listNODE.size()<15000)   {
						System.out.println("Worse case");
						neiborSIZE=this.get_Neighbourhood(listNODE);
						FindCLIQUE f = new FindCLIQUE(listNODE,minSIZE,neiborSIZE);
						ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
						for (int U=0;U<listCLIQUE.size();U++)
									{
							ArrayList<Integer> Cliq = listCLIQUE.get(U);
							ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
							for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
							Alignment A= new Alignment(MaximalClique,true);
							if(A.RMSD<this.maximumRMSD)
							myAlignments1.add(A);
						}
						}
		
				

			
				
			}
				}
			
		
														}
	
	else {
		ArrayList<ArrayList<Node>> ListlistNODE = this.get_list_NODE3(path,PDBcode,this.polarityCheck);
		for(ArrayList<Node> listNODE :ListlistNODE ){
			if(listNODE.size()!=0){
		FindCLIQUE f;
		if(listNODE.size()>5000){
			ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
			f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
					}
		else 	
		{
			
			ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
			f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE,true);
		}
			

		ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
		for (int U=0;U<listCLIQUE.size();U++)
					{
			ArrayList<Integer> Cliq = listCLIQUE.get(U);
			ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
			for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
			Alignment A= new Alignment(MaximalClique,false);
			if(A.RMSD<this.maximumRMSD)
			myAlignments1.add(A);
		}
			
		}
			}
		
	}

	
			
			}
	
	MyDBengine	SAVE = new MyDBengine(); 
	Myresult result1 = new Myresult(myAlignments1);
	String path1 = System.getProperty("user.dir") + File.separator +"OutputFiles"+ File.separator + "result1";
	SAVE.SerialObject(path1,result1);
	
	
	for (int i=1500;i<2800;i++)
	{
String path = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+listPDB25.get(i)+".pdb";
String PDBcode = listPDB25.get(i);
//System.out.println("protein "+i +" "+PDBcode+": done");
int[] neiborSIZE=null;

if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
ArrayList<ArrayList<Node>> ListlistNODE ;
	if(this.has==true)
		ListlistNODE  = this.get_list_NODE2(path,PDBcode,this.polarityCheck);
	else  ListlistNODE  = this.get_list_NODE(path,PDBcode,this.polarityCheck);
	
	for(ArrayList<Node> listNODE :ListlistNODE ){
		if(listNODE.size()!=0){
	
	
	if(listNODE.size()<9500)	
	{
		
		ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
		FindCLIQUE f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
		
		ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
		for (int U=0;U<listCLIQUE.size();U++)
					{
			ArrayList<Integer> Cliq = listCLIQUE.get(U);
			ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
			for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
			Alignment A= new Alignment(MaximalClique,true);
			if(A.RMSD<this.maximumRMSD)
			myAlignments2.add(A);
		}
	}
	else if(listNODE.size()>9500&&listNODE.size()<15000)   {
				System.out.println("Worse case");
				neiborSIZE=this.get_Neighbourhood(listNODE);
				FindCLIQUE f = new FindCLIQUE(listNODE,minSIZE,neiborSIZE);
				ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
				for (int U=0;U<listCLIQUE.size();U++)
							{
					ArrayList<Integer> Cliq = listCLIQUE.get(U);
					ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
					for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
					Alignment A= new Alignment(MaximalClique,true);
					if(A.RMSD<this.maximumRMSD)
					myAlignments2.add(A);
				}
				}

		

	
		
	}
		}
	

												}

else {
ArrayList<ArrayList<Node>> ListlistNODE = this.get_list_NODE3(path,PDBcode,this.polarityCheck);
for(ArrayList<Node> listNODE :ListlistNODE ){
	if(listNODE.size()!=0){
FindCLIQUE f;
if(listNODE.size()>5000){
	ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
	f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
			}
else 	
{
	
	ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
	f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE,true);
}
	

ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
for (int U=0;U<listCLIQUE.size();U++)
			{
	ArrayList<Integer> Cliq = listCLIQUE.get(U);
	ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
	for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
	Alignment A= new Alignment(MaximalClique,false);
	if(A.RMSD<this.maximumRMSD)
	myAlignments2.add(A);
}
	
}
	}

}


	
	}

	Myresult result2 = new Myresult(myAlignments2);
	String path2 = System.getProperty("user.dir") + File.separator +"OutputFiles"+ File.separator + "result2";
	SAVE.SerialObject(path2,result2);
	
	for (int i=2800;i<n;i++)
	{
String path = System.getProperty("user.dir") + File.separator + "PDBfiles"+ File.separator+listPDB25.get(i)+".pdb";
String PDBcode = listPDB25.get(i);
//System.out.println("protein "+i +" "+PDBcode+": done");
int[] neiborSIZE=null;

if(this.fullpdbFile.trim().compareTo("ALL residues")==0){
ArrayList<ArrayList<Node>> ListlistNODE ;
	if(this.has==true)
		ListlistNODE  = this.get_list_NODE2(path,PDBcode,this.polarityCheck);
	else  ListlistNODE  = this.get_list_NODE(path,PDBcode,this.polarityCheck);
	
	for(ArrayList<Node> listNODE :ListlistNODE ){
		if(listNODE.size()!=0){
	
	
	if(listNODE.size()<9500)	
	{
		
		ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
		FindCLIQUE f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
		
		ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
		for (int U=0;U<listCLIQUE.size();U++)
					{
			ArrayList<Integer> Cliq = listCLIQUE.get(U);
			ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
			for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
			Alignment A= new Alignment(MaximalClique,true);
			if(A.RMSD<this.maximumRMSD)
			myAlignments2.add(A);
		}
	}
	else if(listNODE.size()>9500&&listNODE.size()<15000)   {
				System.out.println("Worse case");
				neiborSIZE=this.get_Neighbourhood(listNODE);
				FindCLIQUE f = new FindCLIQUE(listNODE,minSIZE,neiborSIZE);
				ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
				for (int U=0;U<listCLIQUE.size();U++)
							{
					ArrayList<Integer> Cliq = listCLIQUE.get(U);
					ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
					for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
					Alignment A= new Alignment(MaximalClique,true);
					if(A.RMSD<this.maximumRMSD)
					myAlignments2.add(A);
				}
				}

		

	
		
	}
		}
	

												}

else {
ArrayList<ArrayList<Node>> ListlistNODE = this.get_list_NODE3(path,PDBcode,this.polarityCheck);
for(ArrayList<Node> listNODE :ListlistNODE ){
	if(listNODE.size()!=0){
FindCLIQUE f;
if(listNODE.size()>5000){
	ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
	f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE);
			}
else 	
{
	
	ArrayList<ArrayList<Integer>> list_neighbourHood=this.get_Neighbourhood2(listNODE);
	f = new FindCLIQUE(listNODE,list_neighbourHood,minSIZE,true);
}
	

ArrayList<ArrayList<Integer>> listCLIQUE = f.listCLIQUE;
for (int U=0;U<listCLIQUE.size();U++)
			{
	ArrayList<Integer> Cliq = listCLIQUE.get(U);
	ArrayList<Node> MaximalClique = new ArrayList<Node>(Cliq.size());
	for (int l=0;l<Cliq.size();l++) MaximalClique.add(listNODE.get(Cliq.get(l)));
	Alignment A= new Alignment(MaximalClique,false);
	if(A.RMSD<this.maximumRMSD)
	myAlignments2.add(A);
}
	
}
	}

}


	
	}

	Myresult result3 = new Myresult(myAlignments3);
	String path3 = System.getProperty("user.dir") + File.separator +"OutputFiles"+ File.separator + "result3";
	SAVE.SerialObject(path3,result3);
	
			}*/










	public LinkedList<Alignment>  sort (LinkedList<Alignment> list)
	{
	//if(this.sortChoice==0) 
		Collections.sort(list,new ScoreComparator(true));
	//else if(this.sortChoice==1) Collections.sort(list,new RMSDComparator(true));
	//else Collections.sort(list,new ResidueIdentityComparator(true));
	return list;}
	
	
	public LinkedList<FragmentAlignment> sortt(LinkedList<FragmentAlignment> list) {
		Collections.sort(list, new FragmentAlignmentComparator());
		return list;
	}
	
	
	
public void get_enzyme_function_description()throws Exception{
	
	Scanner in=new Scanner(new FileInputStream("EnzymeFunctionDesciption.txt"));
	while(in.hasNextLine()){
		String [] row = in.nextLine().split("XXXX");
		 this.PDBcodeVSfunction.put(row[0],row[1]+"\n"+row[2]);
		 }in.close();}




public int count_number_residue_in_sphere(Residue R,double maxDistance,ArrayList<Residue> listALLresidues){
	int count =0;
	for(Residue R1 :listALLresidues ){if (R.get_distanceTo(R1)<maxDistance)count ++;}
	return count-1;
}


public boolean less_than_maximumDistance(double max, ArrayList<Residue> listALLresidues){
	boolean lessThan = true;
	for( Residue R1 : listALLresidues)
		for( Residue R2 : listALLresidues){if(R1.get_distanceTo(R2)>max){lessThan=false;break;}
		}
	return lessThan;
}





public ArrayList<Residue> sort_alphabetically_list_residues_of_activesite(ArrayList<Residue> my_list)
		{
		ArrayList<Residue> sorted_list = new ArrayList<Residue>();
		int n= my_list.size();
		
		HashMap<String,Residue> hm=new HashMap<String,Residue>();
		LinkedList <String> list = new LinkedList<String>();

	for( Residue R: my_list){
	list.add(R.get_ResidueName_ChainName_ResidueNumber());
	hm.put(R.get_ResidueName_ChainName_ResidueNumber(),R);
				}

		Collections.sort(list);

	for(int i=0;i<n;i++){sorted_list.add(hm.get(list.get(i)));}

		return sorted_list;
							}





public ArrayList<Residue> find_Residue(ArrayList<TriangleResidue> list_triangles,String residue_name1,String residue_name2){
	ArrayList<Residue> myList= new ArrayList<Residue>();
	for (TriangleResidue triangle:list_triangles){ 
if (triangle.R1.get_ResidueName_ChainName_ResidueNumber().compareTo(residue_name1)==0&&triangle.R2.get_ResidueName_ChainName_ResidueNumber().compareTo(residue_name2)==0)
							myList.add(triangle.R3);
	}
 	 return myList;	
}




public Point get_geometric_average_Point(ArrayList<Point> l){
			double x=0,y=0,z=0;
			for(Point p:l){x+=p.x/l.size();y+=p.y/l.size();z+=p.z/l.size();}
			return new Point(x,y,z);}

public MT The_best_rotation(MT X,MT Y){
	MT S=X.identity(3);
	int i=0;
	double cur=20;
while(i<20){
	//System.out.println(i);
	MT S1=this.better_x_rotation(X,Y);
	MT Y1=S1.times(Y.transpose());S=S1.times(S);
	MT S2=this.better_y_rotation(X,Y1.transpose());
	MT Y2=S2.times(Y1); S=S2.times(S);
	MT S3=this.better_z_rotation(X,Y2.transpose());
	MT Y3=S3.times(Y2);
	S=S3.times(S);
	
	double rmsd=this.RMSD(X.transpose(),Y3);
	if(Math.abs(rmsd-cur)<0.001) break;
	else{
	cur=rmsd;
	Y=Y3.transpose();
	i++;
	}
	}
return S;}



public MT better_x_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
double c= this.get_anpha_radian(U);MT S1=this.get_x_rotation(c);MT S2=this.get_x_rotation(c+Math.PI);
double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
if (rmsd1<rmsd2)return S1;else return S2;}
public MT better_z_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
double c= this.get_gama_radian(U);MT S1=this.get_z_rotation(c);MT S2=this.get_z_rotation(c+Math.PI);
double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));if (rmsd1<rmsd2)return S1;else return S2;}

public MT better_y_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
double c= this.get_beta_radian(U);MT S1=this.get_y_rotation(c);MT S2=this.get_y_rotation(c+Math.PI);
double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
if (rmsd1<rmsd2)return S1;else return S2;}




public MT get_x_rotation(double x){MT A= new MT(3,3);A.data[0][0]=1;A.data[0][1]=0;A.data[0][2]=0;A.data[1][0]=0;A.data[1][1]=Math.cos(x);A.data[1][2]=Math.sin(-x);A.data[2][0]=0;A.data[2][1]=Math.sin(x);A.data[2][2]=Math.cos(x);return A;}

public MT get_y_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=0;A.data[0][2]=Math.sin(x);A.data[1][0]=0;A.data[1][1]=1;A.data[1][2]=0;A.data[2][1]=0;A.data[2][0]=Math.sin(-x);A.data[2][2]=Math.cos(x);return A;}

public MT get_z_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=Math.sin(-x);A.data[0][2]=0;A.data[1][0]=Math.sin(x);A.data[1][1]=Math.cos(x);A.data[1][2]=0;A.data[2][0]=0;A.data[2][1]=0;A.data[2][2]=1;return A;}


public double get_anpha_radian(MT U){
if(U.data[1][1]+U.data[2][2]!=0d)
return (Math.atan((U.data[2][1]-U.data[1][2])/(U.data[1][1]+U.data[2][2])));
else return(Math.PI/2); }
public double get_beta_radian(MT U){
if(U.data[0][0]+U.data[2][2]!=0d)
return (Math.atan((-U.data[2][0]+U.data[0][2])/(U.data[0][0]+U.data[2][2])));
else return(Math.PI/2); }
public double get_gama_radian(MT U){
if(U.data[0][0]+U.data[1][1]!=0d)
return (Math.atan((U.data[1][0]-U.data[0][1])/(U.data[1][1]+U.data[0][0])));
else return(Math.PI/2); }




public double RMSD(MT A,MT B){if(A.M==B.M&&A.N==B.N){
	double d=0d;
for (int j =0;j<A.N;j++)
		{d=d+Math.pow((A.data[0][j]-B.data[0][j]),2)+Math.pow((A.data[1][j]-B.data[1][j]),2)+Math.pow((A.data[2][j]-B.data[2][j]),2);}
	return Math.sqrt(d/A.N); }
else throw new RuntimeException("Illegal matrix dimensions.");}








public ArrayList<String> fill_list_representative_atom_table_sidechain_backbone()throws Exception{
		String path = "Importance" + File.separator + "representativeAtomTableSidechainBackbone.txt";

	ArrayList<String> l=new ArrayList<String>();
	Scanner in=new Scanner(new FileInputStream(path));
	while(in.hasNextLine()){ 
		String line=in.nextLine();
		String [] name=line.split("-");
		for(String s: name) l.add(s);}
	in.close();
		return l;
	}

public ArrayList<String> fill_list_representative_atom_table_sidechain()throws Exception{ 
		String path = "Importance" + File.separator + "representativeAtomTableSidechain.txt";

	ArrayList<String> l1=new ArrayList<String>();
	Scanner in=new Scanner(new FileInputStream(path));
	while(in.hasNextLine()){ 
		String line=in.nextLine();
		String [] name=line.split("-");
		for(String s: name) l1.add(s);}
	in.close();
		return l1;
	}


public ArrayList<String> fill_list_representative_atom_table_backbone()throws Exception{
		String path = "Importance" + File.separator + "representativeAtomTableBackbone.txt";
	ArrayList<String> l2=new ArrayList<String>();
	Scanner in=new Scanner(new FileInputStream(path));
	while(in.hasNextLine()){ 
		String line=in.nextLine();
		String [] name=line.split("-");
		for(String s: name) l2.add(s);}
	in.close();
		return l2;
	}




public MT get_MT_from(ArrayList<Point> l){
	MT X=new MT(l.size(),3);
	for(int i =0;i<l.size();i++){
		X.data[i][0]=l.get(i).x;
		X.data[i][1]=l.get(i).y;
		X.data[i][2]=l.get(i).z;}return X;}
public Point get_Geometric_average_atom(ArrayList<Point> list){
	double x=0d,y=0d,z=0d;	int l=list.size();
		for(Point p :list)
			{
			 x+=p.x;
			 y+=p.y;
			 z+=p.z;
			}
			return new Point(x/l,y/l,z/l);}

 	
	


 boolean hasHELIXSHEETinPDBfile()throws Exception{
	boolean b = false;
	Scanner in=new Scanner(new FileInputStream(this.path_file));
	 while(in.hasNextLine()){
			String line=in.nextLine();
			if(line.startsWith("HELIX")||line.startsWith("SHEET")){ b=true;}}
	 in.close();

	return b;}


public int countNumberChain(String path)throws Exception{
	int x=0;
	Scanner in=new Scanner(new FileInputStream(path));
	 while(in.hasNextLine()){
			String line=in.nextLine();
			if (line.startsWith("TER")) x++;}
	 in.close();
	 if(x==0) return 1;
	 else
	return x;}



public ArrayList<ArrayList<Integer>> Label(String path)throws Exception{
	ArrayList<ArrayList<Integer>> label = new ArrayList<ArrayList<Integer>>(2);
	label.add(new ArrayList<Integer>());// helix
	label.add(new ArrayList<Integer>());// sheet

		Scanner in=new Scanner(new FileInputStream(path));
	    while(in.hasNextLine()){
		String line=in.nextLine(); 
if(line.startsWith("HELIX")){
			String r1=line.substring(21,25).trim();//initial number
			String r2=line.substring(33,37).trim();//end number
			int begin = Integer.parseInt(r1.trim());
			int end = Integer.parseInt(r2.trim());
			label.get(0).add(begin);
			label.get(0).add(end );	
}


else if(line.startsWith("SHEET")){
	String r1=line.substring(22,26).trim();//initial number
	String r2=line.substring(33,37).trim();//end number
	int begin = Integer.parseInt(r1.trim());
	int end = Integer.parseInt(r2.trim());
	label.get(1).add(begin);
	label.get(1).add(end );

}
	    }
	    in.close();
	    return label;}



int getLabel(int residueNumber,ArrayList<ArrayList<Integer>> label){
	int l= 3;// loop
	for(int i= 0;i<label.get(0).size()-1;i=i+2){
			if(residueNumber>=label.get(0).get(i)&&residueNumber<=label.get(0).get(i+1))
		{
			l=1; break;
				}}
			if(l==1) return l;
	else {
		for(int i= 0;i<label.get(1).size()-1;i=i+2){
			if(residueNumber>=label.get(1).get(i)&&residueNumber<=label.get(1).get(i+1))
			{
				l=2; break;
			}
			}
		return l;
			}

}

/*
		void get_listOH()throws Exception{
					Scanner in=new Scanner(new FileInputStream(this.path_file));
						while(in.hasNextLine()){
						String line=in.nextLine(); 
				if(line.startsWith("ATOM")){
						String r2=line.substring(12,16).trim();//atom name
						String r5=line.substring(21,22);//chain name 
						
						if(r5.compareTo("A")==0){
							if(r2.compareTo("O")==0||r2.compareTo("N")==0){
						String r7=line.substring(30,38); 
						String r8=line.substring(38,46);
						String r9=line.substring(46,54);
			this.listOH.add(new Point(Double.parseDouble(r7),Double.parseDouble(r8),Double.parseDouble(r9)));
											}}}}
						in.close();}*/







public ArrayList<ArrayList<Residue>> get_list_all_residues_from_PDBfile(String path,String PDBcode)throws Exception{
	ArrayList<ArrayList<Integer>> label =this.Label(path);
	int numberChain= this.countNumberChain(path);
	ArrayList<ArrayList<Representative_Atom>> listOfList = new ArrayList<ArrayList<Representative_Atom>>();
	for(int i=0;i<numberChain;i++)listOfList.add(new ArrayList<Representative_Atom>());
	
	ArrayList<String> l=null;
if(this.STRUCTURElevel==0)  l=this.fill_list_representative_atom_table_sidechain_backbone();
else if(this.STRUCTURElevel==1)l=this.fill_list_representative_atom_table_sidechain();
else if(this.STRUCTURElevel==2)l=this.fill_list_representative_atom_table_backbone();
	
		Scanner in=new Scanner(new FileInputStream(path));

	 boolean read_more = true; int x=0;
	    while((in.hasNextLine())&&(read_more)){
		String line=in.nextLine(); 
if(line.startsWith("ATOM")){
			String r2=line.substring(12,16).trim();//atom name
			String r3=line.substring(17,20).trim();//residue name
			String r23=line.substring(16,17);
				if (l.contains(r3 + r2)
					&& (r23.compareTo(" ") == 0 || r23.compareTo("A") == 0 || r23.compareTo("B") == 0)) {
			String r5=line.substring(21,22);//chain name
			String r6=line.substring(22,27).trim();  
			String r7=line.substring(30,38); 
			String r8=line.substring(38,46);
			String r9=line.substring(46,54);
if(Character.isDigit(r6.charAt(r6.length()-1))){} else {r6=r6.substring(0,r6.length()-1);
}
			int seq_no = Integer.parseInt(r6);
			Representative_Atom atom=new Representative_Atom(r3,seq_no,r5,r2,new Point(Double.parseDouble(r7),Double.parseDouble(r8),Double.parseDouble(r9)));
			listOfList.get(x).add(atom);}}
			
	else if (line.startsWith("TER")) x++;
	//else if (line.startsWith("END")||line.startsWith("ENDMDL")) read_more = false;
			} 
	 
		in.close();
		
		
		

if(listOfList.size()!=0){

ArrayList<ArrayList<Residue>>listListR = new ArrayList<ArrayList<Residue>>();

for (int i=0;i<listOfList.size();i++){
	listListR.add(new ArrayList<Residue>());}

for(int M=0;M<listOfList.size();M++){
int n=listOfList.get(M).size();
for (int i=0;i<n-2;i=i+3){
	ArrayList<Representative_Atom> listA= new ArrayList<Representative_Atom>();
	listA.add(listOfList.get(M).get(i));
	listA.add(listOfList.get(M).get(i+1));
	listA.add(listOfList.get(M).get(i+2));
	int Label= this.getLabel(listA.get(0).Residue_Number, label);
	int polarity =this.polarity.get(listA.get(0).Residue_Name);
	listListR.get(M).add(new Residue(PDBcode,listA,Label,polarity));
	}
}

	
ArrayList<Integer> lis =new ArrayList<Integer>();
	lis.add(0);
	
for (int i=1;i<listListR.size();i++){
	ArrayList<Residue> l1 = listListR.get(i);
		boolean add = true;
		for(int j: lis){
			if(this.identical(l1,listListR.get(j))||this.identical(listListR.get(j),l1)){
						add = false;break;}
				}
		
		if(add==true){lis.add(i);}
	}

ArrayList<ArrayList<Residue>>MylistListR = new ArrayList<ArrayList<Residue>>();
for(int i: lis){
	MylistListR.add(listListR.get(i));}

for (int i=MylistListR.size()-1;i>=0;i--){if(MylistListR.get(i).size()<8){MylistListR.remove(i);}}



if(MylistListR.size()>10) {
	for (int i=MylistListR.size()-1;i>6;i--)
		MylistListR.remove(i);}




return MylistListR;}else return null;
			}




public ArrayList<Residue> readHETATMline(ArrayList<Residue> listR)throws Exception{

	Scanner in=new Scanner(new FileInputStream(this.path_file));
	
 if(listR.size()>0){
	 String chain = listR.get(0).Chain_Name; 
	String pdbCode=listR.get(0).TargetProtein_id;
    while(in.hasNextLine()){
	String line=in.nextLine(); 
if(line.startsWith("HETATM")){
		String r2=line.substring(12,16).trim();//atom name
		String r3=line.substring(17,20).trim();//residue name
		String r23=line.substring(16,17);
		String r5=line.substring(21,22);
if(r2.compareTo("MO3")==0||r2.compareTo("MG")==0) {r3="MG";r2="MG";}
if(r2.compareTo("FE1")==0||r2.compareTo("FE2")==0||r2.compareTo("FE")==0) {r3="FE";r2="FE";}
if(r2.compareTo("CU1")==0||r2.compareTo("CUA")==0||r2.compareTo("CU")==0) {r3="CU";r2="CU";}
if(r2.compareTo("ZNO")==0||r2.compareTo("ZN1")==0||r2.compareTo("ZN")==0) {r3="ZN";r2="ZN";}

if((r2.compareTo("ZN")==0||r2.compareTo("CU")==0||r2.compareTo("FE")==0||r2.compareTo("MG")==0)&&r5.compareTo(chain)==0&&(r23.compareTo(" ")==0 ||r23.compareTo("A")==0)){
		String r6=line.substring(22,27).trim();  
		String r7=line.substring(30,38); 
		String r8=line.substring(38,46);
		String r9=line.substring(46,54);
if(Character.isDigit(r6.charAt(r6.length()-1))){} else {r6=r6.substring(0,r6.length()-1);}
		int seq_no = Integer.parseInt(r6);
		ArrayList<Representative_Atom> ls= new ArrayList<Representative_Atom>();
		ls.add(new Representative_Atom(r3,seq_no,r5,r2,new Point(Double.parseDouble(r7),Double.parseDouble(r8),Double.parseDouble(r9))));
		listR.add(new Residue(pdbCode,ls,4,4));		
}}}  in.close();
//System.out.println("list_All_Residues123 "+listR.size());
 }

return listR;
}





public ArrayList<ArrayList<Residue>> get_list_all_residues_from_PDBfile3(String path,String PDBcode)throws Exception{
	int numberChain= this.countNumberChain(path);
	ArrayList<ArrayList<Representative_Atom>> listOfList = new ArrayList<ArrayList<Representative_Atom>>();
	for(int i=0;i<numberChain;i++)listOfList.add(new ArrayList<Representative_Atom>());
	
	ArrayList<String> l=null;
if(this.STRUCTURElevel==0)  l=this.fill_list_representative_atom_table_sidechain_backbone();
else if(this.STRUCTURElevel==1)l=this.fill_list_representative_atom_table_sidechain();
else if(this.STRUCTURElevel==2)l=this.fill_list_representative_atom_table_backbone();
	
		Scanner in=new Scanner(new FileInputStream(path));

	 boolean read_more = true; int x=0;
	    while((in.hasNextLine())&&(read_more)){
		String line=in.nextLine(); 
if(line.startsWith("ATOM")){
			String r2=line.substring(12,16).trim();//atom name
			String r3=line.substring(17,20).trim();//residue name
			String r23=line.substring(16,17);
	if(l.contains(r3+r2)&&(r23.compareTo(" ")==0 ||r23.compareTo("A")==0)){
			String r5=line.substring(21,22);//chain name
			String r6=line.substring(22,27).trim();  
			String r7=line.substring(30,38); 
			String r8=line.substring(38,46);
			String r9=line.substring(46,54);
if(Character.isDigit(r6.charAt(r6.length()-1))){} else {r6=r6.substring(0,r6.length()-1);
}
			int seq_no = Integer.parseInt(r6);
			Representative_Atom atom=new Representative_Atom(r3,seq_no,r5,r2,new Point(Double.parseDouble(r7),Double.parseDouble(r8),Double.parseDouble(r9)));
			listOfList.get(x).add(atom);}}
			
	else if (line.startsWith("TER")) x++;
	//else if (line.startsWith("END")||line.startsWith("ENDMDL")) read_more = false;
			} 
	 
		in.close();
		
		
		

if(listOfList.size()!=0){

ArrayList<ArrayList<Residue>>listListR = new ArrayList<ArrayList<Residue>>();

for (int i=0;i<listOfList.size();i++){
	listListR.add(new ArrayList<Residue>());}

for(int M=0;M<listOfList.size();M++){
int n=listOfList.get(M).size();
if(this.STRUCTURElevel==2||this.STRUCTURElevel==1){
for (int i=0;i<n-2;i=i+3){
	ArrayList<Representative_Atom> listA= new ArrayList<Representative_Atom>();
	listA.add(listOfList.get(M).get(i));
	listA.add(listOfList.get(M).get(i+1));
	listA.add(listOfList.get(M).get(i+2));
	int Label= 4;//dont care
	int polarity =4;//dont care
	listListR.get(M).add(new Residue(PDBcode,listA,Label,polarity));
	}
									}

else{
	for (int i=0;i<n-5;i=i+6){
	ArrayList<Representative_Atom> listA= new ArrayList<Representative_Atom>();
	listA.add(listOfList.get(M).get(i));
	listA.add(listOfList.get(M).get(i+1));
	listA.add(listOfList.get(M).get(i+2));
	listA.add(listOfList.get(M).get(i+3));
	listA.add(listOfList.get(M).get(i+4));
	listA.add(listOfList.get(M).get(i+5));
	int Label= 4;//dont care
	int polarity =4;//dont care
	listListR.get(M).add(new Residue(PDBcode,listA,Label,polarity));
	}
	}
			}

	
ArrayList<Integer> lis =new ArrayList<Integer>();
	lis.add(0);
	
for (int i=1;i<listListR.size();i++){
	ArrayList<Residue> l1 = listListR.get(i);
		boolean add = true;
		for(int j: lis){
			if(this.identical(l1,listListR.get(j))||this.identical(listListR.get(j),l1)){
						add = false;break;}
				}
		
		if(add==true){lis.add(i);}
	}

ArrayList<ArrayList<Residue>>MylistListR = new ArrayList<ArrayList<Residue>>();
for(int i: lis){
	MylistListR.add(listListR.get(i));}

for (int i=MylistListR.size()-1;i>=0;i--){
	if(MylistListR.get(i).size()<3){MylistListR.remove(i);}}

if(MylistListR.size()>10) {
	for (int i=MylistListR.size()-1;i>6;i--)
		MylistListR.remove(i);}

ArrayList<ArrayList<Residue>>MylistListR1 = new ArrayList<ArrayList<Residue>>();

for (int i=0;i<MylistListR.size();i++){
	ArrayList<Residue> l1 = MylistListR.get(i);
	MylistListR1.add(this.readHETATMline(l1));
	}


return MylistListR1;}else return null;
			}


public ArrayList<ArrayList<Residue2>> get_list_all_residues_from_PDBfile2(String path,String PDBcode)throws Exception{
	//ArrayList<ArrayList<Integer>> label =this.Label(path);
	int numberChain= this.countNumberChain(path);
	//System.out.println("ccc"+numberChain);
	ArrayList<ArrayList<Representative_Atom>> listOfList = new ArrayList<ArrayList<Representative_Atom>>();
	for(int i=0;i<numberChain;i++)listOfList.add(new ArrayList<Representative_Atom>());
	
	ArrayList<String> l=null;
if(this.STRUCTURElevel==0)  l=this.fill_list_representative_atom_table_sidechain_backbone();
else if(this.STRUCTURElevel==1)l=this.fill_list_representative_atom_table_sidechain();
else if(this.STRUCTURElevel==2)l=this.fill_list_representative_atom_table_backbone();
	
		Scanner in=new Scanner(new FileInputStream(path));

	 boolean read_more = true; int x=0;
	    while((in.hasNextLine())&&(read_more)){
		String line=in.nextLine(); 
if(line.startsWith("ATOM")){
			String r2=line.substring(12,16).trim();//atom name
			String r3=line.substring(17,20).trim();//residue name
			String r23=line.substring(16,17);
				if (l.contains(r3 + r2)
					&& (r23.compareTo(" ") == 0 || r23.compareTo("A") == 0 || r23.compareTo("B") == 0)) {
			String r5=line.substring(21,22);//chain name
			String r6=line.substring(22,27).trim();  
			String r7=line.substring(30,38); 
			String r8=line.substring(38,46);
			String r9=line.substring(46,54);
if(Character.isDigit(r6.charAt(r6.length()-1))){} else {r6=r6.substring(0,r6.length()-1);
}
			int seq_no = Integer.parseInt(r6);
			Representative_Atom atom=new Representative_Atom(r3,seq_no,r5,r2,new Point(Double.parseDouble(r7),Double.parseDouble(r8),Double.parseDouble(r9)));
			listOfList.get(x).add(atom);}}
			
			else if (line.startsWith("TER"))
				x++;
			else if (line.startsWith("END") || line.startsWith("ENDMDL"))
				read_more = false;
			} 
	 
		in.close();
		
		
		

if(listOfList.size()!=0){

ArrayList<ArrayList<Residue2>>listListR = new ArrayList<ArrayList<Residue2>>();

for (int i=0;i<listOfList.size();i++){
	listListR.add(new ArrayList<Residue2>());}

for(int M=0;M<listOfList.size();M++){
int n=listOfList.get(M).size();
for (int i=0;i<n-2;i=i+3){
	ArrayList<Representative_Atom> listA= new ArrayList<Representative_Atom>();
	listA.add(listOfList.get(M).get(i));
	listA.add(listOfList.get(M).get(i+1));
	listA.add(listOfList.get(M).get(i+2));
	//int Label= this.getLabel(listA.get(0).Residue_Number, label);
	//int polarity =this.polarity.get(listA.get(0).Residue_Name);
	listListR.get(M).add(new Residue2(listA,PDBcode));
	//listListR.get(M).add(new Residue(PDBcode,listA,Label,polarity));
	}
}

/*
for (int i=0;i<listListR.size();i++){
	System.out.println("sss"+listListR.get(i).size());
				}*/





ArrayList<Integer> lis =new ArrayList<Integer>();
	lis.add(0);
	
for (int i=1;i<listListR.size();i++){
	ArrayList<Residue2> l1 = listListR.get(i);
		boolean add = true;
		for(int j: lis){
			if(this.identical2(l1,listListR.get(j))||this.identical2(listListR.get(j),l1)){
						add = false;break;}
				}
		
		if(add==true){lis.add(i);}
	}

ArrayList<ArrayList<Residue2>>MylistListR = new ArrayList<ArrayList<Residue2>>();
for(int i: lis){
	MylistListR.add(listListR.get(i));}

for (int i=MylistListR.size()-1;i>=0;i--){if(MylistListR.get(i).size()<8){MylistListR.remove(i);}}

if(MylistListR.size()>10) {
	for (int i=MylistListR.size()-1;i>6;i--)
		MylistListR.remove(i);}


return MylistListR;} else return null;
			} 


public boolean identical(Residue R1,Residue R2,Residue R3,Residue R4,Residue R5,Residue RR1,Residue RR2,Residue RR3,Residue RR4,Residue RR5){
	if(R1.Residue_Name.compareTo(RR1.Residue_Name)==0&&R2.Residue_Name.compareTo(RR2.Residue_Name)==0&&R3.Residue_Name.compareTo(RR3.Residue_Name)==0&&R4.Residue_Name.compareTo(RR4.Residue_Name)==0&&R5.Residue_Name.compareTo(RR5.Residue_Name)==0)
return true;else return false;
}

public boolean identical2(Residue2 R1,Residue2 R2,Residue2 R3,Residue2 R4,Residue2 R5,Residue2 RR1,Residue2 RR2,Residue2 RR3,Residue2 RR4,Residue2 RR5){
	if(R1.Residue_Name.compareTo(RR1.Residue_Name)==0&&R2.Residue_Name.compareTo(RR2.Residue_Name)==0&&R3.Residue_Name.compareTo(RR3.Residue_Name)==0&&R4.Residue_Name.compareTo(RR4.Residue_Name)==0&&R5.Residue_Name.compareTo(RR5.Residue_Name)==0)
return true;else return false;
}
public boolean identical(ArrayList<Residue> l1, ArrayList<Residue> l2){
	//the first six  residues of l1 repeat in l2 (one of the first 15 position)
	if(l1.size()>8&&l2.size()>8){
	boolean identical = false;
	for(int i=0;i<5;i++){
		
			//System.out.println(l1.get(i+k).Residue_Name+"   "+l2.get(k).Residue_Name);
			if(this.identical(l1.get(i),l1.get(i+1),l1.get(i+2),l1.get(i+3),l1.get(i+4),l2.get(0),l2.get(1),l2.get(2),l2.get(3),l2.get(4))){identical = true;break;}
		
	}
	
	return identical;}else{return false;}
}

public boolean identical2(ArrayList<Residue2> l1, ArrayList<Residue2> l2){
	//the first six  residues of l1 repeat in l2 (one of the first 5 position)
	if(l1.size()>8&&l2.size()>8){
	boolean identical = false;
	for(int i=0;i<5;i++){
		
			//System.out.println(l1.get(i+k).Residue_Name+"   "+l2.get(k).Residue_Name);
			if(this.identical2(l1.get(i),l1.get(i+1),l1.get(i+2),l1.get(i+3),l1.get(i+4),l2.get(0),l2.get(1),l2.get(2),l2.get(3),l2.get(4))){identical = true;break;}
		
	}
	
	return identical;}else{return false;}
}
 }
 	


 

class Residue2 implements java.io.Serializable{
		private static final long serialVersionUID = 1007L;
		ArrayList<Representative_Atom> list_Atoms;
		String Chain_Name;
		String Residue_Name;
		String TargetProtein_id;
		
Residue2(ArrayList<Representative_Atom>list_Atoms,String TargetProtein_id){
		this.list_Atoms=list_Atoms;
		this.Residue_Name=list_Atoms.get(0).Residue_Name;
		this.Chain_Name = list_Atoms.get(0).Chain_Name;
		this.TargetProtein_id = TargetProtein_id;
		}}

class Fragment implements java.io.Serializable {

	private static final long serialVersionUID = 307L;
	ArrayList<Residue> listResidue;

	Fragment(ArrayList<Residue> ListResidue) {
		this.listResidue = ListResidue;
	}

	ArrayList<Residue> getListResidue() {
		return this.listResidue;
	}

}

class FragmentAlignment implements java.io.Serializable {
	private static final long serialVersionUID = 321L;
	Fragment hit;
	Fragment input;
	double GLscore;
	int SSE;// number of identical Secondary structures;

	FragmentAlignment(Fragment Hit, Fragment Input, double GLscore, int SSE) {
		this.input = Input;
		this.hit = Hit;
		this.GLscore = GLscore;
		this.SSE = SSE;
	}
	FragmentAlignment(Fragment Hit, Fragment Input) {
		this.input = Input;
		this.hit = Hit;
	}

	Fragment getHit() {
		return this.hit;
	}

	Fragment getInput() {
		return this.input;
	}
}


  class Residue implements java.io.Serializable{
		private static final long serialVersionUID = 13L;
	  
	int polarity; //1= polar, 2= nonpolar , 3 =else
	int label;// 1 =helix 2 =sheet 3= else
	//int trueLable;// 1,2,3....m if there are many helix in structure,truelabel tell which one exactly.The same for sheet and coil 
	String Chain_Name;
	String Residue_Name;
	int Residue_number;
	String TargetProtein_id; 
	ArrayList<Representative_Atom> list_Atoms;
	Residue(String TargetProtein_id,ArrayList<Representative_Atom>list_Atoms,int label,int polarity){
			this.polarity = polarity;
		  	this.label = label;
		 // 	this.trueLable= trueLable;
		  	this.list_Atoms=list_Atoms;
		  	this.Chain_Name = list_Atoms.get(0).Chain_Name;
			this.Residue_Name=list_Atoms.get(0).Residue_Name;
			this.Residue_number=list_Atoms.get(0).Residue_Number;
			this.list_Atoms=list_Atoms;
			this.TargetProtein_id=TargetProtein_id;}
	
	Residue(Residue2 R,int label,int polarity){
		
	 // this.trueLable= trueLable;
	  	this.list_Atoms=R.list_Atoms;
	  	this.polarity = polarity;
	  	this.label = label;
	  	this.Chain_Name = list_Atoms.get(0).Chain_Name;
		this.Residue_Name=list_Atoms.get(0).Residue_Name;
		this.Residue_number=list_Atoms.get(0).Residue_Number;
		this.TargetProtein_id=R.TargetProtein_id;}
	
	
 
 
 
	public String get_ResidueName_ChainName_ResidueNumber(){
return this.Residue_Name+this.Chain_Name+this.Residue_number;
				}
	public String toString() {
return this.Residue_Name+" "+this.Residue_number+" "+this.Chain_Name;
				}
	
	
	public Point get_Geometric_Everage_Atom(){double x=0d,y=0d,z=0d;	int l=this.list_Atoms.size();
	for(Representative_Atom r :this.list_Atoms)
		{
		 x+=r.Atom_Coordinate.x;
		 y+=r.Atom_Coordinate.y;
		 z+=r.Atom_Coordinate.z;
		}
		if(l!=0) return new Point(x/l,y/l,z/l); else return null;}
	
	public double get_distanceTo(Residue another_residue){
		Point A,B;
		if(this.label==4){
				A = this.get_Geometric_Everage_Atom();
				B = another_residue.get_Geometric_Everage_Atom();
					}
		else {
		A = this.list_Atoms.get(1).Atom_Coordinate;
		B = another_residue.list_Atoms.get(1).Atom_Coordinate;
		}
			return(A.distanceTo(B));}}



 

 


  class Representative_Atom implements java.io.Serializable{
		private static final long serialVersionUID = 17L;
			public String Residue_Name;
			public int Residue_Number;
			public String Chain_Name;
			public String Atom_Name;
			public Point Atom_Coordinate;
			public Representative_Atom(String Residue_Name,int Residue_Number,String Chain_Name,String Atom_Name,Point Atom_Coordinate){
				this.Chain_Name=Chain_Name;
				this.Residue_Name =Residue_Name;
				this.Residue_Number= Residue_Number;
				this.Atom_Name=Atom_Name;
				this.Atom_Coordinate=Atom_Coordinate;}
	
	public String  toString(){
		
		return  Atom_Name;
	}
	}
  class Point implements java.io.Serializable{
		private static final long serialVersionUID = 7L;
	    	  public double x ;
	  	 	  public double y ;
		 	  public double z ;
		 
	   	public Point(double x,double y,double z) {
			this.x = x;
			this.y = y;
			this.z = z;			}
		public double distanceTo(Point B){
			Point A=this;
			return Math.sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y)+(A.z-B.z)*(A.z-B.z));}
		public String  toString(){
			
			return String.format("%.2f",this.x)+"  "+String.format("%.2f",this.y)+"  "+String.format("%.2f",this.z);
		}

			}
		
  
 
  class Neibourhood implements java.io.Serializable{
		private static final long serialVersionUID =  223L;
		ArrayList<Integer> listNeibor;
		Neibourhood (ArrayList<Integer> listNeibor){
			this.listNeibor = listNeibor;
		}
		ArrayList<Integer> getLisNerbor()
		{
			return listNeibor;
		}
		

}
  
  class Myresult implements java.io.Serializable{
		private static final long serialVersionUID =  227L;
		ArrayList<Alignment> listAlignments ; 
		Myresult(ArrayList<Alignment> listAlignments ){
			this.listAlignments= listAlignments;
		}
		ArrayList<Alignment> getResult()
		{
			return listAlignments;
		}
		

}
  
class CompleteFragmentAlignment {

	ArrayList<FragmentAlignment> fragmentAlignments;

	CompleteFragmentAlignment(ArrayList<FragmentAlignment> fragmentAlignments) {
		this.fragmentAlignments = fragmentAlignments;
	}

	CompleteFragmentAlignment(ArrayList<Fragment> hit, ArrayList<Fragment> input) {
		this.fragmentAlignments = new ArrayList<FragmentAlignment>();
		for (int i = 0; i < hit.size(); i++)
			this.fragmentAlignments.add(new FragmentAlignment(hit.get(i), input.get(i)));

	}

	ArrayList<FragmentAlignment> getFragmentAlignments() {
		return this.fragmentAlignments;
	}
}

  class PreAlignment {
		/* Pre alignment is the real alignment if its tm score is highest*/
		ArrayList<Residue> ListInputResidues;// from input protein
		ArrayList<Residue> ListHitResidues;//from proteins on pdb 25
	int Lmin;// of input protein
	double evolScore;
	double tm;

	PreAlignment(PreAlignment pre, double tm) {
		this.ListInputResidues = pre.getListInputResidues();
		this.ListHitResidues = pre.getListHitResidues();
		this.tm = tm;
	}
		public PreAlignment(ArrayList<Residue> ListHitResidues,ArrayList<Residue> ListInputResidues, int length) {
			this.ListInputResidues = ListInputResidues;
			this.ListHitResidues = ListHitResidues;
		this.Lmin = length;
		}

	public PreAlignment(ArrayList<Residue> ListHitResidues, ArrayList<Residue> ListInputResidues, double evolScore) {
		this.ListInputResidues = ListInputResidues;
		this.ListHitResidues = ListHitResidues;
		this.evolScore = evolScore;
	}

	ArrayList<Residue> getListInputResidues() {
		return this.ListInputResidues;
	}

	ArrayList<Residue> getListHitResidues() {
		return this.ListHitResidues;
	}
		
		
	double getEvolScore() {
		return this.evolScore;
	}

	double tm() {
		return this.tm;
	}
		double getTMscore(){ 
			double TMscore = 0;
			ArrayList<Point> l2=new ArrayList<Point>();
			for(Residue R : this.ListHitResidues )
				for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
			
			ArrayList<Point> l1=new ArrayList<Point>();
			for(Residue R : this.ListInputResidues)
				for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
			Point O1 = this.get_geometric_average_Point(l1);
			Point O2 = this.get_geometric_average_Point(l2);
			MT Y=this.get_MT_from(l1).translation_to_the_Origin(O1);
			MT X=this.get_MT_from(l2).translation_to_the_Origin(O2);
			MT S=this.The_best_rotation(X,Y);
			double ex= (double)1.0/3.0;
			// int Lmin=this.length;
		// int Lmin = Math.min(this.ListInputResidues.size(), this.ListInputResidues.size());
				
			double d8=1.5*Math.pow(Lmin,0.3)+3.5;
		double d0 = 0.168;
		if (Lmin > 19)
			d0 = 1.24 * Math.pow((Lmin - 15), ex) - 1.8;
			for(int i=1;i<X.M;i=i+3){
				MT I = new MT(3,1);
				I.data[0][0]=Y.data[i][0];
				I.data[1][0]=Y.data[i][1];
				I.data[2][0]=Y.data[i][2];
				MT R= S.times(I);
				/*Point P1=new Point(R.data[0][0],R.data[1][0],R.data[2][0]);
				Point P2=new Point(X.data[i][0],X.data[i][1],X.data[i][2]);
				double di=P1.distanceTo(P2);*/
				double di=Math.sqrt(Math.pow(R.data[0][0]-X.data[i][0],2)+Math.pow(R.data[1][0]-X.data[i][1],2)+Math.pow(R.data[2][0]-X.data[i][2],2));
				if(di<d8)
				TMscore=TMscore+1/(1+di*di/(d0*d0));
			}
		
			return TMscore/Lmin;
		}	
  
  
		
		public MT get_rotational_Matrix(){
			ArrayList<Point> l2=new ArrayList<Point>();
			for(Residue R : this.ListHitResidues )
				for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
			
			ArrayList<Point> l1=new ArrayList<Point>();
			for(Residue R : this.ListInputResidues)
				for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
			
			
			Point O1 = this.get_geometric_average_Point(l1);
			Point O2 = this.get_geometric_average_Point(l2);
			MT YY=this.get_MT_from(l1).translation_to_the_Origin(O1);
			MT XX=this.get_MT_from(l2).translation_to_the_Origin(O2);
			MT S=this.The_best_rotation(XX,YY);
			return S;
		}

		public Point center_of_inputResidues(){
				
				ArrayList<Point> l1=new ArrayList<Point>();
				for(Residue R : this.ListInputResidues)
					for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
				Point O1 = this.get_geometric_average_Point(l1);
				return O1;}


		public Point center_of_HitResidues(){
			
			ArrayList<Point> l2=new ArrayList<Point>();
			for(Residue R : this.ListHitResidues)
				for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
			Point O2 = this.get_geometric_average_Point(l2);
			return O2;}
			
			public double get_RMSD(){
				
				ArrayList<Point> l2=new ArrayList<Point>();
				for(Residue R :  this.ListHitResidues )
					for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
				
				ArrayList<Point> l1=new ArrayList<Point>();
				for(Residue R : this.ListInputResidues )
					for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
				
				
				Point O1 = this.get_geometric_average_Point(l1);
				Point O2 = this.get_geometric_average_Point(l2);
				MT YY=this.get_MT_from(l1).translation_to_the_Origin(O1);
				MT XX=this.get_MT_from(l2).translation_to_the_Origin(O2);
				MT S=this.The_best_rotation(XX,YY);
				double rmsd=this.RMSD(XX.transpose(),S.times(YY.transpose()));
				return rmsd;
			}
			
			
				
				public MT get_MT_from(ArrayList<Point> l){
					MT X=new MT(l.size(),3);
					for(int i =0;i<l.size();i++){
						X.data[i][0]=l.get(i).x;
						X.data[i][1]=l.get(i).y;
						X.data[i][2]=l.get(i).z;}return X;}

				public Point get_geometric_average_Point(ArrayList<Point> l){
					double x=0,y=0,z=0;
					for(Point p:l){x+=p.x/l.size();y+=p.y/l.size();z+=p.z/l.size();}
					return new Point(x,y,z);}

				public MT The_best_rotation(MT X,MT Y){
					MT S=X.identity(3);
					int i=0;
					double cur=20;
				while(i<20){
					//System.out.println(i);
					MT S1=this.better_x_rotation(X,Y);
					MT Y1=S1.times(Y.transpose());S=S1.times(S);
					MT S2=this.better_y_rotation(X,Y1.transpose());
					MT Y2=S2.times(Y1); S=S2.times(S);
					MT S3=this.better_z_rotation(X,Y2.transpose());
					MT Y3=S3.times(Y2);
					S=S3.times(S);
					
					double rmsd=this.RMSD(X.transpose(),Y3);
					if(Math.abs(rmsd-cur)<0.001) break;
					else{
					cur=rmsd;
					Y=Y3.transpose();
					i++;
					}
					}
				return S;}



		public MT better_x_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
		double c= this.get_anpha_radian(U);MT S1=this.get_x_rotation(c);MT S2=this.get_x_rotation(c+Math.PI);
		double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
		if (rmsd1<rmsd2)return S1;else return S2;}
		public MT better_z_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
		double c= this.get_gama_radian(U);MT S1=this.get_z_rotation(c);MT S2=this.get_z_rotation(c+Math.PI);
		double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));if (rmsd1<rmsd2)return S1;else return S2;}

		public MT better_y_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
		double c= this.get_beta_radian(U);MT S1=this.get_y_rotation(c);MT S2=this.get_y_rotation(c+Math.PI);
		double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
		if (rmsd1<rmsd2)return S1;else return S2;}




		public MT get_x_rotation(double x){MT A= new MT(3,3);A.data[0][0]=1;A.data[0][1]=0;A.data[0][2]=0;A.data[1][0]=0;A.data[1][1]=Math.cos(x);A.data[1][2]=Math.sin(-x);A.data[2][0]=0;A.data[2][1]=Math.sin(x);A.data[2][2]=Math.cos(x);return A;}

		public MT get_y_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=0;A.data[0][2]=Math.sin(x);A.data[1][0]=0;A.data[1][1]=1;A.data[1][2]=0;A.data[2][1]=0;A.data[2][0]=Math.sin(-x);A.data[2][2]=Math.cos(x);return A;}

		public MT get_z_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=Math.sin(-x);A.data[0][2]=0;A.data[1][0]=Math.sin(x);A.data[1][1]=Math.cos(x);A.data[1][2]=0;A.data[2][0]=0;A.data[2][1]=0;A.data[2][2]=1;return A;}


		public double get_anpha_radian(MT U){
		if(U.data[1][1]+U.data[2][2]!=0d)
		return (Math.atan((U.data[2][1]-U.data[1][2])/(U.data[1][1]+U.data[2][2])));
		else return(Math.PI/2); }
		public double get_beta_radian(MT U){
		if(U.data[0][0]+U.data[2][2]!=0d)
		return (Math.atan((-U.data[2][0]+U.data[0][2])/(U.data[0][0]+U.data[2][2])));
		else return(Math.PI/2); }
		public double get_gama_radian(MT U){
		if(U.data[0][0]+U.data[1][1]!=0d)
		return (Math.atan((U.data[1][0]-U.data[0][1])/(U.data[1][1]+U.data[0][0])));
		else return(Math.PI/2); }




		public double RMSD(MT A,MT B){if(A.M==B.M&&A.N==B.N){
			double d=0d;
		for (int j =0;j<A.N;j++)
				{d=d+Math.pow((A.data[0][j]-B.data[0][j]),2)+Math.pow((A.data[1][j]-B.data[1][j]),2)+Math.pow((A.data[2][j]-B.data[2][j]),2);}
			return Math.sqrt(d/A.N); }
		else throw new RuntimeException("Illegal matrix dimensions.");}
		
		
  
  }
  
  
  
  
  
  class Alignment implements java.io.Serializable{
		/* match between subset of input residues (input protein) and subset of residues of protein  found on PDB 25 list*/
		private static final long serialVersionUID = 1L;
		String InputProteinID;
		String HitProteinID;
		String InputResidues;
		String HitProteinResidues;
		//String enzymeFunction;
		ArrayList<Residue> ListInputResidues;// from input protein
		ArrayList<Residue> ListHitResidues;//from proteins on pdb 25
		double score;
		double RMSD;
		double residueIDENTITY;//percent
	double blosum;
	double clesum;
	double hydrogenBondSimilarity;
	double evolutionScore;
		String HitProteinDescription;//header of pdb file
		String path;
	String KnownProteinPath;
	ArrayList<HashMap<String, String>> color1;// using distance
	ArrayList<HashMap<String, String>> color2;// using blosum
	String[] seqAl;
		
		
	public Alignment(ArrayList<Residue> ListHitResidues, ArrayList<Residue> ListInputResidues, String path,
		String KnownProteinPath) throws Exception {
			this.path= path;
		this.KnownProteinPath = KnownProteinPath;
			this.ListInputResidues = ListInputResidues;
			this.ListHitResidues = ListHitResidues;
			this.InputResidues = this.showInputResidues();
			this.HitProteinResidues = this.showHitResidues();
			this.InputProteinID = ListInputResidues.get(0).TargetProtein_id;
		this.HitProteinID = ListHitResidues.get(0).TargetProtein_id;
			this.RMSD=this.get_RMSD();
			this.score=ListInputResidues.size();
			this.residueIDENTITY=this.get_residueIDENTITY();
			HitProteinHeader();}
		
	public Alignment(PreAlignment Pre, String path, String KnownProteinPath) throws Exception {
			this.path=path;
		this.KnownProteinPath = KnownProteinPath;
			this.ListInputResidues = Pre.ListInputResidues;
			this.ListHitResidues = Pre.ListHitResidues;
			this.InputResidues = this.showInputResidues();
			this.HitProteinResidues = this.showHitResidues();
			this.InputProteinID = ListInputResidues.get(0).TargetProtein_id;
		this.HitProteinID = ListHitResidues.get(0).TargetProtein_id;
			//this.enzymeFunction=enzymeFunction;
			this.RMSD=this.get_RMSD();
			this.score=Pre.getTMscore();
			this.residueIDENTITY=this.get_residueIDENTITY();
			HitProteinHeader();}

	public Alignment(PreAlignment Pre, String path, String KnownProteinPath, double[] a,
		ArrayList<HashMap<String, String>> color1, ArrayList<HashMap<String, String>> color2, String[] seqAl)
			throws Exception {
		this.path = path;
		this.KnownProteinPath = KnownProteinPath;
		this.ListInputResidues = Pre.ListInputResidues;
		this.ListHitResidues = Pre.ListHitResidues;
		this.InputResidues = this.showInputResidues();
		this.HitProteinResidues = this.showHitResidues();
		this.InputProteinID = ListInputResidues.get(0).TargetProtein_id;
		this.HitProteinID = ListHitResidues.get(0).TargetProtein_id;
		// this.enzymeFunction=enzymeFunction;
		this.RMSD = this.get_RMSD();
		this.score = Pre.getTMscore();
		blosum = a[0];
		clesum = a[1];
		this.hydrogenBondSimilarity = a[2];
		this.evolutionScore = a[3];
		HitProteinHeader();
		this.color1 = color1;
		this.color2 = color2;
		this.seqAl = seqAl;
	}
	public Alignment(PreAlignment Pre, String path, String KnownProteinPath, double[] a) throws Exception {
		this.path = path;
		this.KnownProteinPath = KnownProteinPath;
		this.ListInputResidues = Pre.ListInputResidues;
		this.ListHitResidues = Pre.ListHitResidues;
		this.InputResidues = this.showInputResidues();
		this.HitProteinResidues = this.showHitResidues();
		this.InputProteinID = ListInputResidues.get(0).TargetProtein_id;
		this.HitProteinID = ListHitResidues.get(0).TargetProtein_id;
		// this.enzymeFunction=enzymeFunction;
		this.RMSD = this.get_RMSD();
		this.score = Pre.getTMscore();
		blosum = a[0];
		clesum = a[1];
		this.hydrogenBondSimilarity = a[2];
		this.evolutionScore = a[3];
		HitProteinHeader();
	}
		
		void HitProteinHeader() throws Exception{
		// String path = System.getProperty("user.dir") + File.separator + "PDBfiles"+
		// File.separator+this.HitProteinID+".pdb";
		String path = this.KnownProteinPath + File.separator + this.HitProteinID + ".pdb";

		Scanner in = new Scanner(new FileInputStream(path));
			boolean read_more = true; 
		    while((in.hasNextLine())&&(read_more)){
			String line=in.nextLine();
			//String s1="";
			//String s2="";
	if(line.startsWith("TITLE")){
		
		this.HitProteinDescription=line.substring(5,80).trim();
		/*
		String [] s =line.substring(5,80).trim().split("\\s+");
		if(s.length<5) this.HitProteinDescription=line.substring(5,80).trim();
		else {
			for(int i=0;i<5;i++) s1 = s1+s[i]+" ";
			for(int i=5;i<s.length;i++) s2 = s2+s[i]+" ";
			this.HitProteinDescription=s1.trim()+"\n"+s2.trim();
		}*/
				read_more = false;
				}}
		    in.close();}
		
		
		
		
		public ArrayList<String> toString(ArrayList<Residue>  ls){
			ArrayList<String> lisName = new ArrayList<String>();
			for(Residue R:ls) lisName.add(R.toString());
			Collections.sort(lisName);
			return lisName;}
		
		
		public boolean identity(ArrayList<String> lis1, ArrayList<String>lis2){
			int n1 =lis1.size();
			int n2 =lis2.size();
			if(n1!=n2) return false;
			else {
				boolean identical = true;
				for(int i=0;i<n1;i++){if(lis1.get(i).compareTo(lis2.get(i))==0){}else{identical=false;break;}}
				
				return identical;}}
		
		
		public boolean equals(Object obj) {
			if(this==null) return false;
			else {
				if (this == obj)  	return true;
				if (obj == null)	return false;
				if (getClass() != obj.getClass())return false;
				
				Alignment other = (Alignment) obj;
				ArrayList<String> newListHit1 = this.toString(this.ListHitResidues);
				ArrayList<String> newListHit2 = this.toString(other.ListHitResidues);
				ArrayList<String> newListInput1 = this.toString(this.ListInputResidues);
				ArrayList<String> newListInput2 = this.toString(other.ListInputResidues);
			
				if(this.identity(newListHit1,newListHit2)&&this.identity(newListInput1,newListInput2)){return true;}
				else return false;
			}
			

			}
		
		
		
		public String  getString(ArrayList<Residue> listRe){
			String s="";
			for(int i=0;i<listRe.size();i++) s=s+listRe.get(i).toString();
			return s;
		}
		/*
		public ArrayList<Residue> sort(ArrayList<Residue> listResidue){
			ArrayList<Residue> newList= new ArrayList<Residue>();
			HashMap<String,Residue> hm=new HashMap<String,Residue>();
			LinkedList <String> list = new LinkedList<String>();
			for(Residue R1:  listResidue )
				{
				list.add(R1.Residue_Name+R1.Chain_Name+R1.Residue_number);
				hm.put(R1.Residue_Name+R1.Chain_Name+R1.Residue_number,R1);
				}
		
			Collections.sort(list);
			for(int i=0;i<list.size();i++) newList.add(hm.get(list.get(i)));
			return newList;}
		*/
		
		
		public String showInputResidues(){
			String s="";
			for(Residue R : this.ListInputResidues) s=s+R.toString()+"\n";
				return s;
		}
		
		public String showHitResidues(){
			String s="";
			for(Residue R : this.ListHitResidues) s=s+R.toString()+"\n";
				return s;
		}
	 
		public double get_residueIDENTITY(){
			int n = this.ListInputResidues.size();
			int m = 0;
			for(int i=0;i<n;i++)
			{
				if(this.ListInputResidues.get(i).Residue_Name.compareTo(this.ListHitResidues.get(i).Residue_Name)==0){m++;}}
		
			
			return 100*m/(double)n;
		}
		


	public MT get_rotational_Matrix(){
		ArrayList<Point> l2=new ArrayList<Point>();
		for(Residue R : this.ListHitResidues )
			for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
		
		ArrayList<Point> l1=new ArrayList<Point>();
		for(Residue R : this.ListInputResidues)
			for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
		
		
		Point O1 = this.get_geometric_average_Point(l1);
		Point O2 = this.get_geometric_average_Point(l2);
		MT YY=this.get_MT_from(l1).translation_to_the_Origin(O1);
		MT XX=this.get_MT_from(l2).translation_to_the_Origin(O2);
		MT S=this.The_best_rotation(XX,YY);
		return S;
	}

	public Point center_of_inputResidues(){
			
			ArrayList<Point> l1=new ArrayList<Point>();
			for(Residue R : this.ListInputResidues)
				for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
			Point O1 = this.get_geometric_average_Point(l1);
			return O1;}


	public Point center_of_HitResidues(){
		
		ArrayList<Point> l2=new ArrayList<Point>();
		for(Residue R : this.ListHitResidues)
			for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
		Point O2 = this.get_geometric_average_Point(l2);
		return O2;}
		
		public double get_RMSD(){
			
			ArrayList<Point> l2=new ArrayList<Point>();
			for(Residue R :  this.ListHitResidues )
				for (Representative_Atom atom : R.list_Atoms) l2.add(atom.Atom_Coordinate);
			
			ArrayList<Point> l1=new ArrayList<Point>();
			for(Residue R : this.ListInputResidues )
				for (Representative_Atom atom : R.list_Atoms) l1.add(atom.Atom_Coordinate);
			
			
			Point O1 = this.get_geometric_average_Point(l1);
			Point O2 = this.get_geometric_average_Point(l2);
			MT YY=this.get_MT_from(l1).translation_to_the_Origin(O1);
			MT XX=this.get_MT_from(l2).translation_to_the_Origin(O2);
			MT S=this.The_best_rotation(XX,YY);
			double rmsd=this.RMSD(XX.transpose(),S.times(YY.transpose()));
			return rmsd;
		}
		
		
		  public String print_Score(){
			return String.format("%.4f",this.score);
					}
		   public String print_RMSD(){
				return String.format("%.2f",this.RMSD);
						}

	public String print_blosum() {
		return String.format("%.2f", this.blosum);
	}

	public String print_clesum() {
		return String.format("%.2f", this.clesum);
	}

	public String print_hyrd() {
		return String.format("%.2f", this.hydrogenBondSimilarity);
	}

	public String print_evol() {
		return String.format("%.2f", this.evolutionScore);
	}
			public String print_residueIdentity(){
				return String.format("%.2f",this.residueIDENTITY)+"%";
							}


			public String toString(){return this.HitProteinResidues+this.InputResidues;}	
			
			public MT get_MT_from(ArrayList<Point> l){
				MT X=new MT(l.size(),3);
				for(int i =0;i<l.size();i++){
					X.data[i][0]=l.get(i).x;
					X.data[i][1]=l.get(i).y;
					X.data[i][2]=l.get(i).z;}return X;}

			public Point get_geometric_average_Point(ArrayList<Point> l){
				double x=0,y=0,z=0;
				for(Point p:l){x+=p.x/l.size();y+=p.y/l.size();z+=p.z/l.size();}
				return new Point(x,y,z);}

			public MT The_best_rotation(MT X,MT Y){
				MT S=X.identity(3);
				int i=0;
				double cur=20;
			while(i<20){
				//System.out.println(i);
				MT S1=this.better_x_rotation(X,Y);
				MT Y1=S1.times(Y.transpose());S=S1.times(S);
				MT S2=this.better_y_rotation(X,Y1.transpose());
				MT Y2=S2.times(Y1); S=S2.times(S);
				MT S3=this.better_z_rotation(X,Y2.transpose());
				MT Y3=S3.times(Y2);
				S=S3.times(S);
				
				double rmsd=this.RMSD(X.transpose(),Y3);
				if(Math.abs(rmsd-cur)<0.001) break;
				else{
				cur=rmsd;
				Y=Y3.transpose();
				i++;
				}
				}
			return S;}



	public MT better_x_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
	double c= this.get_anpha_radian(U);MT S1=this.get_x_rotation(c);MT S2=this.get_x_rotation(c+Math.PI);
	double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
	if (rmsd1<rmsd2)return S1;else return S2;}
	public MT better_z_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
	double c= this.get_gama_radian(U);MT S1=this.get_z_rotation(c);MT S2=this.get_z_rotation(c+Math.PI);
	double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));if (rmsd1<rmsd2)return S1;else return S2;}

	public MT better_y_rotation(MT X,MT Y){MT U=X.transpose().times(Y);
	double c= this.get_beta_radian(U);MT S1=this.get_y_rotation(c);MT S2=this.get_y_rotation(c+Math.PI);
	double rmsd1=this.RMSD(X.transpose(),S1.times(Y.transpose()));double rmsd2=this.RMSD(X.transpose(),S2.times(Y.transpose()));
	if (rmsd1<rmsd2)return S1;else return S2;}




	public MT get_x_rotation(double x){MT A= new MT(3,3);A.data[0][0]=1;A.data[0][1]=0;A.data[0][2]=0;A.data[1][0]=0;A.data[1][1]=Math.cos(x);A.data[1][2]=Math.sin(-x);A.data[2][0]=0;A.data[2][1]=Math.sin(x);A.data[2][2]=Math.cos(x);return A;}

	public MT get_y_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=0;A.data[0][2]=Math.sin(x);A.data[1][0]=0;A.data[1][1]=1;A.data[1][2]=0;A.data[2][1]=0;A.data[2][0]=Math.sin(-x);A.data[2][2]=Math.cos(x);return A;}

	public MT get_z_rotation(double x){MT A= new MT(3,3);A.data[0][0]=Math.cos(x);A.data[0][1]=Math.sin(-x);A.data[0][2]=0;A.data[1][0]=Math.sin(x);A.data[1][1]=Math.cos(x);A.data[1][2]=0;A.data[2][0]=0;A.data[2][1]=0;A.data[2][2]=1;return A;}


	public double get_anpha_radian(MT U){
	if(U.data[1][1]+U.data[2][2]!=0d)
	return (Math.atan((U.data[2][1]-U.data[1][2])/(U.data[1][1]+U.data[2][2])));
	else return(Math.PI/2); }
	public double get_beta_radian(MT U){
	if(U.data[0][0]+U.data[2][2]!=0d)
	return (Math.atan((-U.data[2][0]+U.data[0][2])/(U.data[0][0]+U.data[2][2])));
	else return(Math.PI/2); }
	public double get_gama_radian(MT U){
	if(U.data[0][0]+U.data[1][1]!=0d)
	return (Math.atan((U.data[1][0]-U.data[0][1])/(U.data[1][1]+U.data[0][0])));
	else return(Math.PI/2); }




	public double RMSD(MT A,MT B){if(A.M==B.M&&A.N==B.N){
		double d=0d;
	for (int j =0;j<A.N;j++)
			{d=d+Math.pow((A.data[0][j]-B.data[0][j]),2)+Math.pow((A.data[1][j]-B.data[1][j]),2)+Math.pow((A.data[2][j]-B.data[2][j]),2);}
		return Math.sqrt(d/A.N); }
	else throw new RuntimeException("Illegal matrix dimensions.");}

			
			
			
			


		}














class TriangleResidue implements java.io.Serializable{
	private static final long serialVersionUID = 79L;
	Residue R1;
	Residue R2;
	Residue R3;
	String TargetProtein_id;
	Point Signature;
	
	TriangleResidue(Residue R1,Residue R2,Residue R3)
		{
		HashMap<String,Residue> hm=new HashMap<String,Residue>();
		LinkedList <String> list = new LinkedList<String>();
	list.add(R1.Residue_Name+R1.Chain_Name+R1.Residue_number);
	hm.put(R1.Residue_Name+R1.Chain_Name+R1.Residue_number,R1);
	list.add(R2.Residue_Name+R2.Chain_Name+R2.Residue_number);
	hm.put(R2.Residue_Name+R2.Chain_Name+R2.Residue_number,R2);
	list.add(R3.Residue_Name+R3.Chain_Name+R3.Residue_number);
	hm.put(R3.Residue_Name+R3.Chain_Name+R3.Residue_number,R3);
		Collections.sort(list);
		Residue Re1=hm.get(list.get(0));
		Residue Re2=hm.get(list.get(1));
		Residue Re3=hm.get(list.get(2));
		if((Re1.Residue_Name.compareTo(Re2.Residue_Name)!=0)&&(Re1.Residue_Name.compareTo(Re3.Residue_Name)!=0)&&(Re2.Residue_Name.compareTo(Re3.Residue_Name)!=0))
								{
			this.R1=Re1;
			this.R2=Re2;
			this.R3=Re3;	
								}		
		else if(Re1.Residue_Name.compareTo(Re2.Residue_Name)==0){
			if(Re1.get_distanceTo(Re3)>Re2.get_distanceTo(Re3))
				{
				this.R1=Re1;
				this.R2=Re2;
				this.R3=Re3;
				}
			else 
				{
				this.R1=Re2;
				this.R2=Re1;
				this.R3=Re3;
				}
																}
		
		else if(Re2.Residue_Name.compareTo(Re3.Residue_Name)==0){
			if(Re1.get_distanceTo(Re3)>Re2.get_distanceTo(Re3))
				{
				this.R1=Re1;
				this.R2=Re2;
				this.R3=Re3;
				}
			else 
				{
				this.R1=Re1;
				this.R2=Re3;
				this.R3=Re2;
				}
																}
		this.TargetProtein_id=R1.TargetProtein_id;
		this.Signature=new Point(this.R1.get_distanceTo(this.R2),this.R2.get_distanceTo(this.R3),this.R3.get_distanceTo(this.R1));	
		}

	/*TriangleResidue(Residue R1,Residue R2,Residue R3,int x)
	{
	this.R1=R1;
	this.R2=R2;
	this.R3=R3;						
	this.TargetProtein_id=R1.TargetProtein_id;
	this.Signature=new Point(this.R1.get_distanceTo(this.R2),this.R2.get_distanceTo(this.R3),this.R3.get_distanceTo(this.R1));				
	}*/
	
	public ArrayList<Residue> getList_3_Residues(){
		ArrayList<Residue> ListResidues = new ArrayList<Residue>();
		ListResidues.add(this.R1);ListResidues.add(this.R2);ListResidues.add(this.R3);
		return ListResidues;
	}
	public double SignatureRMSDfrom(TriangleResidue another_triangle){
		return Math.sqrt((Math.pow((this.Signature.x-another_triangle.Signature.x),2.0)/3+Math.pow((this.Signature.y-another_triangle.Signature.y),2.0)/3+Math.pow((this.Signature.z-another_triangle.Signature.z),2.0)/3));
				}
	public ArrayList<Point> get_list_Points(){
		ArrayList<Point> l=new ArrayList<Point>();
		for (Representative_Atom atom : R1.list_Atoms) l.add(atom.Atom_Coordinate);
		for (Representative_Atom atom : R2.list_Atoms) l.add(atom.Atom_Coordinate);
		for (Representative_Atom atom : R3.list_Atoms) l.add(atom.Atom_Coordinate);
			return l;}
	

	public String toString() {
return this.R1.toString()+"\n"+this.R2.toString()+"\n"+this.R3.toString();
				}}
class MT implements java.io.Serializable{
	private static final long serialVersionUID = 7576163164455567730L;
	public int M;
	public int N;
	public double data[][];
	
public MT(int M, int N) {
        this.M = M;
        this.N = N;
        data = new double[M][N];
    }
	public Point get_center(){MT A=this; 
		double x=0d,y=0d,z=0d;
		for (int i = 0; i < this.M; i++){x=x+A.data[i][0]/A.M;y=y+A.data[i][1]/A.M; z=z+A.data[i][2]/A.M;  }
		Point CA= new Point(x,y,z);return CA;} 
	public String get_data(){
   		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String s="";
        	try {
         
        	    s = input.readLine();
        	}   catch (IOException ex) {
        	    ex.printStackTrace();
        			}
		return s;
				}
	
	public double getDouble(String s)
		{
		return Double.parseDouble(s);
		}
	public int getInt(String s)
		{
	return Integer.parseInt(s);
		}
	public void InputMT()
		{
		System.out.print("Number of row:");
		this.M=getInt(get_data());
		System.out.print("Number of column:");
		this.N=getInt(get_data());
		System.out.print("input the Matrix:\n");
		for( int i=0;i<M;i++)
		 for(int j=0;j<N;j++) {
		System.out.print("["+i+"]["+j+"]:=");
		data[i][j]=getDouble(get_data());
					  }
		}
	public void show() {
		for (int i = 0; i < this.M; i++) {
			for (int j = 0; j < this.N; j++)
				System.out.printf("%9.6f ", data[i][j]);

		}
    			   }


	public MT plus(MT B) {
        	MT A = this;
        	if (B.M != A.M || B.N != A.N) throw new RuntimeException("Illegal matrix dimensions.");
        	MT C = new MT(M, N);
        	for (int i = 0; i < M; i++)
        	    for (int j = 0; j < N; j++)
         	       C.data[i][j] = A.data[i][j] + B.data[i][j];
       				 return C;
   					 }

 

	public MT times(MT B) {
       		 MT A = this;
       		 if (A.N != B.M) throw new RuntimeException("Illegal matrix dimensions.");
       		 MT C = new MT(A.M, B.N);
        	for (int i = 0; i < C.M; i++)
         	   for (int j = 0; j < C.N; j++)
          	      for (int k = 0; k < A.N; k++)
           	         C.data[i][j] += (A.data[i][k] * B.data[k][j]);
        					return C;
   					 }
	  public MT identity( int M){MT A= new MT(M,M);
			for (int i = 0; i < M; i++)
        	   		for (int j = 0; j < M; j++)
             	   			{if (i==j)A.data[i][j] = 1;else A.data[i][j] = 0; }
        			return A;}
	  public MT translation_to_the_Origin(Point O){MT A=this;
			for (int i =0;i<A.M;i++)
				{A.data[i][0]=A.data[i][0]-O.x;A.data[i][1]=A.data[i][1]-O.y;A.data[i][2]=A.data[i][2]-O.z; }return A;}
	  
	  public MT transpose() {
      		  MT A = new MT(this.N, this.M);
      		  for (int i = 0; i <this. M; i++)
        	    for (int j = 0; j < this.N; j++)
             	   A.data[j][i] = this.data[i][j];
        			return A;
   			        }
   				 }




 
 
 class OpenJmol extends JFrame{
	private static final long serialVersionUID = 1L;
	JmolViewer viewer;
    JmolPanel jmolPanel;
   
 
    
 
     OpenJmol(String title) throws Exception { 
    	 
    	 super(title);
    	setSize(800,600);
		int w = Toolkit.getDefaultToolkit().getScreenSize().width;
 		int h = Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setLocation((int)w/2 - 400,
         (int)h/2 - 300);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        Container contentPane = this.getContentPane();
        jmolPanel = new JmolPanel();
 
        jmolPanel.setPreferredSize(new Dimension(800,600));
        contentPane.add(jmolPanel);
 
        pack();
        setVisible(true);
        
 
    }
    
    
     public void openPDBfile(String path,String howJmol) throws Exception{	
         JmolViewer viewer = jmolPanel.getViewer();
         this.viewer = viewer;
         viewer.openFile(path);
         viewer.setAutoBond(false);
       //  viewer.evalString("select ;spacefill off;wireframe off;cartoons on;select *:Z;spacefill 100;wireframe 0.3;");
         viewer.evalString(howJmol);
     }
   
     
     

    public JmolViewer getViewer(){
    	 
        return jmolPanel.getViewer();
    }
 
 
 
     class JmolPanel extends JPanel {
        private static final long serialVersionUID = -3661941083797644242L;
        JmolViewer viewer;
        JmolAdapter adapter;
        JmolPanel() {
            adapter = new SmarterJmolAdapter();
            viewer = JmolViewer.allocateViewer(this, adapter,null,null,null,null,null);
 
        }
        public JmolViewer getViewer() {
            return viewer;
        }
 
        public void executeCmd(String rasmolScript){
            viewer.evalString(rasmolScript);
        }
 
 
        final Dimension currentSize = new Dimension();
        final Rectangle rectClip = new Rectangle();
 
        public void paint(Graphics g) {
            getSize(currentSize);
            g.getClipBounds( rectClip); 
            viewer.renderScreenImage(g,currentSize.width, currentSize.height);
        }
    }
 
}
 